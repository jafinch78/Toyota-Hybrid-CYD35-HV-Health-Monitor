#pragma once
#include "TVM1_Meta.h"
#include <stdint.h>

class Tvm1SessionMeta {
public:
  Tvm1SessionMeta();
  bool begin(File &file, uint32_t sessionNumber, uint64_t sessionCreateUs,
             const char *loggerName, const char *firmwareVersion,
             const char *boardProfile, const char *buildId,
             const char *runtimeDatabase, uint32_t canBitrate);
  bool writeRawFileOpen(uint16_t fileIndex, const char *filename, uint64_t timeUs);
  bool writeRawFileClose(uint16_t fileIndex, uint64_t recordsPersisted,
                         uint64_t bytesPersisted, uint64_t timeUs);
  bool writeClockSync(uint16_t sequence, uint64_t receiveUs, uint64_t sendUs,
                      const char *source);
  bool writeEvent(uint64_t timeUs, const char *severity, const char *eventName,
                  int32_t profile = -1, int32_t confidence = -1);
  bool writeCounters(uint64_t timeUs, uint64_t rxRecords, uint64_t txRecords,
                     uint64_t persistedRecords, uint64_t queueDrops,
                     uint64_t storageDroppedRecords, uint32_t queueHighWater,
                     uint32_t protocolErrors);
  bool writeHealthSnapshot(uint64_t timeUs);
  bool writeCaptureHealth(uint64_t timeUs,
                          uint64_t diagnosticQueueDropsSession,
                          uint64_t isotpFlowControlFailuresSession,
                          uint64_t twaiBusErrorsSession,
                          uint64_t twaiRxMissedSession,
                          uint64_t twaiRxOverrunSession,
                          uint64_t twaiTxFailedSession,
                          uint64_t twaiArbLostSession,
                          uint64_t queueHighWater,
                          uint64_t stopRequestUs,
                          uint64_t stopQueueDepth,
                          uint64_t stopFramesDrained,
                          uint64_t lastPersistedRawFrameUs,
                          uint64_t sessionCloseUs,
                          uint64_t tftRenderCalls,
                          uint64_t tftRenderTotalUs,
                          uint64_t tftRenderMaxUs,
                          uint64_t tftRenderSkippedPressure,
                          uint64_t tftDirtyRegionsDrawn,
                          uint64_t tftFullRedraws,
                          uint64_t tftQueueDepthBeforeMax,
                          uint64_t tftQueueDepthAfterMax,
                          uint64_t tftDirtyRenderEnabled,
                          uint64_t tftPressureShedEnabled,
                          uint64_t tftBatchTransactionEnabled,
                          uint64_t tftForcedFullRedraws);
  bool writeTftPageHealth(uint64_t timeUs, const uint64_t *pageCalls,
                          const uint64_t *pageTotalUs, uint8_t pageCount);
  bool writeStartTiming(uint64_t recordTimeUs,
                        uint64_t startCommandReceivedUs, uint64_t startLoggingEnterUs,
                        uint64_t sessionDirReadyUs, uint64_t rawOpenUs,
                        uint64_t metaOpenUs, uint64_t loggingActiveUs,
                        uint64_t firstPostStartRawUs, uint64_t startAckUs,
                        uint64_t firstRawFrameTimeUs);
  bool writeRuntimePerf(uint64_t timeUs, const uint64_t *values, uint8_t count);
  bool writeResiliencePerf(uint64_t timeUs, const uint64_t *values, uint8_t count);
  bool writeOptimizationPerf(uint64_t timeUs, const uint64_t *values, uint8_t count);
  bool writeBleControlEvent(uint64_t timeUs, uint16_t eventCode, uint16_t sequence,
                            uint8_t opcode, uint8_t status, uint8_t linkState);
  bool writeStorageHealth(uint64_t timeUs, uint64_t cardBytes, uint64_t usedBytes);
  bool writeDiagnosticState(uint64_t timeUs, bool enabled, uint32_t profile, uint32_t confidence);
  bool writeBusState(uint64_t timeUs, bool normalMode, uint32_t bitrate, uint32_t externalTesterRecent);
  bool writeStreamStop(uint16_t reasonCode, uint64_t timeUs);
  bool writeSessionClose(bool clean, uint16_t reasonCode, uint64_t timeUs);
  bool flush();
  void end();
  bool active() const { return active_; }

private:
  Tvm1Writer writer_;
  bool active_;
  bool appendString(uint8_t *buffer, uint16_t capacity, uint16_t &offset, const char *value);
  uint16_t eventCode(const char *eventName) const;
  uint8_t severityCode(const char *severity) const;
};
