Toyota_Hybrid_CYD35_HV_Health_DEV2_9_RAW_META

TFT PERF2 field-test revision after S0195/S0196.

Scope:
- Preserve 75% queue-pressure shedding, 80 MHz TFT, RAW-first, draining STOP, queue size and batch/storage settings.
- Dirty rendering expanded to MAIN, TEMP, HV, POWER, HEALTH, SYSTEM and DIAG EXP; SPEED/WHEELS remain dirty.
- BLOCKS and TREND intentionally remain full-render paths for a later graph-specific optimization.
- Outer sketch page cycling corrected to all 11 pages.
- External tester state uses visible cyan and explicitly reports CYD POLL PAUSED.
- Per-page profiling is stored as TVM1 HEALTH schema 4:
  2026-2036 = page render calls for pages 0-10
  2037-2047 = page render total microseconds for pages 0-10
  Page map: 0 MAIN, 1 SPEED, 2 WHEELS, 3 TEMP, 4 HV, 5 BLOCKS, 6 TREND, 7 POWER, 8 HEALTH, 9 SYSTEM, 10 DIAG EXP.
- Existing schema 3 metrics 2001-2025 remain unchanged.

This is a TEST build until Arduino IDE Verify and physical CYD testing succeed.
