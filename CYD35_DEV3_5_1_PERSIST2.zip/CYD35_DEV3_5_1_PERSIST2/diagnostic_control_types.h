#pragma once
#include <stdint.h>
#include <stddef.h>

enum VehicleProfile : uint8_t {
  PROFILE_SCANNING = 0,
  PROFILE_PRIUS_GEN2 = 1,
  PROFILE_PRIUS_GEN3 = 2,
  PROFILE_PRIUS_PHV_GEN1 = 3,
  PROFILE_CAMRY_HYBRID_GEN1 = 4,
  PROFILE_PRIUS_GEN3_OR_PHV = 5,
  PROFILE_UNKNOWN = 6,
  PROFILE_CONFLICT = 7,
  // Requested profile slot. Existing numeric values above remain frozen.
  PROFILE_PRIUS_ALPHA_ZVW45 = 8
};

enum DiagnosticCapability : uint8_t {
  VERIFIED = 0,
  READ_ONLY,
  LOCKED_UNVERIFIED,
  UNSUPPORTED
};

enum ToyotaEcuRole : uint8_t {
  ENGINE = 0,
  HYBRID_PM,
  HV_BATTERY,
  ABS_SKID,
  AC,
  SRS,
  ECU_EPS,
  COMBINATION_METER,
  BODY,
  GATEWAY,
  SMART_KEY,
  ECU_ROLE_COUNT
};

enum DiagnosticDecoderKind : uint8_t {
  DTC_DECODER_NONE = 0,
  DTC_DECODER_OBD03,
  DTC_DECODER_TOYOTA_13,
  DTC_DECODER_RAW,
  DTC_DECODER_OBD07,
  DTC_DECODER_OBD0A
};

enum DiagnosticOwner : uint8_t {
  DIAG_OWNER_NONE = 0,
  DIAG_OWNER_PERIODIC,
  DIAG_OWNER_DTC_READ,
  DIAG_OWNER_DTC_CLEAR,
  DIAG_OWNER_FAN_REFRESH
};

enum DiagnosticPlatformKey : uint8_t {
  PLATFORM_NHW20 = 0,
  PLATFORM_ZVW30,
  PLATFORM_ZVW35,
  PLATFORM_ZVW45,
  PLATFORM_AHV40
};

struct DiagnosticRequestDef {
  uint32_t requestId;
  uint32_t responseId;
  uint8_t requestLength;
  uint8_t request[7];
  uint8_t positivePrefixLength;
  uint8_t positivePrefix[3];
  DiagnosticDecoderKind decoder;
  DiagnosticCapability capability;
  uint8_t targetAddress; // Zero means standard ISO-TP; nonzero is Toyota target-addressed SF.
};

static inline bool encodeDiagnosticSingleFrame(const DiagnosticRequestDef &request,
                                                uint8_t (&data)[8]) {
  if (request.requestLength == 0 || request.requestLength > 7 ||
      (request.targetAddress && request.requestLength > 6)) return false;
  for (uint8_t i=0; i<8; ++i) data[i] = 0;
  const uint8_t offset = request.targetAddress ? 1U : 0U;
  if (request.targetAddress) data[0] = request.targetAddress;
  data[offset] = request.requestLength;
  for (uint8_t i=0; i<request.requestLength; ++i)
    data[offset + 1U + i] = request.request[i];
  return true;
}

struct FanCommandProfileDef {
  DiagnosticRequestDef overrideRequest;
  DiagnosticRequestDef releaseRequest;
  uint8_t maxLevel;
  uint8_t highLevel;
  uint16_t refreshMs;
};

struct VehicleDiagnosticEcuDef {
  ToyotaEcuRole role;
  const char *label;
  bool primary;
  DiagnosticRequestDef read;
  DiagnosticRequestDef clear;
  DiagnosticRequestDef read2; // Optional additional diagnostic store (read-only).
  DiagnosticRequestDef read3; // Optional additional diagnostic store (read-only).
};

struct VehicleDiagnosticProfile {
  VehicleProfile vehicleProfile;
  DiagnosticPlatformKey platformKey;
  const char *platformLabel;
  const char *identityToken;
  const VehicleDiagnosticEcuDef *ecus;
  uint8_t ecuCount;
  FanCommandProfileDef fan;
};
