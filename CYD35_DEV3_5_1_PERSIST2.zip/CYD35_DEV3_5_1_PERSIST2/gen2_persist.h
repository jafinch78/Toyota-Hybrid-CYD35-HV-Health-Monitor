// GEN2 ODO/FUEL-PERSIST1 (R&D test build). Included after core state definitions.
// NVS operations are called ONLY from the main loop after RAW batch service.
#pragma once
#include <stddef.h>

struct Gen2PersistRecord {
  uint32_t magic;
  uint32_t revision;
  uint32_t sequence;
  uint8_t variant;
  uint8_t flags;       // 0x01 odometer present; 0x02 real CAN fuel present
  uint8_t fuelRaw;     // last real NHW20 0x5A4 B1, never an estimate
  uint8_t reserved;
  double odoMiles;
  double fuelOdoMiles; // odometer at the last real CAN fuel sample
  uint32_t crc32;
};
static_assert(sizeof(Gen2PersistRecord) <= 64, "Gen2 NVS payload too large");
constexpr uint32_t GEN2_PERSIST_MAGIC = 0x4F444F46UL; // ODOF
constexpr uint32_t GEN2_PERSIST_REV = 1;
constexpr double GEN2_PERSIST_INTERVAL_MI = 0.25;
constexpr double GEN2_PERSIST_DEFAULT_MI_PER_RAW = 12.0; // EXPERIMENTAL, not calibrated MPG

struct Gen2RuntimePersist {
  Nhw20Variant variant = NHW20_VARIANT_UNKNOWN;
  double odoMiles = 0.0;
  bool odoValid = false;
  uint8_t lastRealFuel = 0;
  bool fuelValid = false;
  double lastFuelOdoMiles = 0.0;
  double savedOdoMiles = 0.0;
  uint8_t savedFuelRaw = 0;
  bool savedFuelValid = false;
  double savedFuelOdoMiles = 0.0;
  uint32_t sequence = 0;
  uint8_t nextSlot = 0;
  uint32_t lastStoreMs = 0;
  uint32_t stoppedSinceMs = 0;
  bool movingObserved = false;
  bool stoppedCommitDone = false;
  bool odoDerivedSinceCan = false;
  bool saveFailed = false;
  bool forcePending = false;
};
Gen2RuntimePersist gen2Persist;

static uint32_t gen2PersistCrc(const Gen2PersistRecord &rec) {
  // CRC32, reflected IEEE polynomial, over every byte preceding crc32.
  uint32_t crc = 0xFFFFFFFFUL;
  const uint8_t *p = (const uint8_t *)&rec;
  for (size_t i=0; i<offsetof(Gen2PersistRecord,crc32); ++i) {
    crc ^= p[i];
    for (uint8_t b=0;b<8;++b) crc = (crc >> 1) ^ ((crc & 1U) ? 0xEDB88320UL : 0UL);
  }
  return ~crc;
}

static bool gen2ValidRecord(const Gen2PersistRecord &r, Nhw20Variant variant) {
  return r.magic == GEN2_PERSIST_MAGIC && r.revision == GEN2_PERSIST_REV &&
         r.variant == (uint8_t)variant && (r.flags & 0xFCU) == 0 &&
         isfinite(r.odoMiles) && r.odoMiles >= 0.0 && r.odoMiles <= 10000000.0 &&
         isfinite(r.fuelOdoMiles) && r.fuelOdoMiles >= 0.0 && r.fuelOdoMiles <= 10000000.0 &&
         (!(r.flags & 2U) || r.fuelRaw <= 40U) &&
         r.crc32 == gen2PersistCrc(r);
}

static const char* gen2PersistKey(Nhw20Variant variant, uint8_t slot) {
  if (variant == NHW20_VARIANT_0405) return slot ? "g2b04" : "g2a04";
  return slot ? "g2b09" : "g2a09";
}

static bool gen2PersistStoredGeneration(Nhw20Variant variant, Preferences &prefs) {
  for (uint8_t slot=0;slot<2;++slot) {
    Gen2PersistRecord attempt = {};
    if (prefs.getBytesLength(gen2PersistKey(variant,slot)) == sizeof(attempt) &&
        prefs.getBytes(gen2PersistKey(variant,slot),&attempt,sizeof(attempt)) == sizeof(attempt) &&
        gen2ValidRecord(attempt,variant)) return true;
  }
  return false;
}

static Nhw20Variant gen2PersistRecoverSoleVariant() {
  Preferences prefs;
  if (!prefs.begin(SESSION_NVS_NAMESPACE,true)) return NHW20_VARIANT_UNKNOWN;
  bool early=gen2PersistStoredGeneration(NHW20_VARIANT_0405,prefs);
  bool late=gen2PersistStoredGeneration(NHW20_VARIANT_0609,prefs);
  prefs.end();
  if (early == late) return NHW20_VARIANT_UNKNOWN; // Ambiguous or no record.
  return early ? NHW20_VARIANT_0405 : NHW20_VARIANT_0609;
}

static void gen2PersistActivate(Nhw20Variant variant) {
  if (gen2Persist.variant == variant || variant == NHW20_VARIANT_UNKNOWN) return;
  gen2Persist = Gen2RuntimePersist();
  gen2Persist.variant = variant;
  Preferences prefs;
  Gen2PersistRecord selected = {};
  bool found = false;
  uint8_t selectedSlot = 0;
  if (prefs.begin(SESSION_NVS_NAMESPACE, true)) {
    for (uint8_t slot=0;slot<2;++slot) {
      Gen2PersistRecord attempt = {};
      if (prefs.getBytesLength(gen2PersistKey(variant,slot)) != sizeof(attempt)) continue;
      if (prefs.getBytes(gen2PersistKey(variant,slot),&attempt,sizeof(attempt)) != sizeof(attempt)) continue;
      if (!gen2ValidRecord(attempt,variant)) continue;
      if (!found || (int32_t)(attempt.sequence - selected.sequence)>0) {
        selected=attempt; selectedSlot=slot; found=true;
      }
    }
    prefs.end();
  }
  if (found) {
    gen2Persist.sequence=selected.sequence;
    gen2Persist.nextSlot=(uint8_t)(1U-selectedSlot);
    gen2Persist.odoValid=(selected.flags&1U)!=0;
    gen2Persist.odoMiles=selected.odoMiles;
    gen2Persist.savedOdoMiles=selected.odoMiles;
    gen2Persist.fuelValid=(selected.flags&2U)!=0;
    gen2Persist.lastRealFuel=selected.fuelRaw;
    gen2Persist.savedFuelRaw=selected.fuelRaw;
    gen2Persist.savedFuelValid=gen2Persist.fuelValid;
    gen2Persist.lastFuelOdoMiles=selected.fuelOdoMiles;
    gen2Persist.savedFuelOdoMiles=selected.fuelOdoMiles;
  } else if (variant == NHW20_VARIANT_0405 && odoBaseValid && isfinite(odoBaseMiles)) {
    // One-time migration of legacy NHW20 0405 manual ODO keypad storage.
    gen2Persist.odoValid=true;
    gen2Persist.odoMiles=odoBaseMiles;
    gen2Persist.savedOdoMiles=odoBaseMiles;
  }
  Serial.printf("# GEN2 PERSIST LOAD,variant=%u,record=%u,odo=%u,fuel=%u,mi=%.3f,raw=%u\n",
    (unsigned)variant,found?1U:0U,gen2Persist.odoValid?1U:0U,
    gen2Persist.fuelValid?1U:0U,gen2Persist.odoMiles,(unsigned)gen2Persist.lastRealFuel);
  tftLastRenderedPage=0xFF;
}

static void gen2PersistDistance(double deltaMiles) {
  if (gen2Persist.variant == NHW20_VARIANT_UNKNOWN || !gen2Persist.odoValid ||
      !isfinite(deltaMiles) || deltaMiles <= 0.0 || deltaMiles > 0.05) return;
  if (gen2Persist.variant == NHW20_VARIANT_0405 ||
      !live.odometerValid || (uint32_t)(millis()-live.odometerMs)>=10000U) {
    gen2Persist.odoMiles += deltaMiles;
    gen2Persist.odoDerivedSinceCan = true;
  }
}

static void gen2PersistFuel(uint8_t raw) {
  if (gen2Persist.variant == NHW20_VARIANT_UNKNOWN || raw > 40) return;
  gen2Persist.fuelValid = true;
  gen2Persist.lastRealFuel = raw;
  if (gen2Persist.odoValid) gen2Persist.lastFuelOdoMiles=gen2Persist.odoMiles;
  else gen2Persist.lastFuelOdoMiles=0.0;
}

static void gen2PersistCanOdo(double miles) {
  if (gen2Persist.variant != NHW20_VARIANT_0609 || !isfinite(miles) || miles < 0.0 || miles > 10000000.0) return;
  // Ignore isolated impossible reverse jumps; do not overwrite a valid saved ODO.
  if (gen2Persist.odoValid && miles + 5.0 < gen2Persist.odoMiles) return;
  if (!gen2Persist.odoValid && gen2Persist.fuelValid && gen2Persist.lastFuelOdoMiles == 0.0)
    gen2Persist.lastFuelOdoMiles=miles;
  gen2Persist.odoValid = true;
  gen2Persist.odoMiles = miles;
  gen2Persist.odoDerivedSinceCan=false;
}

static bool gen2PersistCheckpoint(bool force) {
  if (gen2Persist.variant == NHW20_VARIANT_UNKNOWN ||
      (!gen2Persist.odoValid && !gen2Persist.fuelValid)) return false;
  if (force) gen2Persist.forcePending=true;
  if (capturePressureMode || startPostamblePending || stopTiming.pending ||
      (canQueue != nullptr && uxQueueMessagesWaiting(canQueue) > PRESSURE_LOW)) return false;
  const uint32_t nowMs=millis();
  if (!force && (uint32_t)(nowMs-gen2Persist.lastStoreMs)<2000U) return false;
  // Avoid NVS flash wear when an operator repeatedly stops/restarts without movement.
  // Preserve fuel sample mileage as well as raw, so estimates resume from the latest real sample.
  const bool sameOdo = !gen2Persist.odoValid ||
      fabs(gen2Persist.odoMiles-gen2Persist.savedOdoMiles)<0.001;
  const bool sameFuel = gen2Persist.fuelValid==gen2Persist.savedFuelValid &&
      (!gen2Persist.fuelValid || (gen2Persist.lastRealFuel==gen2Persist.savedFuelRaw &&
        fabs(gen2Persist.lastFuelOdoMiles-gen2Persist.savedFuelOdoMiles)<0.001));
  if (gen2Persist.sequence && sameOdo && sameFuel) {
    gen2Persist.forcePending=false;
    return true;
  }
  Gen2PersistRecord record = {};
  record.magic=GEN2_PERSIST_MAGIC;
  record.revision=GEN2_PERSIST_REV;
  record.sequence=gen2Persist.sequence+1U;
  record.variant=(uint8_t)gen2Persist.variant;
  record.flags=(gen2Persist.odoValid?1U:0U)|(gen2Persist.fuelValid?2U:0U);
  record.fuelRaw=gen2Persist.lastRealFuel;
  record.odoMiles=gen2Persist.odoMiles;
  record.fuelOdoMiles=gen2Persist.lastFuelOdoMiles;
  record.crc32=gen2PersistCrc(record);
  const char* key=gen2PersistKey(gen2Persist.variant,gen2Persist.nextSlot);
  Preferences prefs;
  bool ok=false;
  if (prefs.begin(SESSION_NVS_NAMESPACE,false)) {
    ok=prefs.putBytes(key,&record,sizeof(record))==sizeof(record);
    Gen2PersistRecord verify={};
    ok=ok && prefs.getBytes(key,&verify,sizeof(verify))==sizeof(verify) &&
       verify.sequence==record.sequence && gen2ValidRecord(verify,gen2Persist.variant);
    prefs.end();
  }
  gen2Persist.lastStoreMs=nowMs;
  gen2Persist.saveFailed=!ok;
  if (ok) {
    gen2Persist.forcePending=false;
    gen2Persist.sequence=record.sequence;
    gen2Persist.nextSlot^=1U;
    gen2Persist.savedOdoMiles=gen2Persist.odoMiles;
    gen2Persist.savedFuelRaw=gen2Persist.lastRealFuel;
    gen2Persist.savedFuelValid=gen2Persist.fuelValid;
    gen2Persist.savedFuelOdoMiles=gen2Persist.lastFuelOdoMiles;
  }
  Serial.printf("# GEN2 PERSIST SAVE,variant=%u,seq=%lu,odo=%.3f,fuel=%u,ok=%u\n",
    (unsigned)gen2Persist.variant,(unsigned long)record.sequence,gen2Persist.odoMiles,
    (unsigned)record.fuelRaw,ok?1U:0U);
  return ok;
}

static void gen2PersistService(uint32_t nowMs) {
  if (vehicleProfile != PROFILE_PRIUS_GEN2 || gen2Persist.variant == NHW20_VARIANT_UNKNOWN) return;
  const bool speedFresh=live.vehicleSpeedValid && (uint32_t)(nowMs-live.vehicleSpeedMs)<2500U;
  if (speedFresh && live.vehicleSpeedMph >= 2.0f) {
    gen2Persist.movingObserved=true;
    gen2Persist.stoppedSinceMs=0;
    gen2Persist.stoppedCommitDone=false;
  } else if (speedFresh && live.vehicleSpeedMph <= 0.8f) {
    if (gen2Persist.stoppedSinceMs == 0) gen2Persist.stoppedSinceMs=nowMs;
  } else {
    gen2Persist.stoppedSinceMs=0;
  }
  const bool stopDue=gen2Persist.stoppedSinceMs != 0 &&
      (uint32_t)(nowMs-gen2Persist.stoppedSinceMs)>=2000U &&
      !gen2Persist.stoppedCommitDone &&
      (gen2Persist.movingObserved || gen2Persist.sequence==0);
  const bool quarterDue=gen2Persist.odoValid &&
      gen2Persist.odoMiles-gen2Persist.savedOdoMiles >= GEN2_PERSIST_INTERVAL_MI;
  if (stopDue || quarterDue || gen2Persist.forcePending) {
    if (gen2PersistCheckpoint(gen2Persist.forcePending) && stopDue) {
      gen2Persist.stoppedCommitDone=true;
      gen2Persist.movingObserved=false;
    }
  }
}

static bool gen2FuelForDisplay(uint32_t nowMs,uint8_t &raw,const char* &label) {
  if (live.fuelValid && (uint32_t)(nowMs-live.fuelMs)<10000U) {
    raw=live.fuelRaw;label="LIVE";return true;
  }
  if (vehicleProfile!=PROFILE_PRIUS_GEN2 || !gen2Persist.fuelValid) return false;
  raw=gen2Persist.lastRealFuel;
  label="LAST";
  if (gen2Persist.odoValid && gen2Persist.lastFuelOdoMiles>0.0 &&
      gen2Persist.odoMiles>gen2Persist.lastFuelOdoMiles+0.1) {
    const double driven=gen2Persist.odoMiles-gen2Persist.lastFuelOdoMiles;
    const double predicted=(double)raw-driven/GEN2_PERSIST_DEFAULT_MI_PER_RAW;
    raw=(uint8_t)(predicted>0.0 ? (predicted>=40.0?40U:(uint8_t)(predicted+0.5)) : 0U);
    label="EST";
  }
  return true;
}
