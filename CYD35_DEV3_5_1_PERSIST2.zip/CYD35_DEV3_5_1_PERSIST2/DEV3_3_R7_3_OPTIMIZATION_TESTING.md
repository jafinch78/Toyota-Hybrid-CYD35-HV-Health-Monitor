DEV3.3 / DIAG4 R7.3 STORAGERES2 + TFT-PERF3 TEST

Why this revision
-----------------
S0220 validated R7.2.1 lossless operation. S0221 reproduced a Card-B 238.590 ms RAW write tail and 106 queue drops on DEV3.2.1. STORAGERES1 recovered after pressure began, but DEV entered pressure at 512 frames; the backlog was already near 400 after a long write.

Changes
-------
1. Keep proven queues: DEV 1024, R7 768.
2. Use HIGH=384 and LOW=192 on both variants.
3. Above LOW: suppress BLOCKS/TREND entirely; throttle simple TFT pages to <=2 Hz.
4. At/above HIGH: existing RAW-only catch-up remains authoritative.
5. BLOCKS redraw only when block data/freshness changes (or forced 30 s refresh/page entry).
6. TREND redraw only when the 1 Hz trend ring changes (or forced refresh/page entry).
7. BLOCKS/TREND preserve static page furniture and repaint only dynamic graph areas.
8. Remove TREND's four temporary 120-element staging arrays; use the ring directly.
9. Use fixed char buffers for graph-page dynamic text.
10. Add low-frequency internal heap/largest-block and long-storage context telemetry.
11. Preserve all CAN/SD/TWAI/BLE safety and session contracts.

Optimization META schema 8 (TVM1 HEALTH_SNAPSHOT)
--------------------------------------------------
IDs begin at 2112 in this order:
2112 soft simple-page render skips
2113 graph skips due soft pressure
2114 graph skips because source data is unchanged
2115 session minimum internal free heap
2116 session minimum sampled largest internal free block
2117 pressure-entry internal free heap
2118 pressure-entry largest internal free block
2119 last pressure-entry timestamp us
2120 last pressure-entry depth
2121 last pressure-exit timestamp us
2122 last pressure-exit depth
2123 worst long-storage post-op internal free heap
2124 worst long-storage post-op largest internal block
2125 worst long-storage elapsed us
2126 worst long-storage event timestamp us
2127 worst long-storage queue depth before
2128 worst long-storage queue depth after
2129 count of storage operations >=100 ms

First test
----------
Arduino IDE Verify first. Then perform a short paired S-session run on each board with clean Android START/STOP. Exercise BLOCKS and TREND briefly. Card B is the useful stress source after the basic pair is structurally clean.
