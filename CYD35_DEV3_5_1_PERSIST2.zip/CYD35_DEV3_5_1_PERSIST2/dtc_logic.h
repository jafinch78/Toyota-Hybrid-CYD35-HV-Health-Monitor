#pragma once
#include <stdint.h>
#include <stddef.h>
#include "diagnostic_profile_tables.h"

constexpr uint8_t DTC_RESULT_CAPACITY = 32;
constexpr uint8_t DTC_RESULT_HAS_INF = 0x01;
constexpr uint8_t DTC_RESULT_NO_INF = 0x02;
constexpr uint8_t DTC_RESULT_RAW = 0x04;
constexpr uint8_t DTC_RESULT_CLEAR_OK = 0x08;
constexpr uint8_t DTC_RESULT_PENDING = 0x10;
constexpr uint8_t DTC_RESULT_PERMANENT = 0x20;

struct DtcResult {
  uint8_t ecuIndex;
  uint32_t normalizedCode;
  uint16_t inf;
  uint8_t flags;
};

struct DtcScanState {
  bool active;
  bool truncated;
  uint32_t selectedMask;
  uint32_t respondingMask;
  uint32_t completedMask;
  uint32_t noResponseMask;
  uint8_t pendingEcuIndex;
  uint8_t pendingReadStep; // Multi-store DTC reads never assume a single 13 PID is exhaustive.
  uint8_t resultCount;
  DtcResult results[DTC_RESULT_CAPACITY];
};

struct DtcClearState {
  bool confirmationPending;
  bool active;
  bool postReadPending;
  uint32_t requestedMask;
  uint32_t eligibleMask;
  uint32_t postReadMask;
  uint32_t completedMask;
  uint32_t successMask;
  uint32_t failedMask;
  uint8_t pendingEcuIndex;
};

static inline bool dtcReadCapabilityEnabled(DiagnosticCapability c) {
  return c == VERIFIED || c == READ_ONLY;
}

static inline void dtcStartRead(DtcScanState &state, uint32_t selectedMask) {
  state = {};
  state.active = true;
  state.selectedMask = selectedMask;
  state.pendingEcuIndex = 0xFF;
  state.pendingReadStep = 0;
}

static inline const DiagnosticRequestDef *dtcReadRequestForStep(
    const VehicleDiagnosticEcuDef &ecu, uint8_t step) {
  if (step == 0) return &ecu.read;
  if (step == 1 && ecu.read2.requestLength != 0 &&
      dtcReadCapabilityEnabled(ecu.read2.capability)) return &ecu.read2;
  if (step == 2 && ecu.read3.requestLength != 0 &&
      dtcReadCapabilityEnabled(ecu.read3.capability)) return &ecu.read3;
  return nullptr;
}

static inline void dtcRecordReadStep(DtcScanState &state,
                                     const VehicleDiagnosticEcuDef &ecu,
                                     uint8_t ecuIndex, bool responded) {
  if (ecuIndex >= 32) return;
  const uint32_t bit = 1UL << ecuIndex;
  if (responded) state.respondingMask |= bit;
  ++state.pendingReadStep;
  while (state.pendingReadStep <= 2 &&
         !dtcReadRequestForStep(ecu, state.pendingReadStep)) ++state.pendingReadStep;
  if (state.pendingReadStep > 2) {
    state.completedMask |= bit;
    if ((state.respondingMask & bit) == 0) state.noResponseMask |= bit;
    else state.noResponseMask &= ~bit;
    state.pendingReadStep = 0;
    state.pendingEcuIndex = 0xFF;
  }
}

static inline int dtcNextSelectedEcu(const DtcScanState &state,
                                     const VehicleDiagnosticProfile *profile,
                                     int afterIndex) {
  if (!profile) return -1;
  int start = afterIndex < -1 ? 0 : afterIndex + 1;
  for (int i=start;i<(int)profile->ecuCount && i<32;i++) {
    const uint32_t bit = 1UL << i;
    if ((state.selectedMask & bit) == 0) continue;
    if (!dtcReadCapabilityEnabled(profile->ecus[i].read.capability)) continue;
    return i;
  }
  return -1;
}

static inline int dtcNextPendingEcu(const DtcScanState &state,
                                    const VehicleDiagnosticProfile *profile) {
  if (!profile) return -1;
  for (uint8_t i=0;i<profile->ecuCount && i<32;i++) {
    const uint32_t bit = 1UL << i;
    if ((state.selectedMask & bit) == 0 || (state.completedMask & bit) != 0) continue;
    if (!dtcReadCapabilityEnabled(profile->ecus[i].read.capability)) continue;
    return (int)i;
  }
  return -1;
}

static inline void dtcMarkNoResponse(DtcScanState &state, uint8_t ecuIndex) {
  if (ecuIndex >= 32) return;
  const uint32_t bit = 1UL << ecuIndex;
  state.completedMask |= bit;
  state.noResponseMask |= bit;
  state.pendingEcuIndex = 0xFF;
}

static inline void dtcMarkResponded(DtcScanState &state, uint8_t ecuIndex) {
  if (ecuIndex >= 32) return;
  const uint32_t bit = 1UL << ecuIndex;
  state.completedMask |= bit;
  state.respondingMask |= bit;
  state.noResponseMask &= ~bit;
  state.pendingEcuIndex = 0xFF;
}

static inline bool dtcAppendResult(DtcScanState &state, const DtcResult &result) {
  for (uint8_t i=0; i<state.resultCount; ++i) {
    const DtcResult &prior = state.results[i];
    if (prior.ecuIndex == result.ecuIndex &&
        prior.normalizedCode == result.normalizedCode && prior.flags == result.flags)
      return true; // A DTC repeated by two Toyota stores is one display row.
  }
  if (state.resultCount >= DTC_RESULT_CAPACITY) {
    state.truncated = true;
    return false;
  }
  state.results[state.resultCount++] = result;
  return true;
}

static inline uint8_t dtcDecodeResponse(DtcScanState &state, uint8_t ecuIndex,
                                        DiagnosticDecoderKind decoder,
                                        const uint8_t *payload, uint16_t length) {
  if (!payload || length == 0) return 0;
  uint8_t before = state.resultCount;
  if (decoder == DTC_DECODER_OBD03 ||
      decoder == DTC_DECODER_OBD07 || decoder == DTC_DECODER_OBD0A) {
    const uint8_t expected = decoder == DTC_DECODER_OBD03 ? 0x43 :
                             decoder == DTC_DECODER_OBD07 ? 0x47 : 0x4A;
    if (payload[0] != expected) return 0;
    const uint8_t storeFlag = decoder == DTC_DECODER_OBD07 ? DTC_RESULT_PENDING :
                              decoder == DTC_DECODER_OBD0A ? DTC_RESULT_PERMANENT : 0;
    // S0231 permanent response: 4A 01 04 20 (count=1 then P0420).
    const uint16_t first = (length >= 4 && (length & 1U) == 0U &&
                            payload[1] <= (length-2U)/2U) ? 2U : 1U;
    for (uint16_t i=first;i+1<length;i+=2) {
      uint16_t code = ((uint16_t)payload[i] << 8) | payload[i+1];
      if (code == 0) continue;
      DtcResult r = {ecuIndex, code, 0, (uint8_t)(DTC_RESULT_NO_INF | storeFlag)};
      dtcAppendResult(state, r);
    }
  } else if (decoder == DTC_DECODER_TOYOTA_13) {
    if (payload[0] != 0x53 || length < 2) return 0;
    uint8_t count = payload[1];
    uint16_t needed = 2U + (uint16_t)count * 2U;
    if (needed > length) {
      DtcResult r = {ecuIndex, 0, 0, (uint8_t)(DTC_RESULT_RAW | DTC_RESULT_NO_INF)};
      uint32_t packed=0; for (uint16_t i=0;i<length && i<4;i++) packed=(packed<<8)|payload[i];
      r.normalizedCode=packed; dtcAppendResult(state,r);
    } else {
      for (uint8_t n=0;n<count;n++) {
        uint16_t pos = 2U + (uint16_t)n * 2U;
        uint16_t code = ((uint16_t)payload[pos] << 8) | payload[pos+1];
        if (code == 0) continue;
        DtcResult r = {ecuIndex, code, 0, DTC_RESULT_NO_INF};
        dtcAppendResult(state, r);
      }
    }
  } else {
    DtcResult r = {ecuIndex, 0, 0, (uint8_t)(DTC_RESULT_RAW | DTC_RESULT_NO_INF)};
    uint32_t packed=0; for (uint16_t i=0;i<length && i<4;i++) packed=(packed<<8)|payload[i];
    r.normalizedCode=packed; dtcAppendResult(state,r);
  }
  return (uint8_t)(state.resultCount - before);
}


static inline uint32_t dtcClearEligibleMask(const VehicleDiagnosticProfile *profile,
                                             uint32_t selectedMask,
                                             bool controlIdentityVerified,
                                             bool externalTesterOwner) {
  if (!profile || !controlIdentityVerified || externalTesterOwner) return 0;
  uint32_t mask = 0;
  for (uint8_t i=0; i<profile->ecuCount && i<32; ++i) {
    if ((selectedMask & (1UL << i)) == 0) continue;
    if (profile->ecus[i].clear.capability == VERIFIED) mask |= (1UL << i);
  }
  return mask;
}

static inline bool dtcBeginClearConfirmation(DtcClearState &state,
                                              const VehicleDiagnosticProfile *profile,
                                              uint32_t selectedMask,
                                              bool controlIdentityVerified,
                                              bool externalTesterOwner) {
  state = {};
  const uint32_t eligible = dtcClearEligibleMask(profile, selectedMask,
                                                  controlIdentityVerified,
                                                  externalTesterOwner);
  if (eligible == 0) return false;
  state.confirmationPending = true;
  state.requestedMask = selectedMask;
  state.eligibleMask = eligible;
  state.postReadMask = selectedMask & diagnosticSelectableReadMask(profile);
  state.pendingEcuIndex = 0xFF;
  return true;
}

static inline void dtcCancelClear(DtcClearState &state) {
  state = {};
  state.pendingEcuIndex = 0xFF;
}

static inline bool dtcConfirmClear(DtcClearState &state, bool externalTesterOwner) {
  if (!state.confirmationPending || state.eligibleMask == 0 || externalTesterOwner) return false;
  state.confirmationPending = false;
  state.active = true;
  state.postReadPending = false;
  state.completedMask = state.successMask = state.failedMask = 0;
  state.pendingEcuIndex = 0xFF;
  return true;
}

static inline int dtcNextPendingClearEcu(const DtcClearState &state,
                                          const VehicleDiagnosticProfile *profile) {
  if (!state.active || !profile) return -1;
  for (uint8_t i=0; i<profile->ecuCount && i<32; ++i) {
    const uint32_t bit = 1UL << i;
    if ((state.eligibleMask & bit) == 0 || (state.completedMask & bit) != 0) continue;
    if (profile->ecus[i].clear.capability != VERIFIED) continue;
    return (int)i;
  }
  return -1;
}

static inline void dtcMarkClearResult(DtcClearState &state, uint8_t ecuIndex, bool success) {
  if (ecuIndex >= 32) return;
  const uint32_t bit = 1UL << ecuIndex;
  state.completedMask |= bit;
  if (success) { state.successMask |= bit; state.failedMask &= ~bit; }
  else { state.failedMask |= bit; state.successMask &= ~bit; }
  state.pendingEcuIndex = 0xFF;
}

static inline bool dtcClearAllDone(const DtcClearState &state) {
  return state.eligibleMask != 0 && (state.completedMask & state.eligibleMask) == state.eligibleMask;
}

static inline void dtcAbortOperatorWork(DtcScanState &scan, DtcClearState &clear) {
  scan.active = false;
  scan.pendingEcuIndex = 0xFF;
  dtcCancelClear(clear);
}
