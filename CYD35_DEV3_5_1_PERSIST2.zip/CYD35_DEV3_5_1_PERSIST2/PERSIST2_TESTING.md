# DEV3.5.1 PERSIST2 validation candidate

SOURCE: User-supplied combined archive `Toyota_Hybrid_CYD35_DEV3_5_0_DIAG4R7_5_1_PHVCAM.zip`, internal `DEV3.5.0`.

Changes: `ODO-PERSIST1` and `FUEL-PERSIST1` separate `NHW20_0405` / `NHW20_0609` NVS two-slot CRC records. 0x230 distance continues while session counters reset; 0405 keypad and 0609 direct 0x53F precedence. Save at 0.25mi or stable stop (2s), defer during queue pressure, and after normal STOP. Save last genuine 0x5A4 B1 raw; on loss show LAST or EST using uncalibrated 12 miles/raw-count proxy (not gallons or a factory fuel level). PHV 0x612 B5 displays RAW E on 0..255 bar. Camry 2129 displays US gal E with experimental 65 L proportional bar. Gen2 profile 100% only after 0x529 DLC 6/7 + corroborated Prius fingerprint; unique-NVS restore without 529 remains unconfirmed, not 100%. Wi-Fi EXIT unchanged in both variants.

Preserved: 3.5.x PHV/Camry DTC/INF and MAX-fan tables, guarded Engine/Smart Key clears, no Techstream 3B startup operations. Existing 25MHz SD, 128 RAW batch, GEN2 passive fuel and 1024/768 CAN queues unchanged.

TEST: Arduino IDE Verify before flash. Power up/after shutdown and check `# GEN2 PERSIST LOAD/SAVE`. Seed 0405 ODO via keypad while stopped, drive >0.25mi, pause 2s, power-cycle, check derived ODO restored and 0x5A4 LIVE/LAST/EST. Test 0609 live 0x53F and restoration. For bench dropout do not disconnect vehicle CAN while driving. Verify Camry gallon and PHV raw bars, WiFi exit, page navigation, safety of DTC and FAN user UI. Compare queue losses/heap with the 3.5.0 baseline.

WARNING: NVS records are isolated by generation, not VIN. Don't move the same device between cars of the same generation without clearing/re-seeding persistent values. Consumption guess is experimental. Arduino IDE and real CYD hardware test not performed in this environment.
