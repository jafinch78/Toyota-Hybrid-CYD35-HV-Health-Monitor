#pragma once

#include <stdint.h>
#include <stddef.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

static inline int fuelTripSocWholePercent(float socPct) {
  if (!isfinite(socPct)) return 0;
  long rounded = lroundf(socPct);
  if (rounded < 0) rounded = 0;
  if (rounded > 100) rounded = 100;
  return (int)rounded;
}

enum FuelBarBand : uint8_t {
  FUEL_BAR_RED = 0,
  FUEL_BAR_YELLOW,
  FUEL_BAR_GREEN
};

static inline uint8_t fuelBarPercent(uint8_t raw) {
  const uint16_t clamped = raw > 40U ? 40U : raw;
  return (uint8_t)((clamped * 100U + 20U) / 40U);
}

static inline FuelBarBand fuelBarBand(uint8_t raw) {
  if (raw <= 7U) return FUEL_BAR_RED;
  if (raw <= 19U) return FUEL_BAR_YELLOW;
  return FUEL_BAR_GREEN;
}

static inline uint16_t fuelTripBarFillPixels(uint32_t value, uint32_t maxValue, uint16_t width) {
  if (maxValue == 0 || width == 0) return 0;
  if (value >= maxValue) return width;
  return (uint16_t)(((uint64_t)value * (uint64_t)width + (uint64_t)(maxValue / 2U)) / (uint64_t)maxValue);
}

static inline bool fuelTripEntryAppend(char *buffer, uint8_t *length, size_t capacity, char key) {
  if (!buffer || !length || capacity < 2) return false;
  if (!((key >= '0' && key <= '9') || key == '.')) return false;
  if (key == '.' && strchr(buffer, '.') != nullptr) return false;
  if ((size_t)(*length) + 1U >= capacity) return false;
  buffer[*length] = key;
  ++(*length);
  buffer[*length] = '\0';
  return true;
}

static inline void fuelTripEntryBackspace(char *buffer, uint8_t *length) {
  if (!buffer || !length || *length == 0) return;
  --(*length);
  buffer[*length] = '\0';
}

static inline bool fuelTripParseMiles(const char *text, double *milesOut) {
  if (!text || !milesOut || text[0] == '\0') return false;
  char *endp = nullptr;
  double value = strtod(text, &endp);
  if (endp == text || *endp != '\0' || !isfinite(value) || value < 0.0 || value > 999999.999) return false;
  *milesOut = value;
  return true;
}
