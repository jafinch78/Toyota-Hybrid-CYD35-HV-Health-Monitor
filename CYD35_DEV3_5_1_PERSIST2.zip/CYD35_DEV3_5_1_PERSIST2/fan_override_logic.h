#pragma once
#include <stdint.h>
#include <stddef.h>
#include <math.h>

constexpr int16_t FAN_SLIDER_X_MIN = 60;
constexpr int16_t FAN_SLIDER_X_MAX = 420;
constexpr uint8_t FAN_TRIGGER_MIN_F = 55;
constexpr uint8_t FAN_TRIGGER_MAX_F = 95;
constexpr uint8_t FAN_TRIGGER_DEFAULT_F = 69;
constexpr uint8_t FAN_HYSTERESIS_F = 2;

enum FanSpeedChoice : uint8_t {
  FAN_SPEED_MAX = 0,
  FAN_SPEED_HIGH = 1
};

enum FanUiState : uint8_t {
  FAN_UI_AUTO = 0,
  FAN_UI_ARMED,
  FAN_UI_OVERRIDE,
  FAN_UI_TEMP_STALE,
  FAN_UI_CONTROL_LOCKED,
  FAN_UI_EXTERNAL_TESTER
};

enum FanAction : uint8_t {
  FAN_ACTION_NONE = 0,
  FAN_ACTION_OVERRIDE,
  FAN_ACTION_RELEASE
};

struct FanOverrideState {
  bool enabled;
  uint8_t triggerF;
  FanSpeedChoice speed;
  FanUiState state;
  bool overrideActive;
  bool releasePending;
  uint32_t lastCommandMs;
};

struct FanDecision {
  FanUiState uiState;
  FanAction action;
  bool nextOverrideActive;
  bool disableEnabled;
};

static inline FanOverrideState fanOverrideBootState() {
  FanOverrideState s{};
  s.enabled = false;
  s.triggerF = FAN_TRIGGER_DEFAULT_F;
  s.speed = FAN_SPEED_MAX;
  s.state = FAN_UI_AUTO;
  s.overrideActive = false;
  s.releasePending = false;
  s.lastCommandMs = 0;
  return s;
}

static inline uint8_t fanSliderTempFromX(int16_t x) {
  if (x <= FAN_SLIDER_X_MIN) return FAN_TRIGGER_MIN_F;
  if (x >= FAN_SLIDER_X_MAX) return FAN_TRIGGER_MAX_F;
  const int32_t span = FAN_SLIDER_X_MAX - FAN_SLIDER_X_MIN;
  const int32_t offset = x - FAN_SLIDER_X_MIN;
  const int32_t range = FAN_TRIGGER_MAX_F - FAN_TRIGGER_MIN_F;
  return (uint8_t)(FAN_TRIGGER_MIN_F + (offset * range + span / 2) / span);
}

static inline bool fanHottestTempWholeF(const float *temps, uint8_t count, int16_t *outF) {
  if (!temps || !outF || count == 0) return false;
  float hottest = temps[0];
  if (!isfinite(hottest)) return false;
  for (uint8_t i=1; i<count; ++i) {
    if (!isfinite(temps[i])) return false;
    if (temps[i] > hottest) hottest = temps[i];
  }
  *outF = (int16_t)lroundf(hottest);
  return true;
}

static inline FanDecision evaluateFanOverride(const FanOverrideState &state,
                                               bool tempFresh,
                                               int16_t hottestF,
                                               bool controlAllowed,
                                               bool externalOwner) {
  FanDecision d{FAN_UI_AUTO, FAN_ACTION_NONE, false, false};
  if (externalOwner) {
    d.uiState = FAN_UI_EXTERNAL_TESTER;
    d.disableEnabled = state.enabled;
    return d; // never compete with another tester, including release TX
  }
  if (!state.enabled) {
    d.uiState = FAN_UI_AUTO;
    d.action = (state.overrideActive && controlAllowed) ? FAN_ACTION_RELEASE : FAN_ACTION_NONE;
    return d;
  }
  if (!controlAllowed) {
    d.uiState = FAN_UI_CONTROL_LOCKED;
    d.action = state.overrideActive ? FAN_ACTION_RELEASE : FAN_ACTION_NONE;
    return d;
  }
  if (!tempFresh) {
    d.uiState = FAN_UI_TEMP_STALE;
    d.action = state.overrideActive ? FAN_ACTION_RELEASE : FAN_ACTION_NONE;
    return d;
  }
  const int16_t releaseF = (int16_t)state.triggerF - FAN_HYSTERESIS_F;
  if (state.overrideActive) {
    if (hottestF <= releaseF) {
      d.uiState = FAN_UI_ARMED;
      d.action = FAN_ACTION_RELEASE;
      return d;
    }
    d.uiState = FAN_UI_OVERRIDE;
    d.action = FAN_ACTION_OVERRIDE;
    d.nextOverrideActive = true;
    return d;
  }
  if (hottestF >= (int16_t)state.triggerF) {
    d.uiState = FAN_UI_OVERRIDE;
    d.action = FAN_ACTION_OVERRIDE;
    d.nextOverrideActive = true;
    return d;
  }
  d.uiState = FAN_UI_ARMED;
  return d;
}

static inline void fanRevokeControl(FanOverrideState &state, bool externalOwner) {
  state.enabled = false;
  if (externalOwner) {
    state.overrideActive = false;
    state.releasePending = false;
    state.state = FAN_UI_EXTERNAL_TESTER;
    return;
  }
  state.releasePending = state.overrideActive;
  state.state = FAN_UI_CONTROL_LOCKED;
}
