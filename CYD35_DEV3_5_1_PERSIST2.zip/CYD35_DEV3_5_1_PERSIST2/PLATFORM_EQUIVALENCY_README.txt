Toyota Hybrid CYD35 PLATFORM METRIC EQUIVALENCY INTERMEDIATE

Firmware: DEV2.95-RAW-META
Source research DB: toyota_hybrid_can_db_v0.9.50_PROPOSED_RuntimeMetricEquivalency.json
Source research DB SHA256: 7f13d948e32cf40caa94e434dc29e659cb675a4b46006523b31e4fd74e56b4e6

Purpose:
- Prepare the post-PERF2 firmware for cross-platform equivalency testing.
- Normal display source order: CONFIRMED passive first; profile-gated read-only diagnostic only where no adequate passive source exists; explicitly marked PROBABLE values only; CANDIDATE/evidence-only never normal display or active polling.
- Active runtime profiles: NHW20 Gen2, AHV40 Camry Hybrid Gen1, ZVW35 Prius PHV Gen1.
- ZVW30, ZVW41 and NHW11 remain explicit non-active/research boundaries; no decoder is invented.
- Adds confirmed passive Camry/PHV speed and wheel paths, passive engine/coolant/intake paths, PHV passive SOC/current/MG/thermal paths, source-priority freshness guards, component-level pack electrical freshness, and PHV 2167/2168 read-only torque polling.
- Preserves PERF2 TFT work, RAW-first capture, draining STOP, queue sizes, 128-frame batching, 4 MHz SD and 80 MHz TFT.

Database corrections carried by v0.9.50-PROPOSED:
- S0195: NHW20 PID21C4 crank position = uint8(B6)-128 deg, CONFIRMED.
- S0196: NHW20 PID21C3 shift-sensor AF/AG/AH/AI = raw*5/256 V, channel identity + scale CONFIRMED.

TEST BUILD: Arduino IDE Verify + physical validation remain required.
