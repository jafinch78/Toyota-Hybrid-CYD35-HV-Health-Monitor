DEV3.3.2 / DIAG4 R7.3.2 FUELTRIPUI1

Purpose
- Small UI-only revision on the S0222/S0223 field-passed STORAGERES2 + TFT-PERF3 baseline.

FUEL / TRIP / SOC page
- SOC is shown as a horizontal bar with whole-number percent overlaid in the bar.
- Fuel is shown as a horizontal raw-value bar scaled 0..255 with the authoritative raw B1 integer overlaid.
- No fuel-percent calibration is claimed.

ODO / TRIP entry
- While logging is STOPPED, tap the ODO or TRIP value to open the temporary numeric keypad.
- Keys: 0-9, decimal point, BACK, CLEAR, CANCEL, SAVE.
- SAVE persists through the existing Preferences/NVS odobase/tripbase mechanism.
- SAVE rebases SESSION distance to 0 while preserving the other manual counter at its displayed value.
- Editing is intentionally disabled during active logging so NVS writes cannot add blocking latency to RAW capture.

Unchanged acquisition/storage contract
- DEV queue 1024; DIAG4 R7 queue 768.
- PRESSURE_HIGH/LOW 384/192.
- RAW batch 128.
- SD request 25 MHz.
- STORAGERES2, TFT-PERF3, START-PERF2, TWAI/diagnostic behavior unchanged.

Build note
- Host tests validate UI math/parser behavior and source contracts.
- Arduino IDE Verify on the target ESP32/TFT_eSPI toolchain remains the compile gate before flashing.

FUELTRIPUI1FIX1 (2026-10-12):
- Fixes keypad CANCEL/SAVE screen restoration. The keypad occupies y=232..319 while normal dirty redraw clears only y=2..242; exit now clears the full screen once before restoring the logger page and persistent bottom buttons.
- This is a stopped-only UI restore operation and does not run in active CAN logging.
