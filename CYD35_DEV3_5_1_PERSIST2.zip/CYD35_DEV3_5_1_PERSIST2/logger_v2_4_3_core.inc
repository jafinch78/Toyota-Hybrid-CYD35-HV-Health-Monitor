/*
  Toyota Hybrid CYD 3.5-inch Diagnostic CAN Logger core v2.4.3
  Branched from the exact hardware-proven v2.4.2 logger core for RC1.4; R2.5 hardens logging/diagnostic coexistence. DEV1 adds S0070 NHW20 display validation and HV-health visualization.
  Adds a profile-aware database-driven read-only diagnostic scheduler for normal
  MAIN/TEMP/HV operation independent of SD logging. When another tester owns the
  diagnostic bus, matching validated external responses may feed the same live
  display decoder while the CYD remains listen-only. Acquisition, SD, BLE and
  transmit-safety boundaries remain separate.

  Target hardware:
    - ESP32-3248S035R / E32N35T resistive-touch display
    - SN65HVD230 / VP230 CAN transceiver
    - ESP32 GPIO25 -> VP230 TXD, GPIO32 <- VP230 RXD
    - OBD-II pin 6 CAN-H, pin 14 CAN-L
    - Do NOT add 120-ohm termination when attached to the intact vehicle bus.

  Safety model:
    - TWAI starts in LISTEN-ONLY mode. Once a supported vehicle profile is
      established, the read-only display scheduler may enter NORMAL mode
      automatically even when SD logging is OFF. Profile identity is verified
      before Camry/PHV profile-specific polling to prevent cross-profile request use.
    - No fan commands, actuator commands, writes, clears, resets, or coding commands exist.
    - BLE can synchronize clocks, add markers, and start/stop SD logging. BLE
      has no CAN-transmit command and does not alter hardwired display polling.

  Arduino libraries:
    - TFT_eSPI (configured for this board)
    - SD and SPI (included with ESP32 Arduino core)
    - Native ESP32 TWAI driver
*/

#include <Arduino.h>
#include <SPI.h>
#include <SD.h>
#include <Preferences.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include <TFT_eSPI.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include "driver/twai.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "esp_attr.h"
#include "TVM1_SessionMeta.h"
#include "runtime_trip_math.h"
#include "fuel_trip_ui_math.h"
#include "diagnostic_control_types.h"
#include "diagnostic_profile_tables.h"
#include "dtc_logic.h"
#include "fan_override_logic.h"

// --------------------------- Hardware configuration --------------------------
TFT_eSPI tft = TFT_eSPI();
// Validated arrangement: TFT_eSPI keeps its normal SPI controller while the
// onboard microSD uses a separate HSPI instance routed through the GPIO matrix.
SPIClass sdSPI(HSPI);

#define TFT_BL_PIN 27
#define CAN_TX_PIN GPIO_NUM_25
#define CAN_RX_PIN GPIO_NUM_32

#define SD_CS_PIN   5
#define SD_SCK_PIN 18
#define SD_MISO_PIN 19
#define SD_MOSI_PIN 23

constexpr uint32_t CAN_BITRATE = 500000;
constexpr uint32_t USB_BAUD = 115200;
constexpr bool AUTO_START_LOGGING = false;
constexpr bool USB_DECODED_CSV = false;
constexpr bool PRINT_SD_DIRECTORY_AT_BOOT = false;
constexpr bool ENABLE_GEN2_PASSIVE_CONFIRMED = true;
constexpr bool ENABLE_CAMRY_AHV40_PASSIVE_CONFIRMED = true;
constexpr bool ENABLE_PHV_PASSIVE_CONFIRMED = true;
constexpr uint32_t PASSIVE_SOURCE_PREFERRED_MS = 2500;
constexpr uint32_t RAW_ROTATE_BYTES = 25UL * 1024UL * 1024UL;
constexpr uint32_t DIAGNOSTIC_TIMEOUT_US = 500000;
constexpr uint32_t DIAGNOSTIC_PENDING_TIMEOUT_US = 4000000;
constexpr uint32_t DIAGNOSTIC_GAP_MS = 200;
constexpr uint32_t DECODED_PERIOD_MS = 100;
constexpr uint32_t DISPLAY_PERIOD_MS = 250;
constexpr uint32_t FILE_FLUSH_PERIOD_MS = 1000;
constexpr uint32_t MANIFEST_CHECKPOINT_PERIOD_MS = 5000;
constexpr uint32_t TWAI_STATUS_PERIOD_MS = 1000;
constexpr uint64_t MIN_SD_FREE_BYTES = 8ULL * 1024ULL * 1024ULL;
constexpr uint32_t SD_SPI_FREQUENCY = 25000000;
// Six session streams remain open. Ten descriptors cover those streams plus
// temporary manifest/checkpoint/directory operations without the excessive
// mount-time resource reservation observed with 16 on this non-PSRAM ESP32.
constexpr uint8_t SD_MAX_OPEN_FILES = 10;
// DEV3.4/R7.4 STORAGERES2 TFTPERF3 FUELTRIPUI1FIX1 DTCFAN1 FUELBAR1: restore field-proven per-variant queue capacity after 1536 heap gate failure.
// Real-board release remains gated by post-allocation heap/largest-block telemetry.
constexpr uint16_t CAN_QUEUE_LENGTH = 1024;
constexpr size_t RAW_BATCH_SIZE = 128;
constexpr uint16_t PRESSURE_HIGH = 384U;
constexpr uint16_t PRESSURE_LOW = 192U;
constexpr bool STORAGE_STALL650_TEST = false;
constexpr uint32_t STORAGE_STALL650_MS = 650;
constexpr uint64_t CAN_TRAFFIC_RECENT_US = 3000000ULL;
constexpr uint32_t EXTERNAL_TESTER_HOLD_MS = 5000;
constexpr uint32_t EXTERNAL_OBSERVER_TIMEOUT_MS = 1500;
constexpr uint32_t DIAGNOSTIC_DISPLAY_FRESH_MS = 10000;
constexpr uint8_t DIAGNOSTIC_DRAIN_BUDGET = 32;
constexpr uint8_t MAX_HV_BLOCKS = 17;
constexpr uint8_t MAX_BATTERY_TEMPS = 12;
constexpr uint8_t MAX_INTAKE_TEMPS = 4;
constexpr uint8_t BLE_PROTOCOL_VERSION = 1;
constexpr char SESSION_COUNTER_PATH[] = "/CANLOG/NEXT_SESSION.TXT";
constexpr char SESSION_COUNTER_NEW_PATH[] = "/CANLOG/NEXT_SESSION.NEW";
constexpr char SESSION_NVS_NAMESPACE[] = "toyotacand";
constexpr char SESSION_NVS_KEY[] = "nextsess";

// BLE carries only clock/session metadata. It cannot inject CAN frames or
// enable diagnostic polling.
constexpr char BLE_SERVICE_UUID[] = "6ed9f000-4f21-4c8c-a8a7-923c86b40001";
constexpr char BLE_COMMAND_UUID[] = "6ed9f000-4f21-4c8c-a8a7-923c86b40002";
constexpr char BLE_RESPONSE_UUID[] = "6ed9f000-4f21-4c8c-a8a7-923c86b40003";

constexpr int CYD_LOG_BTN_X = 245;
constexpr int CYD_LOG_BTN_Y = 258;
constexpr int CYD_LOG_BTN_W = 105;
constexpr int CYD_LOG_BTN_H = 50;
constexpr int CYD_DIAG_BTN_X = 365;
constexpr int CYD_DIAG_BTN_Y = 258;
constexpr int CYD_DIAG_BTN_W = 105;
constexpr int CYD_DIAG_BTN_H = 50;
constexpr int CYD_PAGE_BTN_X = 10;
constexpr int CYD_PAGE_BTN_Y = 258;
constexpr int CYD_PAGE_BTN_W = 105;
constexpr int CYD_PAGE_BTN_H = 50;

// ------------------------------- Data types ----------------------------------

enum BleLinkState : uint8_t {
  BLE_LINK_STARTING = 0,
  BLE_LINK_ADVERTISING,
  BLE_LINK_CONNECTED,
  BLE_LINK_ERROR
};

struct __attribute__((packed)) CapturedFrame {
  uint64_t timeUs;
  uint32_t identifier;
  uint8_t data[8];
  uint8_t dlc;
  uint8_t extended;
  uint8_t rtr;
  uint8_t direction; // 0=RX, 1=TX
};

static_assert(sizeof(CapturedFrame) == 24, "Binary CAN record must remain 24 bytes");

struct DiagnosticTransaction {
  bool active;
  bool multiFrame;
  DiagnosticOwner owner;
  uint8_t contextIndex;
  uint8_t targetAddress;
  bool pendingResponse;
  uint8_t requestLength;
  uint8_t requestBytes[7];
  uint8_t positivePrefixLength;
  uint8_t positivePrefix[3];
  DiagnosticDecoderKind decoder;
  uint32_t requestId;
  uint32_t responseId;
  uint8_t service;
  uint8_t pid;
  uint64_t requestTimeUs;
  uint64_t lastActivityUs;
  uint16_t expectedLength;
  uint16_t receivedLength;
  uint8_t nextSequence;
  uint8_t frameCount;
  uint8_t payload[96];
};

struct ExternalDiagObserver {
  bool requestValid;
  bool responseActive;
  uint32_t requestId;
  uint32_t responseId;
  uint8_t service;
  uint8_t pids[8];
  uint8_t pidCount;
  uint64_t requestTimeUs;
  uint64_t lastActivityUs;
  uint16_t expectedLength;
  uint16_t receivedLength;
  uint8_t nextSequence;
  uint8_t payload[192];
};

struct ExternalFunctionalRequest {
  bool valid;
  uint8_t service;
  uint8_t pids[8];
  uint8_t pidCount;
  uint64_t requestTimeUs;
};

struct BleSyncRecord {
  uint16_t sequence;
  uint64_t receiveUs;
  uint64_t sendUs;
};

struct BleCommand {
  uint16_t sequence;
  uint8_t opcode;  // 1=start passive, 2=stop, 3=marker
  uint8_t flags;
  uint16_t marker;
  uint64_t receiveUs;
};

struct PendingBleMetaEvent {
  uint16_t eventCode;
  uint16_t sequence;
  uint8_t opcode;
  uint8_t status;
  uint8_t linkState;
  uint8_t reserved;
  uint64_t timeUs;
};

struct LiveSignals {
  float socPct;
  float packVolts;
  float packAmps;
  float packKW;
  int32_t mg1RPM;
  int32_t mg2RPM;
  int32_t engineRPM;
  float mg1TorqueNm;
  float mg2TorqueNm;
  uint32_t engineRunTimeS;
  float mg1InvF;
  float mg2InvF;
  float mg1StatorF;
  float mg2StatorF;
  float engineCoolantF;
  float engineIntakeAirF;
  float catalystB1S1F;
  float catalystB1S2F;
  float converterTempF;
  float hvTemp1F;
  float hvTemp2F;
  float hvTemp3F;
  float hvTemp4F;
  float hvAvgF;
  float intakeTempF;
  float intakeTempsF[MAX_INTAKE_TEMPS];
  float batteryTempsF[MAX_BATTERY_TEMPS];
  uint8_t intakeTempCount;
  uint8_t batteryTempCount;
  float auxVolts;
  uint32_t auxVoltsMs;
  bool auxVoltsValid;
  float deltaSocPct;
  float chargeLimitKW;
  float dischargeLimitKW;
  float socAfterIgPct;
  float socMaxPct;
  float socMinPct;
  float inverterCoolantF;
  uint16_t inverterPumpRPM;
  float powerResourceCurrent1;
  float powerResourceCurrent2;
  uint8_t fanLevel;
  float batteryFanMonitorV1;
  float batteryFanMonitorV2;
  uint32_t batteryFanMonitorMs;
  uint8_t batteryFanMonitorCount;
  bool batteryFanMonitorValid;
  bool batteryFanMonitorProbable;
  uint8_t gearCode;
  uint8_t gearRedundantCode;

  // DEV3/R7 normalized FUEL/TRIP/SOC page state. Fuel remains raw-only on
  // NHW20 because an exact dash-bar transfer function is not yet confirmed.
  uint8_t fuelRaw;
  uint32_t fuelMs;
  bool fuelValid;
  double odometerMiles;
  uint32_t odometerMs;
  bool odometerValid;
  bool odometerProbable;
  double runDistanceMiles;
  uint32_t runDistanceMs;
  bool runDistanceValid;

  // DEV2 SPEED/WHEELS display contract. These fields are intentionally
  // populated only by profile-validated vehicle/wheel-speed decoders.
  // Do not infer them from unvalidated cross-generation definitions.
  float vehicleSpeedMph;
  float wheelSpeedMph[4]; // FL, FR, RL, RR
  uint32_t vehicleSpeedMs;
  uint32_t wheelSpeedMs;
  bool vehicleSpeedValid;
  bool wheelSpeedValid;
  bool wheelPositionProbable;

  // Normalized metric validity/source-priority state. Component freshness is
  // tracked separately so a fresh current cannot make an old voltage appear fresh.
  uint32_t packVoltageMs;
  uint32_t packCurrentMs;
  bool packVoltageValid;
  bool packCurrentValid;
  uint32_t mg1RPMMs;
  uint32_t mg2RPMMs;
  uint32_t mg1TorqueMs;
  uint32_t mg2TorqueMs;
  bool mg1RPMValid;
  bool mg2RPMValid;
  bool mg1TorqueValid;
  bool mg2TorqueValid;
  bool mg1TorqueProbable;
  uint32_t gearMs;
  bool gearValid;

  // Fresh CONFIRMED passive sources outrank overlapping diagnostic values.
  uint32_t passiveEngineRPMMs; bool passiveEngineRPMValid;
  uint32_t passiveCoolantMs; bool passiveCoolantValid;
  uint32_t passiveIntakeMs; bool passiveIntakeValid;
  uint32_t passiveSocMs; bool passiveSocValid;
  uint32_t passivePackVoltageMs; bool passivePackVoltageValid;
  uint32_t passivePackCurrentMs; bool passivePackCurrentValid;
  uint32_t passiveMg1RPMMs; bool passiveMg1RPMValid;
  uint32_t passiveMg2RPMMs; bool passiveMg2RPMValid;
  uint32_t passiveMg1TorqueMs; bool passiveMg1TorqueValid;
  uint32_t passiveMotorTempMs; bool passiveMotorTempValid;
  uint32_t passiveInverterTempMs; bool passiveInverterTempValid;
  uint32_t passiveInverterCoolantMs; bool passiveInverterCoolantValid;

  uint8_t blockCount;
  float blockVolts[MAX_HV_BLOCKS];
  float blockMinV;
  float blockMaxV;
  float blockDeltaV;
  uint8_t blockMinNumber;
  uint8_t blockMaxNumber;
  float internalResistance[MAX_HV_BLOCKS];
  uint32_t socMs;
  uint32_t electricalMs;
  uint32_t blockVoltageMs;
  uint32_t resistanceMs;
  uint32_t batteryTempMs;
  uint32_t motorTempMs;
  uint32_t inverterTempMs;
  bool socValid;
  bool electricalValid;
  bool blockVoltageValid;
  bool resistanceValid;
  bool batteryTempValid;
  bool motorTempValid;
  bool inverterTempValid;
  uint32_t passiveElectricalMs;
  uint32_t passiveSocTempMs;
  uint32_t engineRPMMs;
  uint32_t mgPowertrainMs;
  uint32_t engineRunTimeMs;
  uint32_t c3Ms;
  uint32_t c4Ms;
  uint32_t coolantMs;
  uint32_t engineIntakeMs;
  uint32_t catalystMs;
  uint32_t catalystB1S2Ms;
  uint32_t ceMs;
  uint32_t cfMs;
  uint32_t d0Ms;
  uint32_t camryGearMs;
  uint32_t camryEngineMs;
  uint32_t camryCoolantMs;
  bool passiveElectricalValid;
  bool passiveSocTempValid;
  bool engineRPMValid;
  bool mgPowertrainValid;
  bool engineRunTimeValid;
  bool c3Valid;
  bool c4Valid;
  bool coolantValid;
  bool engineIntakeValid;
  bool catalystValid;
  bool catalystB1S2Valid;
  bool ceValid;
  bool cfValid;
  bool d0Valid;
  bool camryGearValid;
  bool camryGearRedundantValid;
  bool camryEngineValid;
  bool camryCoolantValid;
};

// ------------------------- Vehicle fingerprint data --------------------------
const uint16_t PRIUS_G2_FINGERPRINT_IDS[] = {
  0x527,0x528,0x529,0x52C,0x540,0x553,0x554,0x56D,0x57F,0x591,
  0x5A4,0x5B2,0x5B6,0x5C8,0x5CC,0x5D4,0x5EC,0x5ED,0x5F8,0x602
};
const uint16_t CAMRY_AHV40_FINGERPRINT_IDS[] = {
  0x03D,0x383,0x38B,0x394,0x398,0x39B,0x3A0,0x3A1,0x3B0,0x3B1,0x3B3,0x3B4,
  0x3B6,0x3B7,0x3B9,0x3C1,0x420,0x440,0x442,0x4DC,0x4DD,0x610,0x611
};
bool priusSeen[sizeof(PRIUS_G2_FINGERPRINT_IDS) / sizeof(uint16_t)] = {};
bool camrySeen[sizeof(CAMRY_AHV40_FINGERPRINT_IDS) / sizeof(uint16_t)] = {};
uint8_t priusScore = 0;
uint8_t camryScore = 0;
VehicleProfile vehicleProfile = PROFILE_SCANNING;
uint8_t profileConfidence = 0;
uint32_t detectionStartedMs = 0;

enum Nhw20Variant : uint8_t {
  NHW20_VARIANT_UNKNOWN = 0,
  NHW20_VARIANT_0405,
  NHW20_VARIANT_0609
};
Nhw20Variant nhw20Variant = NHW20_VARIANT_UNKNOWN;
bool nhw20VariantConfirmedBy529 = false;
bool gen2PersistFallbackChecked = false;

static inline bool nhw20EarlyProfileConfirmed() {
  return vehicleProfile == PROFILE_PRIUS_GEN2 && nhw20Variant == NHW20_VARIANT_0405;
}

static inline bool odoManualEntryAllowed() {
  return nhw20EarlyProfileConfirmed();
}


// Active read-only polling is authorized only by DB_ACTIVE_DIAGNOSTIC_REQUESTS
// in the runtime database overlay. Decoder definitions alone never authorize TX.

// ------------------------------- Global state --------------------------------
QueueHandle_t canQueue = nullptr;
QueueHandle_t diagnosticQueue = nullptr;
QueueHandle_t bleSyncQueue = nullptr;
QueueHandle_t bleCommandQueue = nullptr;
QueueHandle_t bleMetaEventQueue = nullptr;
TaskHandle_t canReceiveTaskHandle = nullptr;
LiveSignals live = {};
DiagnosticTransaction diag = {};
DtcScanState dtcScan = {};
DtcClearState dtcClear = {};
FanOverrideState fanOverride = fanOverrideBootState();
VehicleProfile fanOverrideCommandProfile = PROFILE_UNKNOWN;
bool diagnosticDisablePendingAfterFanRelease = false;
uint32_t dtcOperatorSelectedMask = 0;

enum OperatorUiModal : uint8_t {
  OP_MODAL_NONE = 0,
  OP_MODAL_MORE_ECUS,
  OP_MODAL_DTC_RESULTS,
  OP_MODAL_CLEAR_CONFIRM
};
OperatorUiModal operatorUiModal = OP_MODAL_NONE;
uint8_t operatorModalPage = 0;
ExternalDiagObserver externalObservers[8] = {};
ExternalFunctionalRequest externalFunctionalRequest = {};
uint32_t externalObserverRequests = 0;
uint32_t externalObserverCompleted = 0;
uint32_t externalObserverDecodedConfirmed = 0;
uint32_t externalObserverDecodedProbable = 0;
uint32_t externalObserverCandidateHits = 0;
uint32_t externalObserverUnknown = 0;
uint32_t externalObserverReassemblyErrors = 0;
uint32_t externalObserverTimeouts = 0;
uint32_t externalObserverBundledDecoded = 0;
uint32_t externalObserverLastMs = 0;
uint32_t externalObserverLastRequestId = 0;
uint32_t externalObserverLastResponseId = 0;
uint8_t externalObserverLastService = 0;
uint8_t externalObserverLastPid = 0;
uint16_t externalObserverLastLength = 0;
const char *externalObserverLastGrade = "NONE";
const char *externalObserverLastKey = "NONE";
VehicleProfile databaseProfileHint = PROFILE_SCANNING;
uint8_t databaseProfileHintConfidence = 0;
uint32_t databaseProfileHintMs = 0;
bool databaseProfileAuthoritative = false;


volatile uint32_t canQueueDrops = 0;
volatile uint32_t diagnosticQueueDrops = 0;
volatile uint32_t isotpFlowControlCount = 0;
volatile uint32_t isotpFlowControlFailures = 0;
volatile uint32_t isotpFlowControlMaxUs = 0;
volatile uint64_t isotpFlowControlTotalUs = 0;
uint32_t sdLogDrops = 0;
uint32_t sdLogDroppedFrames = 0;
uint64_t rawSequence = 0;
uint32_t diagnosticSequence = 0;
volatile uint32_t receivedFrameCount = 0;
volatile uint32_t transmittedFrameCount = 0;
volatile bool fastDiagActive = false;
volatile uint32_t fastDiagResponseId = 0;
volatile uint64_t fastDiagRequestTimeUs = 0;
uint32_t diagnosticTimeouts = 0;
uint32_t diagnosticNegativeResponses = 0;
uint32_t activeDiagnosticLastPollMs[DB_ACTIVE_DIAGNOSTIC_REQUEST_COUNT] = {};
bool diagnosticIdentityVerified = false;
uint32_t lastDiagnosticIdentityRequestMs = 0;
uint8_t diagnosticIdentityAttempts = 0;
const char *activeDiagnosticLastGrade = "NONE";
const char *activeDiagnosticLastKey = "NONE";
uint32_t lastDiagnosticCompleteMs = 0;
uint32_t lastDecodedMs = 0;
uint32_t lastDisplayMs = 0;
uint32_t lastFlushMs = 0;
uint32_t lastManifestCheckpointMs = 0;
uint32_t lastTwaiStatusMs = 0;
uint32_t lastProfileEvaluationMs = 0;
uint32_t lastTouchMs = 0;
bool touchWasDown = false;
uint16_t touchDownX = 0;
uint16_t touchDownY = 0;
bool diagnosticEnabled = false;
// R2.5: MAIN/TEMP/HV acquisition is independent of SD logging. Read-only
// diagnostic polling auto-starts once a supported profile is established. The
// DIAG button can manually pause/resume CYD-originated requests. External testers
// temporarily own the bus; the CYD listens/decodes and resumes after they leave.
bool diagnosticAutoStartPending = true;
bool sdReady = false;
bool loggingActive = false;
bool manifestClosed = false;
struct HvHealthRuntime {
  uint32_t sampleCount = 0;
  uint32_t lastSampleMs = 0;
  float spreadSumV = 0.0f;
  float maxSpreadV = 0.0f;
  float maxBatteryTempF = -1000.0f;
  float maxTempSpreadF = 0.0f;
  float chargeAh = 0.0f;
  float dischargeAh = 0.0f;
  uint32_t negativeCurrentSamples = 0;
  uint32_t positiveCurrentSamples = 0;
  uint32_t lowestCount[MAX_HV_BLOCKS] = {};
  uint32_t highestCount[MAX_HV_BLOCKS] = {};
  uint32_t lowAtNegativeCurrentCount[MAX_HV_BLOCKS] = {};
  uint32_t highAtPositiveCurrentCount[MAX_HV_BLOCKS] = {};
  float worstDeviationV[MAX_HV_BLOCKS] = {};
};

HvHealthRuntime hvHealth;
constexpr uint32_t HV_HEALTH_SAMPLE_INTERVAL_MS = 1000;
constexpr uint8_t TREND_SAMPLE_COUNT = 120;
struct TrendSample {
  float spreadV;
  float socPct;
  float packAmps;
  float packKW;
  float battMaxF;
  bool valid;
};
TrendSample trendSamples[TREND_SAMPLE_COUNT] = {};
uint8_t trendHead = 0;
uint8_t trendCount = 0;
uint32_t lastTrendSampleMs = 0;

uint8_t displayPage = 0;

// TFT PERF2: dirty rendering expanded to text-heavy pages + per-page profiling.
// Defaults are runtime-switchable over Serial; capture remains the priority.
constexpr uint8_t TFT_PRESSURE_THRESHOLD_PCT = 75; // retained for runtime compatibility
constexpr uint32_t TFT_SOFT_PRESSURE_INTERVAL_MS = 500;
constexpr uint32_t TFT_FORCED_FULL_REFRESH_MS = 30000;
bool tftDirtyRenderEnabled = true;
bool tftPressureShedEnabled = true;
bool tftBatchTransactionEnabled = true;
uint64_t tftRenderCalls = 0;
uint64_t tftRenderTotalUs = 0;
uint64_t tftRenderMaxUs = 0;
uint64_t tftRenderSkippedPressure = 0;
uint64_t tftDirtyRegionsDrawn = 0;
uint64_t tftFullRedraws = 0;
uint64_t tftQueueDepthBeforeMax = 0;
uint64_t tftQueueDepthAfterMax = 0;
uint64_t tftForcedFullRedraws = 0;
uint64_t tftSoftRenderSkipped = 0;
uint64_t tftGraphRenderSkippedSoftPressure = 0;
uint64_t tftGraphRenderSkippedUnchanged = 0;
uint32_t tftLastSoftPressureRenderMs = 0;
uint32_t tftLastBlocksSourceMs = 0;
bool tftLastBlocksFresh = false;
bool tftLastBlocksFreshInitialized = false;
uint8_t tftLastTrendHead = 0xFF;
uint8_t tftLastTrendCount = 0xFF;
uint8_t tftLastRenderedPage = 0xFF;
uint32_t tftLastFullRedrawMs = 0;
bool tftForceFullRedraw = true;
uint32_t tftLastButtonSignature = 0xFFFFFFFFUL;
String tftSpeedCache[6];
String tftWheelCache[11];
String tftTextPageCache[24];
int16_t tftSocBarCache = -32768;
int16_t tftFuelBarCache = -32768;
uint64_t tftPageRenderCalls[12] = {};
uint64_t tftPageRenderTotalUs[12] = {};
bool tftWheelFreshStateInitialized = false;
bool tftWheelLastFreshState = false;
char tftPerfSerialBuffer[64] = {0};
uint8_t tftPerfSerialLength = 0;
bool twaiRecovering = false;
uint32_t twaiRxMissedCount = 0;
uint32_t twaiRxOverrunCount = 0;
uint32_t twaiTxFailedCount = 0;
uint32_t twaiArbLostCount = 0;
uint32_t twaiBusErrorCount = 0;
uint32_t twaiRxQueued = 0;
uint32_t twaiTxQueued = 0;
uint32_t twaiBusOffEvents = 0;
uint32_t lastDiagRejectMs = 0;
volatile uint64_t externalTesterLastUs = 0;
uint64_t lastExternalTesterEventUs = 0;
uint64_t lastExternalDiagnosticLoggedUs = 0;
uint32_t lastExternalDiagnosticLoggedId = 0;
uint32_t externalDiagnosticFrames = 0;
uint32_t externalTesterEvents = 0;
bool twaiNormalMode = false;
bool bleConnected = false;
volatile BleLinkState bleLinkState = BLE_LINK_STARTING;
bool bleStackInitialized = false;
bool bleServiceReady = false;
char bleDeviceName[24] = {0};
uint32_t bleSyncSamples = 0;
uint32_t bleCommandCount = 0;
bool sessionHasCanTraffic = false;
uint64_t sessionStartUs = 0;
uint64_t sessionFirstCanUs = 0;
uint64_t sessionLastCanUs = 0;
uint64_t sessionLastPersistedRawFrameUs = 0;
uint32_t sessionStartReceivedFrames = 0;
uint32_t sessionStartTransmittedFrames = 0;
char loggerStatus[28] = "READY / STOPPED";
BleSyncRecord pendingSync[32] = {};
uint8_t pendingSyncCount = 0;

BLEServer *bleServer = nullptr;
BLECharacteristic *bleResponseCharacteristic = nullptr;

File rawFile;
File decodedFile;
File diagnosticFile;
File eventFile;
File syncFile;
File externalDiagnosticFile;
File metaFile;
Tvm1SessionMeta sessionMeta;
uint32_t sessionStartCanQueueDrops = 0;
uint32_t sessionStartDiagnosticQueueDrops = 0;
uint32_t sessionStartIsotpFlowControlFailures = 0;
uint32_t sessionStartTwaiBusErrorCount = 0;
uint32_t sessionStartTwaiRxMissedCount = 0;
uint32_t sessionStartTwaiRxOverrunCount = 0;
uint32_t sessionStartTwaiTxFailedCount = 0;
uint32_t sessionStartTwaiArbLostCount = 0;
volatile uint32_t sessionQueueHighWater = 0;
volatile bool sessionMetricsActive = false;

float gen2FrontLeftMph = NAN;
float gen2FrontRightMph = NAN;
float gen2RearLeftMph = NAN;
float gen2RearRightMph = NAN;
uint32_t gen2FrontWheelMs = 0;
uint32_t gen2RearWheelMs = 0;
bool gen2FrontWheelValid = false;
bool gen2RearWheelValid = false;
float camryFrontLeftMph = NAN;
float camryFrontRightMph = NAN;
float camryRearLeftMph = NAN;
float camryRearRightMph = NAN;
uint32_t camryFrontWheelMs = 0;
uint32_t camryRearWheelMs = 0;
bool camryFrontWheelValid = false;
bool camryRearWheelValid = false;

struct StopTimingTelemetry {
  bool pending;
  bool closedCleanly;
  bool bleAckRequired;
  bool boundaryCrossed;
  BleCommand command;
  uint64_t stop_request_us;
  uint32_t stop_queue_depth;
  uint32_t stop_frames_drained;
  uint64_t last_persisted_raw_frame_us;
  uint64_t session_close_us;
};
StopTimingTelemetry stopTiming = {};

char sessionDir[32] = {0};
char rawPath[48] = {0};
uint16_t rawFileIndex = 0;
uint64_t rawFilePersistedRecords = 0;
uint64_t rawFilePersistedBytes = 0;
uint32_t nextSessionNumber = 1;
bool sessionAllocatorReady = false;
bool startPostamblePending = false;
// START-PERF1: normal START advances NVS before mkdir; the SD counter mirror is
// synchronized after capture is already active. Existing Sxxxx directories remain
// the authoritative cross-device recovery source if power is lost before the mirror.
bool sessionCounterSdSyncPending = false;
uint32_t sessionCounterSdSyncValue = 0;

RuntimeDistanceIntegrator sessionDistanceIntegrator = {};
uint16_t nhw20RunCounterPrior = 0;
bool nhw20RunCounterPriorValid = false;
double odoBaseMiles = 0.0;
double tripBaseMiles = 0.0;
bool odoBaseValid = false;
bool tripBaseValid = false;
constexpr char ODO_BASE_NVS_KEY[] = "odobase";
constexpr char TRIP_BASE_NVS_KEY[] = "tripbase";

struct StartTimingTelemetry {
  bool active;
  bool emitted;
  bool bleAckRequired;
  uint16_t commandSequence;
  uint64_t start_command_received_us;
  uint64_t start_logging_enter_us;
  uint64_t session_dir_ready_us;
  uint64_t raw_open_us;
  uint64_t meta_open_us;
  uint64_t logging_active_us;
  uint64_t first_post_start_raw_us;
  uint64_t start_ack_us;
  uint64_t first_raw_frame_time_us;
  uint64_t postamble_begin_us;
  uint64_t postamble_complete_us;
  uint64_t steady_state_us;
  uint64_t startup_max_raw_gap_us;
  uint64_t startup_max_blocking_us;
  uint64_t last_startup_raw_frame_time_us;
  uint32_t drops_before_first_raw;
  uint32_t drops_during_postamble;
};
StartTimingTelemetry startTiming = {};

// START-PERF2 / storage-tail observability. All fields are RAM-only in hot paths;
// persistence occurs later through SESSION.META after RAW service.
enum StartPostambleStep : uint8_t {
  START_POSTAMBLE_BLE_ACK = 0,
  START_POSTAMBLE_MANIFEST,
  START_POSTAMBLE_COUNTER_MIRROR,
  START_POSTAMBLE_EVENT,
  START_POSTAMBLE_PRESTART_SYNC,
  START_POSTAMBLE_COMPLETE,
  START_POSTAMBLE_STEADY
};
uint8_t startPostambleStep = START_POSTAMBLE_BLE_ACK;
uint8_t startPostambleSyncIndex = 0;

struct StorageTimingState {
  uint64_t raw_write_total_us = 0;
  uint64_t raw_write_max_us = 0;
  uint64_t raw_flush_max_us = 0;
  uint64_t meta_flush_max_us = 0;
  uint64_t flush_service_max_us = 0;
  uint64_t used_bytes_max_us = 0;
  uint64_t session_open_open_us = 0;
  uint64_t session_open_write_us = 0;
  uint64_t session_open_close_us = 0;
  uint64_t session_open_total_us = 0;
  uint64_t rotation_max_us = 0;
  uint64_t stop_finalize_max_us = 0;
  uint64_t postamble_step_max_us = 0;
  uint32_t raw_write_count = 0;
  uint32_t stall_over_25ms = 0;
  uint32_t stall_over_50ms = 0;
  uint32_t stall_over_100ms = 0;
  uint32_t stall_over_250ms = 0;
  uint32_t queue_before_max = 0;
  uint32_t queue_after_max = 0;
};
StorageTimingState storageTiming = {};

// DEV3.2/R7.2 storage-resilience state. Hot-path updates remain RAM-only;
// SESSION.META persistence happens from the normal main-loop checkpoint path.
uint32_t queuePreFreeHeap = 0;
uint32_t queuePreLargestBlock = 0;
uint32_t queuePostFreeHeap = 0;
uint32_t queuePostLargestBlock = 0;
uint32_t queueMinFreeHeap = 0;
bool queueAllocationOk = false;
bool capturePressureMode = false;
uint64_t pressureEnterUs = 0;
uint32_t pressureEntryCount = 0;
uint64_t pressureTotalUs = 0;
uint64_t pressureMaxDurationUs = 0;
uint32_t pressureMaxDepth = 0;
uint64_t pressureRawRecordsDrained = 0;
uint32_t pressureDropBaseline = 0;
uint32_t pressureDropTotal = 0;
bool routineFlushPending = false;
uint64_t routineFlushDeferredSinceUs = 0;
uint32_t flushDeferredCount = 0;
uint64_t flushDeferredMaxUs = 0;
bool checkpointPending = false;
uint32_t checkpointDeferredCount = 0;
uint32_t checkpointCoalescedCount = 0;
uint64_t lastRawFlushUs = 0;
uint64_t lastMetaFlushUs = 0;
uint64_t lastFlushServiceUs = 0;
bool stall650Injected = false;
uint64_t stall650StartUs = 0;
uint64_t stall650EndUs = 0;
uint32_t stall650QueueBefore = 0;
uint32_t stall650QueueAfter = 0;
uint32_t stall650DropDelta = 0;

// STORAGERES2: low-frequency internal-heap and long-storage context.
uint32_t sessionMinInternalFree = 0;
uint32_t sessionMinInternalLargest = 0;
uint32_t pressureEntryFreeHeap = 0;
uint32_t pressureEntryLargestBlock = 0;
uint64_t pressureLastEntryUs = 0;
uint32_t pressureLastEntryDepth = 0;
uint64_t pressureLastExitUs = 0;
uint32_t pressureLastExitDepth = 0;
uint32_t longStorageFreeHeap = 0;
uint32_t longStorageLargestBlock = 0;
uint64_t longStorageElapsedUs = 0;
uint64_t longStorageEventUs = 0;
uint32_t longStorageQueueBefore = 0;
uint32_t longStorageQueueAfter = 0;
uint32_t longStorageCount = 0;

bool sdFreeSpaceCacheValid = false;
uint64_t cachedSdCardBytes = 0;
uint64_t cachedSdFreeBytes = 0;
constexpr uint64_t SD_FREE_EXACT_REFRESH_MARGIN = 64ULL * 1024ULL * 1024ULL;

volatile bool externalTesterOwnsSession = false;
volatile bool externalTesterLatchPending = false;
uint64_t externalTesterLatchUs = 0;
uint32_t postLatchDiagnosticTxAttempts = 0;
uint32_t postLatchDiagnosticTxFrames = 0;
uint32_t bleMetaEventDrops = 0;
bool pendingStartBleAck = false;
BleCommand pendingStartBleCommand = {};
bool nonfiniteDistanceReported = false;



// DEV3.1 reset breadcrumbs: comparable coarse retained state to DIAG4 R7.
struct Dev31RtcBreadcrumb {
  uint32_t magic; uint32_t resetReason; uint32_t timeMs; uint32_t session;
  uint32_t canQueued; uint32_t queueHighWater; uint32_t twaiErrors; uint32_t arbLost;
  uint32_t rxMissed; uint32_t rxOverrun; uint32_t txFailed; uint32_t freeHeap;
  uint32_t largestHeap; uint8_t logging; uint8_t diagEnabled; uint8_t externalOwner; uint8_t page;
  char stage[24];
};
constexpr uint32_t DEV31_RTC_MAGIC = 0xD3312501UL;
RTC_DATA_ATTR Dev31RtcBreadcrumb dev31Rtc = {};
static void dev31Breadcrumb(const char *stage) {
  dev31Rtc.magic=DEV31_RTC_MAGIC; dev31Rtc.resetReason=(uint32_t)esp_reset_reason(); dev31Rtc.timeMs=millis();
  dev31Rtc.session=sessionDir[0]?(uint32_t)atoi(&sessionDir[9]):0U;
  dev31Rtc.canQueued=canQueue?(uint32_t)uxQueueMessagesWaiting(canQueue):0U; dev31Rtc.queueHighWater=sessionQueueHighWater;
  dev31Rtc.twaiErrors=twaiBusErrorCount; dev31Rtc.arbLost=twaiArbLostCount; dev31Rtc.rxMissed=twaiRxMissedCount;
  dev31Rtc.rxOverrun=twaiRxOverrunCount; dev31Rtc.txFailed=twaiTxFailedCount; dev31Rtc.freeHeap=ESP.getFreeHeap();
  dev31Rtc.largestHeap=heap_caps_get_largest_free_block(MALLOC_CAP_8BIT); dev31Rtc.logging=loggingActive?1:0;
  dev31Rtc.diagEnabled=diagnosticEnabled?1:0; dev31Rtc.externalOwner=externalTesterOwnsSession?1:0; dev31Rtc.page=displayPage;
  strncpy(dev31Rtc.stage,stage,sizeof(dev31Rtc.stage)-1); dev31Rtc.stage[sizeof(dev31Rtc.stage)-1]='\0';
}

// ---------------------------- Explicit prototypes ----------------------------
// Explicit declarations prevent Arduino's auto-prototype generator from placing
// declarations before custom enum/struct definitions.
const char *profileLabel(VehicleProfile profile);
const char *dataQualityLabel();
const char *bleStateLabel();
const char *sessionName();
bool sessionTrafficRecent();
void setLoggerStatus(const char *status);
uint64_t nowMicros64();
uint16_t wordBE(uint8_t highByte, uint8_t lowByte);
int16_t signExtend12(uint16_t raw);
float rawTemperatureF(uint8_t highByte, uint8_t lowByte);
void canReceiveTask(void *parameter);
bool configureTwai(twai_mode_t mode);
bool setDiagnosticCapture(bool enable, const char *source);
bool profileSupportsActiveDiagnostics(VehicleProfile profile);
bool diagnosticCanBeEnabledForProfile(VehicleProfile profile);
void resetActiveDiagnosticSchedule();
bool sendIsoTpFlowControlFast(const CapturedFrame &firstFrame);
void processCapturedFrame(const CapturedFrame &frame);
void observeExternalDiagnosticFrame(const CapturedFrame &frame);
void serviceExternalDiagnosticObserver();
void completeExternalDiagnosticResponse(ExternalDiagObserver &observer);
const DbRuntimeSignal *findRuntimeSignal(uint32_t requestId, uint32_t responseId, uint8_t service, uint8_t pid);
void decodeRuntimeSignal(const DbRuntimeSignal &definition, const uint8_t *data, uint16_t length);
void applyDatabaseProfileEvidence(VehicleProfile profile, uint8_t confidence, bool authoritative, const char *source);
void recomputeBlockSummary();
void serviceHvHealthAccumulator();
static void serviceTrendSampler();
void writeRawBatch(const CapturedFrame *frames, size_t count);
void serviceDeferredStartPostamble();
static uint32_t currentCanQueueDepthPerf();
static void queueBleMetaEvent(uint16_t eventCode, uint16_t sequence, uint8_t opcode, uint8_t status, uint8_t linkState, uint64_t timeUs);
static bool refreshSdFreeSpaceCache();
static bool ensureSdSpaceForStart();
static void serviceBleMetaEvents(uint8_t budget);
static void emitRuntimePerf(uint64_t timeUs);
static void sampleRuntimeHeapTelemetry(bool pressureEntry = false, uint64_t longStorageUs = 0, uint32_t qBefore = 0, uint32_t qAfter = 0);
void requestLoggingStop(const BleCommand *command, bool closedCleanly);
void servicePendingLoggingStop();
void noteCanQueueResult(BaseType_t result);
void updateTwaiStatusSnapshot();
static void setValidatedVehicleSpeedMph(float mph, uint32_t nowMs);
static void setValidatedWheelSpeedsMph(float fl, float fr, float rl, float rr, uint32_t nowMs);
static bool passiveMetricFresh(bool valid, uint32_t stampMs, uint32_t nowMs, uint32_t maxAgeMs = PASSIVE_SOURCE_PREFERRED_MS);
static void refreshElectricalAggregate(uint32_t nowMs);
static void refreshMgAggregate(uint32_t nowMs);
void observeFingerprint(uint32_t identifier);
void evaluateVehicleProfile();
void parsePassiveGen2(const CapturedFrame &frame);
void parsePassiveCamry(const CapturedFrame &frame);
void parsePassivePhv(const CapturedFrame &frame);
const char *gearLabel(uint8_t gearCode);
bool transmitCAN(uint32_t identifier, const uint8_t *data, uint8_t dlc, const char *source);
void serviceDiagnosticScheduler();
bool beginDiagnosticRequest(const DiagnosticRequestDef &request, DiagnosticOwner owner, uint8_t contextIndex);
bool startOperatorDtcRead(uint32_t selectedMask);
bool beginOperatorDtcClearConfirmation(uint32_t selectedMask);
bool confirmOperatorDtcClear();
void cancelOperatorDtcClear();
bool setOperatorFanOverrideEnabled(bool enable);
void serviceFanOverrideScheduler();
bool operatorDiagnosticWorkActive();
void abortOperatorDiagnostics(const char *reason);
void revokeControlAuthorization(const char *reason);
void startDiagnosticRequest(const DbActiveDiagnosticRequest &request);
void processDiagnosticFrame(const CapturedFrame &frame);
bool isExternalDiagnosticRequest(const CapturedFrame &frame);
void writeExternalDiagnosticFrame(const CapturedFrame &frame, const char *classification);
void completeDiagnostic(const char *status);
void decodeDiagnosticPayload(uint32_t responseId, const uint8_t *payload, uint16_t length);
void decodeC3(const uint8_t *data, uint16_t length);
void decodeC4(const uint8_t *data, uint16_t length);
void decodeCE(const uint8_t *data, uint16_t length);
void decodeCF(const uint8_t *data, uint16_t length);
void decodeD0(const uint8_t *data, uint16_t length);
bool initializeSD();
bool createSessionDirectory();
bool openRawFile();
static void loadDistanceBases();
static Nhw20Variant gen2PersistRecoverSoleVariant();
static void gen2PersistActivate(Nhw20Variant variant);
static void gen2PersistDistance(double deltaMiles);
static void gen2PersistFuel(uint8_t raw);
static void gen2PersistCanOdo(double miles);
static bool gen2PersistCheckpoint(bool force);
static void gen2PersistService(uint32_t nowMs);
static bool gen2FuelForDisplay(uint32_t nowMs, uint8_t &raw, const char* &label);
static void saveDistanceBase(const char *key, double value);
static void serviceDeferredSessionCounterSdSync();
static void drawFuelTripSocPageDirty(uint32_t nowMs);
void closeSessionFiles();
void cleanupFailedSession();
bool failLogStart(const char *stage);
void rotateRawFileIfNeeded();
void writeDecodedSample();
void writeDiagnosticRecord(const char *status, uint64_t completeTimeUs);
void writeEvent(const char *severity, const char *eventName, const String &details);
void writeOperatorEvent(const char *severity, const char *eventName, const char *details);
void writeReadme();
void writeSignalsDictionary();
void writeManifest(bool closedCleanly);
void writeCheckpoint(bool closedCleanly);
bool startLogging();
void finalizeLoggingStop(bool closedCleanly);
void flushLogFiles();
void updateCapturePressureState();
void serviceRoutineStorage(uint32_t nowMs);
void serviceStall650Test();
void emitResiliencePerf(uint64_t timeUs);
void printSDDirectory(const char *dirname, uint8_t levels);
void printSDCardSummary();
void serviceTwaiHealth();
void drainDiagnosticQueue();
void drawStaticUI();
void updateDisplay();
void drawButtons();
void serviceTftPerfSerial();
void resetTftSessionMetrics();
void handleTouch();
void printHeapStage(const char *stage);
void disableBleSync(const char *stage);
bool initializeBleSync();
bool startBleAdvertising();
void serviceBleSync();
void writeSyncRecord(const BleSyncRecord &record, const char *source);
void sendBleControlResponse(const BleCommand &command, uint8_t status, uint64_t eventUs);
void processBleCommand(const BleCommand &command);
void printCsvFloat(File &file, bool valid, float value, uint8_t decimals);
void printCsvInt(File &file, bool valid, int32_t value);

static uint16_t readLe16(const uint8_t *p) {
  return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static void writeLe16(uint8_t *p, uint16_t value) {
  p[0] = value & 0xFF;
  p[1] = (value >> 8) & 0xFF;
}

static void writeLe64(uint8_t *p, uint64_t value) {
  for (uint8_t i = 0; i < 8; ++i) p[i] = (value >> (8 * i)) & 0xFF;
}

static void writeLe32(uint8_t *p, uint32_t value) {
  for (uint8_t i = 0; i < 4; ++i) p[i] = (value >> (8 * i)) & 0xFF;
}

class LoggerBleServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *server) override {
    (void)server;
    bleConnected = true;
    bleLinkState = BLE_LINK_CONNECTED;
    Serial.println("# BLE CONNECTED");
    queueBleMetaEvent(27, 0, 0, 0, BLE_LINK_CONNECTED, nowMicros64());
  }

  void onDisconnect(BLEServer *server) override {
    (void)server;
    bleConnected = false;
    if (bleServiceReady) {
      bleLinkState = BLE_LINK_ADVERTISING;
      BLEDevice::startAdvertising();
      Serial.println("# BLE DISCONNECTED,ADVERTISING");
    } else {
      bleLinkState = BLE_LINK_ERROR;
      Serial.println("# BLE DISCONNECTED,DISABLED");
    }
    queueBleMetaEvent(28, 0, 0, 0, (uint8_t)bleLinkState, nowMicros64());
  }
};

class LoggerBleCommandCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *characteristic) override {
    const uint8_t *value = characteristic->getData();
    size_t length = characteristic->getLength();
    if (value == nullptr || length < 4 || value[1] != BLE_PROTOCOL_VERSION) return;

    uint64_t receiveUs = nowMicros64();
    uint16_t sequence = readLe16(&value[2]);
    queueBleMetaEvent(29, sequence, value[0], 0, (uint8_t)bleLinkState, receiveUs);
    if (value[0] == 0x01) {
      // The client retains T1 and records T4. The 20-byte reply fits the
      // default BLE ATT payload and contains the two ESP32 timestamps.
      uint8_t reply[20] = {};
      reply[0] = 0x81;
      reply[1] = BLE_PROTOCOL_VERSION;
      writeLe16(&reply[2], sequence);
      writeLe64(&reply[4], receiveUs);
      uint64_t sendUs = nowMicros64();
      writeLe64(&reply[12], sendUs);
      if (bleResponseCharacteristic != nullptr) {
        bleResponseCharacteristic->setValue(reply, sizeof(reply));
        bleResponseCharacteristic->notify();
        queueBleMetaEvent(30, sequence, 0x01, 0, (uint8_t)bleLinkState, sendUs); // notify_attempted
      }
      BleSyncRecord record = {sequence, receiveUs, sendUs};
      if (bleSyncQueue != nullptr) xQueueSend(bleSyncQueue, &record, 0);
      return;
    }

    if (value[0] == 0x02 && length >= 8) {
      BleCommand command = {};
      command.sequence = sequence;
      command.opcode = value[4];
      command.flags = value[5];
      command.marker = readLe16(&value[6]);
      command.receiveUs = receiveUs;
      if (bleCommandQueue != nullptr) xQueueSend(bleCommandQueue, &command, 0);
    }
  }
};

// ---------------------------------- Setup -------------------------------------
void setup() {
  Serial.begin(USB_BAUD);
  delay(100);
  Serial.println("# ToyotaHybridCAN Diagnostic Logger core v2.4.3 / wrapper DEV3.5.0 RAW + META SD25M STORAGERES2 TFTPERF3 DTCFAN2 FUELPROFILE1 WIFIEXIT1");
  dev31Breadcrumb("BOOT");
  printHeapStage("BOOT");

  pinMode(TFT_BL_PIN, OUTPUT);
  digitalWrite(TFT_BL_PIN, HIGH);
  tft.init();
  tft.setRotation(1);
  tft.invertDisplay(false);
  tft.fillScreen(TFT_BLACK);
  // Measured on this E32R35T with the microSD card inserted.
  uint16_t calibration[5] = {295, 3524, 310, 3487, 7};
  tft.setTouch(calibration);
  drawStaticUI();
  printHeapStage("TFT_READY");

  // BLE must reserve its contiguous controller/host memory before the large
  // CAN queue, TWAI driver, and FAT filesystem are initialized. Advertising is
  // deliberately delayed until all subsystems are ready, so callbacks cannot
  // start a session during setup.
  bleSyncQueue = xQueueCreate(64, sizeof(BleSyncRecord));
  bleCommandQueue = xQueueCreate(16, sizeof(BleCommand));
  bleMetaEventQueue = xQueueCreate(32, sizeof(PendingBleMetaEvent));
  if (bleSyncQueue == nullptr || bleCommandQueue == nullptr || bleMetaEventQueue == nullptr) {
    if (bleSyncQueue != nullptr) vQueueDelete(bleSyncQueue);
    if (bleCommandQueue != nullptr) vQueueDelete(bleCommandQueue);
    if (bleMetaEventQueue != nullptr) vQueueDelete(bleMetaEventQueue);
    bleSyncQueue = nullptr;
    bleCommandQueue = nullptr;
    bleMetaEventQueue = nullptr;
    bleLinkState = BLE_LINK_ERROR;
    Serial.println("# BLE ERROR,QUEUE_ALLOC");
  } else {
    initializeBleSync();
  }
  printHeapStage("BLE_SERVICE");

  queuePreFreeHeap = (uint32_t)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  queuePreLargestBlock = (uint32_t)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  canQueue = xQueueCreate(CAN_QUEUE_LENGTH, sizeof(CapturedFrame));
  diagnosticQueue = xQueueCreate(64, sizeof(CapturedFrame));
  queuePostFreeHeap = (uint32_t)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  queuePostLargestBlock = (uint32_t)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  queueMinFreeHeap = ESP.getMinFreeHeap();
  queueAllocationOk = canQueue != nullptr && diagnosticQueue != nullptr;
  Serial.printf("# QUEUE MEMORY,target=%u,pre_free=%lu,pre_largest=%lu,post_free=%lu,post_largest=%lu,min_free=%lu,ok=%u\n",
                (unsigned)CAN_QUEUE_LENGTH, (unsigned long)queuePreFreeHeap, (unsigned long)queuePreLargestBlock,
                (unsigned long)queuePostFreeHeap, (unsigned long)queuePostLargestBlock,
                (unsigned long)queueMinFreeHeap, queueAllocationOk ? 1U : 0U);
  if (canQueue == nullptr || diagnosticQueue == nullptr) {
    tft.fillScreen(TFT_RED);
    tft.drawString("QUEUE ALLOC FAILED", 40, 120, 4);
    Serial.println("# FATAL,CAN_QUEUE_ALLOC");
    while (true) delay(1000);
  }
  printHeapStage("CAN_QUEUES");

  sdReady = initializeSD();
  if (sdReady) printSDCardSummary();
  if (sdReady && AUTO_START_LOGGING) startLogging();
  printHeapStage("SD_STAGE");

  if (!configureTwai(TWAI_MODE_LISTEN_ONLY)) {
    tft.fillScreen(TFT_RED);
    tft.setTextColor(TFT_WHITE, TFT_RED);
    tft.drawString("TWAI START FAILED", 40, 120, 4);
    if (loggingActive) writeEvent("ERROR", "TWAI_START_FAILED", "Driver install or start failed");
    while (true) delay(1000);
  }
  diagnosticEnabled = false;
  detectionStartedMs = millis();
  printHeapStage("TWAI_READY");
  if (bleServiceReady) startBleAdvertising();
  printHeapStage("SETUP_COMPLETE");
  dev31Breadcrumb("SETUP_COMPLETE");
  writeEvent("INFO", "TWAI_READY", "500 kbps LISTEN_ONLY; GPIO25 TX; GPIO32 RX");
  updateDisplay();
}

// -------------------------------- Main loop -----------------------------------
void loop() {
  serviceBleSync();
  serviceStall650Test();
  updateCapturePressureState();
  if (!capturePressureMode) drainDiagnosticQueue();

  CapturedFrame batch[RAW_BATCH_SIZE];
  size_t count = 0;
  while (count < RAW_BATCH_SIZE && xQueueReceive(canQueue, &batch[count], 0) == pdTRUE) ++count;

  // Evidence first: persist every session-eligible frame before decode/display work.
  // While STOP is pending, only frames timestamped at/before the request boundary
  // belong to this session. Later frames still flow through live processing below.
  size_t rawCount = count;
  if (stopTiming.pending) {
    rawCount = 0;
    while (rawCount < count && batch[rawCount].timeUs <= stopTiming.stop_request_us) ++rawCount;
    stopTiming.stop_frames_drained += (uint32_t)rawCount;
    if (rawCount < count) stopTiming.boundaryCrossed = true;
  }
  if (rawCount) {
    writeRawBatch(batch, rawCount);
    if (capturePressureMode) pressureRawRecordsDrained += rawCount;
    if (stopTiming.pending) stopTiming.last_persisted_raw_frame_us = sessionLastPersistedRawFrameUs;
  }

  // Process session-eligible frames while META is still open. If this batch
  // crosses the STOP boundary, finalize before processing later live-only frames
  // so post-STOP CAN cannot create diagnostic/event metadata in the closed session.
  for (size_t i = 0; i < rawCount; ++i) processCapturedFrame(batch[i]);
  if (!capturePressureMode) {
    serviceDeferredStartPostamble();
    serviceDeferredSessionCounterSdSync();
  }
  servicePendingLoggingStop();
  for (size_t i = rawCount; i < count; ++i) processCapturedFrame(batch[i]);
  updateCapturePressureState();
  if (loggingActive && capturePressureMode) {
    // Mark routine flush/checkpoint work pending without executing blocking I/O.
    serviceRoutineStorage(millis());
    // RAW catch-up mode: each loop pass drains another existing 128-record batch.
    // Required STOP recognition and RAW rotation remain reachable; optional services wait.
    delay(0);
    return;
  }

  // Frames may have arrived while the SD batch was written. Finish diagnostic
  // reassembly before evaluating timeouts or touchscreen disable requests.
  drainDiagnosticQueue();
  serviceExternalDiagnosticObserver();
  if (externalTesterLatchPending) {
    externalTesterLatchPending = false;
    writeEvent("INFO", "EXTERNAL_TESTER_LATCHED", "CYD diagnostic TX blocked until session end");
  }
  serviceBleMetaEvents(4);

  uint32_t nowMs = millis();
  if (nowMs - lastProfileEvaluationMs >= 1000) {
    evaluateVehicleProfile();
    lastProfileEvaluationMs = nowMs;
  }

  gen2PersistService(nowMs);
  serviceDiagnosticScheduler();
  serviceTwaiHealth();
  serviceHvHealthAccumulator();
  serviceTrendSampler();
  handleTouch();
  serviceTftPerfSerial();
  serviceBleSync();

  if (nowMs - lastDecodedMs >= DECODED_PERIOD_MS) {
    writeDecodedSample();
    lastDecodedMs = nowMs;
  }
  if (nowMs - lastDisplayMs >= DISPLAY_PERIOD_MS) {
    updateDisplay();
    lastDisplayMs = nowMs;
  }
  serviceRoutineStorage(nowMs);
  queueMinFreeHeap = min(queueMinFreeHeap == 0 ? ESP.getMinFreeHeap() : queueMinFreeHeap, ESP.getMinFreeHeap());
  delay(1);
}

// ------------------------------- CAN capture ---------------------------------
uint64_t nowMicros64() {
  return (uint64_t)esp_timer_get_time();
}

void updateCapturePressureState() {
  if (!loggingActive || canQueue == nullptr) return;
  const uint32_t depth = (uint32_t)uxQueueMessagesWaiting(canQueue);
  if (depth > pressureMaxDepth) pressureMaxDepth = depth;
  if (!capturePressureMode && depth >= PRESSURE_HIGH) {
    capturePressureMode = true;
    pressureEnterUs = nowMicros64();
    pressureLastEntryUs = pressureEnterUs;
    pressureLastEntryDepth = depth;
    pressureDropBaseline = canQueueDrops;
    ++pressureEntryCount;
    sampleRuntimeHeapTelemetry(true);
  } else if (capturePressureMode && depth <= PRESSURE_LOW) {
    const uint64_t duration = nowMicros64() - pressureEnterUs;
    pressureTotalUs += duration;
    if (duration > pressureMaxDurationUs) pressureMaxDurationUs = duration;
    pressureDropTotal += canQueueDrops - pressureDropBaseline;
    pressureLastExitUs = nowMicros64();
    pressureLastExitDepth = depth;
    capturePressureMode = false;
    pressureEnterUs = 0;
  }
}

void serviceStall650Test() {
  if (!STORAGE_STALL650_TEST || stall650Injected || !loggingActive || stopTiming.pending) return;
  if (startTiming.steady_state_us == 0 || nowMicros64() - startTiming.steady_state_us < 5000000ULL) return;
  const uint32_t depth = canQueue ? (uint32_t)uxQueueMessagesWaiting(canQueue) : 0U;
  if (capturePressureMode || depth > PRESSURE_LOW) return;
  stall650Injected = true;
  stall650StartUs = nowMicros64();
  stall650QueueBefore = depth;
  const uint32_t dropsBefore = canQueueDrops;
  delay(STORAGE_STALL650_MS);
  stall650EndUs = nowMicros64();
  stall650QueueAfter = canQueue ? (uint32_t)uxQueueMessagesWaiting(canQueue) : 0U;
  stall650DropDelta = canQueueDrops - dropsBefore;
}

void serviceRoutineStorage(uint32_t nowMs) {
  if (!loggingActive) return;
  const uint32_t depth = canQueue ? (uint32_t)uxQueueMessagesWaiting(canQueue) : 0U;
  const bool defer = capturePressureMode || depth > PRESSURE_LOW;

  if (routineFlushPending && !defer) {
    flushLogFiles();
    const uint64_t deferredUs = nowMicros64() - routineFlushDeferredSinceUs;
    if (deferredUs > flushDeferredMaxUs) flushDeferredMaxUs = deferredUs;
    routineFlushPending = false;
    routineFlushDeferredSinceUs = 0;
    lastFlushMs = nowMs;
  } else if (nowMs - lastFlushMs >= FILE_FLUSH_PERIOD_MS) {
    if (defer) {
      if (!routineFlushPending) {
        routineFlushPending = true;
        routineFlushDeferredSinceUs = nowMicros64();
        ++flushDeferredCount;
      }
      lastFlushMs = nowMs;
    } else {
      flushLogFiles();
      lastFlushMs = nowMs;
    }
  }

  if (checkpointPending && !defer) {
    writeCheckpoint(false);
    checkpointPending = false;
    lastManifestCheckpointMs = nowMs;
  } else if (nowMs - lastManifestCheckpointMs >= MANIFEST_CHECKPOINT_PERIOD_MS) {
    if (defer) {
      if (!checkpointPending) { checkpointPending = true; ++checkpointDeferredCount; }
      else ++checkpointCoalescedCount;
      lastManifestCheckpointMs = nowMs;
    } else {
      writeCheckpoint(false);
      lastManifestCheckpointMs = nowMs;
    }
  }
}

bool configureTwai(twai_mode_t mode) {
  if (canReceiveTaskHandle != nullptr) {
    vTaskDelete(canReceiveTaskHandle);
    canReceiveTaskHandle = nullptr;
  }

  // These calls legitimately fail before the first installation.
  twai_stop();
  twai_driver_uninstall();

  twai_general_config_t general = TWAI_GENERAL_CONFIG_DEFAULT(CAN_TX_PIN, CAN_RX_PIN, mode);
  general.tx_queue_len = mode == TWAI_MODE_NORMAL ? 20 : 0;
  general.rx_queue_len = 100;
  twai_timing_config_t timing = TWAI_TIMING_CONFIG_500KBITS();
  twai_filter_config_t filter = TWAI_FILTER_CONFIG_ACCEPT_ALL();
  if (twai_driver_install(&general, &timing, &filter) != ESP_OK) return false;
  if (twai_start() != ESP_OK) {
    twai_driver_uninstall();
    return false;
  }
  twai_reconfigure_alerts(TWAI_ALERT_RX_QUEUE_FULL | TWAI_ALERT_BUS_OFF |
                          TWAI_ALERT_BUS_RECOVERED | TWAI_ALERT_ABOVE_ERR_WARN |
                          TWAI_ALERT_ERR_PASS | TWAI_ALERT_TX_FAILED |
                          TWAI_ALERT_ARB_LOST | TWAI_ALERT_BUS_ERROR, nullptr);
  twaiNormalMode = mode == TWAI_MODE_NORMAL;
  if (xTaskCreatePinnedToCore(canReceiveTask, "CAN_RX", 4096, nullptr, 20,
                             &canReceiveTaskHandle, 0) != pdPASS) {
    twai_stop();
    twai_driver_uninstall();
    canReceiveTaskHandle = nullptr;
    return false;
  }
  return true;
}

bool profileSupportsActiveDiagnostics(VehicleProfile profile) {
  return profile == PROFILE_PRIUS_GEN2 ||
         profile == PROFILE_CAMRY_HYBRID_GEN1 ||
         profile == PROFILE_PRIUS_PHV_GEN1;
}

bool diagnosticCanBeEnabledForProfile(VehicleProfile profile) {
  if (profileSupportsActiveDiagnostics(profile)) return true;
  const VehicleDiagnosticProfile *operatorProfile = diagnosticProfileFor(profile);
  if (operatorProfile && diagnosticSelectableReadMask(operatorProfile) != 0) return true;
  // Unknown/ambiguous profiles may enter NORMAL mode only for the explicit
  // read-only 7E0/21C1 identity preflight. No profile-specific polling starts
  // until the model response resolves to a supported profile.
  return profile == PROFILE_SCANNING || profile == PROFILE_UNKNOWN ||
         profile == PROFILE_PRIUS_GEN3_OR_PHV;
}

void resetActiveDiagnosticSchedule() {
  uint32_t nowMs = millis();
  for (size_t i = 0; i < DB_ACTIVE_DIAGNOSTIC_REQUEST_COUNT; ++i) {
    uint32_t period = DB_ACTIVE_DIAGNOSTIC_REQUESTS[i].periodMs;
    activeDiagnosticLastPollMs[i] = nowMs >= period ? nowMs - period : 0;
  }
  lastDiagnosticIdentityRequestMs = 0;
  diagnosticIdentityAttempts = 0;
  activeDiagnosticLastGrade = "NONE";
  activeDiagnosticLastKey = "NONE";
}

bool setDiagnosticCapture(bool enable, const char *source) {
  if (enable) {
    if (externalTesterOwnsSession) return false;
    if (!diagnosticCanBeEnabledForProfile(vehicleProfile)) return false;
    if (externalTesterLastUs != 0 &&
        (nowMicros64() - externalTesterLastUs) / 1000ULL < EXTERNAL_TESTER_HOLD_MS) {
      writeEvent("WARNING", "DIAGNOSTIC_ENABLE_REJECTED", "External diagnostic tester recently observed");
      return false;
    }
    if (!twaiNormalMode && !configureTwai(TWAI_MODE_NORMAL)) {
      writeEvent("ERROR", "TWAI_MODE_CHANGE_FAILED", "Could not enter NORMAL diagnostic mode");
      return false;
    }
    diagnosticEnabled = true;
    // Strong Gen2 passive fingerprinting is already hardware-proven. Camry and
    // PHV require an authoritative database/model signature before their
    // profile-specific schedules run, because ZVW35 previously matched the
    // Camry heuristic at high confidence.
    diagnosticIdentityVerified =
        (vehicleProfile == PROFILE_PRIUS_GEN2 && profileConfidence >= 80) ||
        ((vehicleProfile == PROFILE_CAMRY_HYBRID_GEN1 || vehicleProfile == PROFILE_PRIUS_PHV_GEN1) &&
         databaseProfileAuthoritative);
    resetActiveDiagnosticSchedule();
    writeEvent("INFO", "DIAGNOSTIC_ENABLED",
               String(source) + "; TWAI=NORMAL; read-only profile scheduler; identity=" +
               (diagnosticIdentityVerified ? "verified" : "preflight"));
    return true;
  }

  if (!externalTesterOwnsSession && fanOverride.overrideActive) {
    fanOverride.enabled = false;
    fanOverride.releasePending = true;
    diagnosticDisablePendingAfterFanRelease = true;
    writeEvent("INFO", "OP_FAN_RELEASE", "Diagnostic disable deferred until AUTO/release attempt");
    return true;
  }
  diagnosticDisablePendingAfterFanRelease = false;
  fastDiagActive = false;
  if (diag.active) completeDiagnostic("DIAGNOSTIC_DISABLED");
  diagnosticEnabled = false;
  diagnosticIdentityVerified = false;
  if (twaiNormalMode && !configureTwai(TWAI_MODE_LISTEN_ONLY)) {
    writeEvent("ERROR", "TWAI_MODE_CHANGE_FAILED", "Could not restore LISTEN_ONLY mode");
    return false;
  }
  writeEvent("INFO", "DIAGNOSTIC_DISABLED", String(source) + "; TWAI=LISTEN_ONLY");
  return true;
}

void noteCanQueueResult(BaseType_t result) {
  if (result != pdTRUE) {
    ++canQueueDrops;
    if (startTiming.active && startTiming.first_post_start_raw_us == 0) ++startTiming.drops_before_first_raw;
    else if (startTiming.active && startTiming.postamble_complete_us == 0) ++startTiming.drops_during_postamble;
    if (sessionMetricsActive) sessionQueueHighWater = CAN_QUEUE_LENGTH;
    return;
  }
  if (!sessionMetricsActive || canQueue == nullptr) return;
  const uint32_t depth = (uint32_t)uxQueueMessagesWaiting(canQueue);
  if (depth > sessionQueueHighWater) sessionQueueHighWater = depth;
}

void canReceiveTask(void *parameter) {
  (void)parameter;
  twai_message_t message;
  for (;;) {
    if (twai_receive(&message, pdMS_TO_TICKS(100)) == ESP_OK) {
      CapturedFrame frame = {};
      frame.timeUs = nowMicros64();
      frame.identifier = message.identifier;
      frame.dlc = message.data_length_code;
      frame.extended = message.extd;
      frame.rtr = message.rtr;
      frame.direction = 0;
      memcpy(frame.data, message.data, 8);
      ++receivedFrameCount;
      if (isExternalDiagnosticRequest(frame)) {
        externalTesterLastUs = frame.timeUs;
        fastDiagActive = false;
        if (!externalTesterOwnsSession &&
            (loggingActive || diagnosticEnabled || operatorDiagnosticWorkActive())) {
          externalTesterOwnsSession = true;
          externalTesterLatchPending = true;
          externalTesterLatchUs = frame.timeUs;
        }
      }
      bool rawQueued = false;
      if (!frame.extended && !frame.rtr &&
          (frame.identifier == 0x7E8 || frame.identifier == 0x7EA || frame.identifier == 0x7EB ||
           frame.identifier == 0x758 || frame.identifier == 0x7B8 || frame.identifier == 0x7C8 ||
           frame.identifier == 0x7A9 || frame.identifier == 0x7CC)) {
        // Preserve chronological RX-before-TX order in the raw queue. This
        // nonblocking RAM copy adds only microseconds before flow control.
        noteCanQueueResult(xQueueSend(canQueue, &frame, 0));
        rawQueued = true;
        // ISO-TP flow control is sent here on the high-priority receive task,
        // before TFT or SD work can delay it. Full reassembly remains in loop().
        if (fastDiagActive && frame.identifier == fastDiagResponseId && frame.timeUs >= fastDiagRequestTimeUs &&
            frame.dlc >= 2 && (frame.data[0] >> 4) == 0x1)
          sendIsoTpFlowControlFast(frame);
        if (xQueueSend(diagnosticQueue, &frame, 0) != pdTRUE) ++diagnosticQueueDrops;
      }
      if (!rawQueued) noteCanQueueResult(xQueueSend(canQueue, &frame, 0));
    }
  }
}

bool sendIsoTpFlowControlFast(const CapturedFrame &firstFrame) {
  bool externalRecent = externalTesterLastUs != 0 &&
                        (nowMicros64() - externalTesterLastUs) / 1000ULL < EXTERNAL_TESTER_HOLD_MS;
  if (externalTesterOwnsSession) { ++postLatchDiagnosticTxAttempts; return false; }
  if (externalRecent || !diagnosticEnabled || !twaiNormalMode) return false;
  uint16_t expected = ((uint16_t)(firstFrame.data[0] & 0x0F) << 8) | firstFrame.data[1];
  if (expected <= 7 || expected > sizeof(diag.payload)) return false;

  twai_message_t message = {};
  message.identifier = firstFrame.identifier - 8;
  message.data_length_code = 8;
  message.data[0] = 0x30;
  if (externalTesterOwnsSession) { ++postLatchDiagnosticTxAttempts; return false; }
  esp_err_t result = twai_transmit(&message, pdMS_TO_TICKS(5));
  if (result != ESP_OK) {
    ++isotpFlowControlFailures;
    return false;
  }
  if (externalTesterOwnsSession) ++postLatchDiagnosticTxFrames;

  uint64_t sentUs = nowMicros64();
  uint32_t latencyUs = (uint32_t)(sentUs - firstFrame.timeUs);
  ++isotpFlowControlCount;
  isotpFlowControlTotalUs += latencyUs;
  if (latencyUs > isotpFlowControlMaxUs) isotpFlowControlMaxUs = latencyUs;
  ++transmittedFrameCount;

  CapturedFrame tx = {};
  tx.timeUs = sentUs;
  tx.identifier = message.identifier;
  tx.dlc = 8;
  tx.direction = 1;
  memcpy(tx.data, message.data, 8);
  if (xQueueSend(canQueue, &tx, 0) != pdTRUE) ++canQueueDrops;
  return true;
}

void drainDiagnosticQueue() {
  // Keep external diagnostic traffic from monopolizing loop(). The main loop
  // calls this twice per pass, so up to 64 diagnostic frames are serviced per
  // iteration while BLE START/STOP, raw CAN batching, touch and SD work remain
  // bounded and responsive. RAW capture uses the independent canQueue.
  CapturedFrame frame;
  uint8_t processed = 0;
  while (processed < DIAGNOSTIC_DRAIN_BUDGET &&
         xQueueReceive(diagnosticQueue, &frame, 0) == pdTRUE) {
    processDiagnosticFrame(frame);
    ++processed;
  }
}

void processCapturedFrame(const CapturedFrame &frame) {
  if (!frame.extended && !frame.rtr) {
    observeExternalDiagnosticFrame(frame);
    if (isExternalDiagnosticRequest(frame)) {
      // External testers own the diagnostic bus while active. Preserve the
      // automatic display-polling intent so the CYD can resume after the hold
      // window expires, unless the user had manually paused DIAG.
      bool newObservation = lastExternalTesterEventUs == 0 ||
                            frame.timeUs - lastExternalTesterEventUs > EXTERNAL_TESTER_HOLD_MS * 1000ULL;
      lastExternalTesterEventUs = frame.timeUs;
      if (newObservation) {
        ++externalTesterEvents;
        writeEvent("INFO", "EXTERNAL_TESTER_DETECTED", "Passive observation; logger diagnostics forced off");
      }
      writeExternalDiagnosticFrame(frame, "EXTERNAL_REQUEST");
      diagnosticAutoStartPending = true;
      if (diagnosticEnabled || diag.active || fastDiagActive) {
        // External tester ownership must never tear down the TWAI driver or
        // CAN_RX task during an Android-controlled logging session. Software
        // inhibit all CYD diagnostic TX and retain the current controller mode.
        // transmitCAN() and the fast ISO-TP FC path independently enforce the
        // external-tester hold gate. The same Sxxxx session therefore remains
        // open until an explicit BLE/TFT STOP LOG.
        fastDiagActive = false;
        if (diag.active) completeDiagnostic("EXTERNAL_TESTER");
        diagnosticEnabled = false;
        diagnosticIdentityVerified = false;
        writeEvent("INFO", "DIAGNOSTIC_SUSPENDED_EXTERNAL",
                   String("TX inhibited; TWAI mode retained; logging=") +
                   (loggingActive ? "active" : "stopped"));
      }
    } else if (externalTesterLastUs != 0 &&
               frame.timeUs >= externalTesterLastUs &&
               frame.timeUs - externalTesterLastUs <= EXTERNAL_TESTER_HOLD_MS * 1000ULL &&
               frame.identifier >= 0x7E8 && frame.identifier <= 0x7EF) {
      writeExternalDiagnosticFrame(frame, "EXTERNAL_RESPONSE");
    }
    observeFingerprint(frame.identifier);
    if (vehicleProfile == PROFILE_PRIUS_GEN2) parsePassiveGen2(frame);
    else if (vehicleProfile == PROFILE_CAMRY_HYBRID_GEN1) parsePassiveCamry(frame);
    else if (vehicleProfile == PROFILE_PRIUS_PHV_GEN1) parsePassivePhv(frame);
  }
}

bool isExternalDiagnosticRequest(const CapturedFrame &frame) {
  if (frame.direction != 0 || frame.extended || frame.rtr || frame.dlc < 3) return false;
  if (!(frame.identifier == 0x7DF || (frame.identifier >= 0x7E0 && frame.identifier <= 0x7E7))) return false;
  uint8_t pciType = frame.data[0] >> 4;
  return pciType == 0x0 || pciType == 0x1;
}

void writeExternalDiagnosticFrame(const CapturedFrame &frame, const char *classification) {
  if (frame.timeUs == lastExternalDiagnosticLoggedUs && frame.identifier == lastExternalDiagnosticLoggedId) return;
  lastExternalDiagnosticLoggedUs = frame.timeUs;
  lastExternalDiagnosticLoggedId = frame.identifier;
  ++externalDiagnosticFrames;
  if (!loggingActive || !externalDiagnosticFile || capturePressureMode) return;
  externalDiagnosticFile.printf("%llu,%03lX,%u,", (unsigned long long)frame.timeUs,
                                (unsigned long)frame.identifier, frame.dlc);
  for (uint8_t i = 0; i < frame.dlc && i < 8; ++i) {
    if (frame.data[i] < 16) externalDiagnosticFile.print('0');
    externalDiagnosticFile.print(frame.data[i], HEX);
  }
  externalDiagnosticFile.print(',');
  externalDiagnosticFile.println(classification);
}

bool transmitCAN(uint32_t identifier, const uint8_t *data, uint8_t dlc, const char *source) {
  if (externalTesterOwnsSession) {
    ++postLatchDiagnosticTxAttempts;
    return false;
  }
  bool externalRecent = externalTesterLastUs != 0 &&
                        (nowMicros64() - externalTesterLastUs) / 1000ULL < EXTERNAL_TESTER_HOLD_MS;
  if (externalRecent) {
    writeEvent("WARNING", "TWAI_TRANSMIT_BLOCKED", String(source) + "; external tester owns diagnostic bus");
    return false;
  }
  if (!diagnosticEnabled || !twaiNormalMode) {
    writeEvent("WARNING", "TWAI_TRANSMIT_BLOCKED", String(source) + "; passive mode active");
    return false;
  }
  twai_message_t message = {};
  message.identifier = identifier;
  message.extd = 0;
  message.rtr = 0;
  message.data_length_code = dlc;
  memcpy(message.data, data, dlc);
  if (externalTesterOwnsSession) { ++postLatchDiagnosticTxAttempts; return false; }
  esp_err_t result = twai_transmit(&message, pdMS_TO_TICKS(20));
  if (result != ESP_OK) {
    writeEvent("ERROR", "TWAI_TRANSMIT_FAILED", String(identifier, HEX) + ",err=" + String((int)result));
    return false;
  }
  if (externalTesterOwnsSession) ++postLatchDiagnosticTxFrames;

  ++transmittedFrameCount;
  CapturedFrame frame = {};
  frame.timeUs = nowMicros64();
  frame.identifier = identifier;
  frame.dlc = dlc;
  frame.direction = 1;
  memcpy(frame.data, data, dlc);
  (void)source;
  if (xQueueSend(canQueue, &frame, 0) != pdTRUE) ++canQueueDrops;
  return true;
}


// ---------------- Passive external diagnostic observer (v2.4.3) -------------
static bool profileNameMatches(const char *name, VehicleProfile profile) {
  if (!name) return false;
  if (profile == PROFILE_PRIUS_GEN2) return strcmp(name, "PRIUS_GEN2") == 0;
  if (profile == PROFILE_PRIUS_PHV_GEN1) return strcmp(name, "PRIUS_PHV_GEN1") == 0;
  if (profile == PROFILE_CAMRY_HYBRID_GEN1) return strcmp(name, "CAMRY_HYBRID_GEN1") == 0;
  return false;
}

const DbRuntimeSignal *findRuntimeSignal(uint32_t requestId, uint32_t responseId, uint8_t service, uint8_t pid) {
  const DbRuntimeSignal *fallback = nullptr;
  uint8_t fallbackCount = 0;
  for (size_t i = 0; i < DB_RUNTIME_SIGNAL_COUNT; ++i) {
    const DbRuntimeSignal &d = DB_RUNTIME_SIGNALS[i];
    bool requestMatch = d.requestId == requestId || (requestId == 0x7DF && d.responseId == responseId);
    if (!requestMatch || d.responseId != responseId || d.service != service || d.pid != pid) continue;
    if (profileNameMatches(d.profile, vehicleProfile)) return &d;
    fallback = &d;
    ++fallbackCount;
  }
  return fallbackCount == 1 ? fallback : nullptr;
}

static const char *catalogGrade(uint32_t requestId, uint32_t responseId, uint8_t service, uint8_t pid) {
  for (size_t i = 0; i < DB_V055_DIAGNOSTIC_CATALOG_COUNT; ++i) {
    const DbDiagnosticCatalogEntry &d = DB_V055_DIAGNOSTIC_CATALOG[i];
    bool requestMatch = d.requestId == requestId || (requestId == 0x7DF && d.responseId == responseId);
    if (!requestMatch || d.responseId != responseId || d.service != service) continue;
    if (d.hasPid && (pid < d.pidStart || pid > d.pidEnd)) continue;
    if (strcmp(d.safetyClass, "CONTROL_WRITE_QUARANTINED") == 0) return "QUARANTINED";
    return d.grade;
  }
  for (size_t i = 0; i < DB_S0047_OBSERVED_DIAGNOSTIC_CANDIDATE_COUNT; ++i) {
    const DbObservedDiagnosticCandidate &d = DB_S0047_OBSERVED_DIAGNOSTIC_CANDIDATES[i];
    if (d.requestId == requestId && d.responseId == responseId && d.service == service &&
        (!d.hasPid || d.pid == pid)) return d.grade;
  }
  return "UNKNOWN";
}

void applyDatabaseProfileEvidence(VehicleProfile profile, uint8_t confidence, bool authoritative, const char *source) {
  if (profile == PROFILE_SCANNING || profile == PROFILE_UNKNOWN) return;
  bool changed = vehicleProfile != profile || profileConfidence < confidence ||
                 (authoritative && !databaseProfileAuthoritative);
  databaseProfileHint = profile;
  databaseProfileHintConfidence = confidence;
  databaseProfileHintMs = millis();
  if (authoritative) databaseProfileAuthoritative = true;
  if (changed) {
    const bool profileChanged = vehicleProfile != profile;
    if (profileChanged) revokeControlAuthorization("DATABASE_PROFILE_CHANGE");
    if (profileChanged) live.fuelValid = false; // Raw scale is vehicle-specific.
    vehicleProfile = profile;
    profileConfidence = confidence;
    writeEvent("INFO", "DATABASE_PROFILE_EVIDENCE",
               String(source ? source : "runtime") + ";profile=" + profileLabel(profile) +
               ";confidence=" + String(confidence) + (authoritative ? ";authoritative=1" : ";authoritative=0"));
    if (diagnosticEnabled) {
      if (authoritative && profileSupportsActiveDiagnostics(vehicleProfile))
        diagnosticIdentityVerified = true;
      else if (!diagnosticCanBeEnabledForProfile(vehicleProfile))
        setDiagnosticCapture(false, "Database profile evidence is outside supported read-only plans");
    }
  }
}

void recomputeBlockSummary() {
  if (live.blockCount == 0 || live.blockCount > MAX_HV_BLOCKS) return;
  float minV = live.blockVolts[0];
  float maxV = live.blockVolts[0];
  uint8_t minIndex = 0;
  uint8_t maxIndex = 0;
  for (uint8_t i = 1; i < live.blockCount; ++i) {
    if (live.blockVolts[i] < minV) { minV = live.blockVolts[i]; minIndex = i; }
    if (live.blockVolts[i] > maxV) { maxV = live.blockVolts[i]; maxIndex = i; }
  }
  live.blockMinV = minV;
  live.blockMaxV = maxV;
  live.blockMinNumber = minIndex + 1;
  live.blockMaxNumber = maxIndex + 1;
  live.blockDeltaV = maxV - minV;
}

static void noteExternalDefinition(uint32_t requestId, uint32_t responseId, uint8_t service, uint8_t pid,
                                   uint16_t payloadLength, const DbRuntimeSignal *definition) {
  externalObserverLastMs = millis();
  externalObserverLastRequestId = requestId;
  externalObserverLastResponseId = responseId;
  externalObserverLastService = service;
  externalObserverLastPid = pid;
  externalObserverLastLength = payloadLength;
  externalObserverLastGrade = definition ? definition->grade : catalogGrade(requestId, responseId, service, pid);
  externalObserverLastKey = definition ? definition->key : "CATALOG/RAW";
  if (strcmp(externalObserverLastGrade, "CONFIRMED") == 0 || strcmp(externalObserverLastGrade, "FIELD_SPECIFIC") == 0)
    ++externalObserverDecodedConfirmed;
  else if (strcmp(externalObserverLastGrade, "PROBABLE") == 0)
    ++externalObserverDecodedProbable;
  else if (strcmp(externalObserverLastGrade, "CANDIDATE") == 0)
    ++externalObserverCandidateHits;
  else
    ++externalObserverUnknown;
}

static bool passiveMetricFresh(bool valid, uint32_t stampMs, uint32_t nowMs, uint32_t maxAgeMs) {
  return valid && (uint32_t)(nowMs - stampMs) <= maxAgeMs;
}

static void refreshElectricalAggregate(uint32_t nowMs) {
  const bool vFresh = live.packVoltageValid && (uint32_t)(nowMs - live.packVoltageMs) <= DIAGNOSTIC_DISPLAY_FRESH_MS;
  const bool iFresh = live.packCurrentValid && (uint32_t)(nowMs - live.packCurrentMs) <= DIAGNOSTIC_DISPLAY_FRESH_MS;
  live.electricalValid = vFresh && iFresh;
  if (live.electricalValid) {
    live.electricalMs = (live.packVoltageMs < live.packCurrentMs) ? live.packVoltageMs : live.packCurrentMs;
    live.packKW = live.packVolts * live.packAmps / 1000.0f;
  }
}

static void refreshMgAggregate(uint32_t nowMs) {
  const bool m1 = live.mg1RPMValid && (uint32_t)(nowMs - live.mg1RPMMs) <= DIAGNOSTIC_DISPLAY_FRESH_MS;
  const bool m2 = live.mg2RPMValid && (uint32_t)(nowMs - live.mg2RPMMs) <= DIAGNOSTIC_DISPLAY_FRESH_MS;
  live.mgPowertrainValid = m1 && m2;
  if (live.mgPowertrainValid) live.mgPowertrainMs = (live.mg1RPMMs < live.mg2RPMMs) ? live.mg1RPMMs : live.mg2RPMMs;
}

static bool containsAsciiToken(const uint8_t *data, uint16_t length, const char *token) {
  if (!data || !token) return false;
  size_t tokenLen = strlen(token);
  if (tokenLen == 0 || length < tokenLen) return false;
  for (uint16_t i = 0; i + tokenLen <= length; ++i)
    if (memcmp(&data[i], token, tokenLen) == 0) return true;
  return false;
}

void decodeRuntimeSignal(const DbRuntimeSignal &definition, const uint8_t *d, uint16_t n) {
  uint32_t nowMs = millis();
  switch (definition.decoder) {
    case DBR_MODE01_RPM:
      if (n >= 2 && !passiveMetricFresh(live.passiveEngineRPMValid, live.passiveEngineRPMMs, nowMs)) { live.engineRPM = wordBE(d[0], d[1]) / 4; live.engineRPMMs = nowMs; live.engineRPMValid = true; }
      break;
    case DBR_MODE01_COOLANT:
      if (n >= 1 && !passiveMetricFresh(live.passiveCoolantValid, live.passiveCoolantMs, nowMs)) { live.engineCoolantF = (d[0] - 40.0f) * 1.8f + 32.0f; live.coolantMs = nowMs; live.coolantValid = true; }
      break;
    case DBR_MODE01_INTAKE:
      if (n >= 1 && !passiveMetricFresh(live.passiveIntakeValid, live.passiveIntakeMs, nowMs)) { live.engineIntakeAirF = (d[0] - 40.0f) * 1.8f + 32.0f; live.engineIntakeMs = nowMs; live.engineIntakeValid = true; }
      break;
    case DBR_MODE01_CATALYST:
      if (n >= 2) { live.catalystB1S1F = (wordBE(d[0], d[1]) / 10.0f - 40.0f) * 1.8f + 32.0f; live.catalystMs = nowMs; live.catalystValid = true; }
      break;
    case DBR_CATALYST_B1S2:
      if (n >= 2) { live.catalystB1S2F = (wordBE(d[0], d[1]) / 10.0f - 40.0f) * 1.8f + 32.0f; live.catalystB1S2Ms = nowMs; live.catalystB1S2Valid = true; }
      break;
    case DBR_GEN2_C3:
      // S0070 Autel AP200 independently CONFIRMED NHW20 C3 MG1/MG2 RPM,
      // MG1/MG2 torque, and the individual motor/inverter temperature labels.
      // Engine speed at bytes 14-15 remains CONFIRMED from S0034.
      if (n >= 28) {
        if (!passiveMetricFresh(live.passiveMg2RPMValid, live.passiveMg2RPMMs, nowMs)) { live.mg2RPM = (int32_t)wordBE(d[0], d[1]) - 16383; live.mg2RPMMs = nowMs; live.mg2RPMValid = true; }
        live.mg2TorqueNm = ((int32_t)wordBE(d[2], d[3]) - 4000) / 8.0f; live.mg2TorqueMs = nowMs; live.mg2TorqueValid = true;
        live.mg1RPM = (int32_t)wordBE(d[6], d[7]) - 16383; live.mg1RPMMs = nowMs; live.mg1RPMValid = true;
        if (!passiveMetricFresh(live.passiveMg1TorqueValid, live.passiveMg1TorqueMs, nowMs)) { live.mg1TorqueNm = ((int32_t)wordBE(d[8], d[9]) - 4000) / 8.0f; live.mg1TorqueMs = nowMs; live.mg1TorqueValid = true; live.mg1TorqueProbable = false; }
        if (!passiveMetricFresh(live.passiveEngineRPMValid, live.passiveEngineRPMMs, nowMs)) { live.engineRPM = wordBE(d[14], d[15]); live.engineRPMMs = nowMs; live.engineRPMValid = true; }
        refreshMgAggregate(nowMs);
        // Current v0.9.50 field order: Y=MG1 inverter, Z=MG2 inverter,
        // AA=MG1 motor, AB=MG2 motor; each raw-50 C.
        live.mg1InvF = 1.8f * d[24] - 58.0f;
        live.mg2InvF = 1.8f * d[25] - 58.0f;
        live.mg1StatorF = 1.8f * d[26] - 58.0f;
        live.mg2StatorF = 1.8f * d[27] - 58.0f;
        live.c3Ms = nowMs; live.c3Valid = true;
        live.mgPowertrainMs = nowMs; live.mgPowertrainValid = true;
        live.inverterTempMs = nowMs; live.inverterTempValid = true;
        live.motorTempMs = nowMs; live.motorTempValid = true;
      }
      break;
    case DBR_GEN2_C4:
      // S0070 CONFIRMED converter temperature at byte F (zero-based d[5]).
      if (n >= 6) {
        live.converterTempF = 1.8f * d[5] - 58.0f;
        live.c4Ms = nowMs; live.c4Valid = true;
      }
      break;
    case DBR_GEN2_AUX_V:
      if (n >= 2) { live.auxVolts = wordBE(d[0], d[1]) / 1000.0f; live.auxVoltsMs = nowMs; live.auxVoltsValid = true; }
      break;
    case DBR_GEN2_RUNTIME:
      if (n >= 2) { live.engineRunTimeS = wordBE(d[0], d[1]); live.engineRunTimeMs = nowMs; live.engineRunTimeValid = true; }
      break;
    case DBR_GEN2_CE:
      if (n >= 31) { decodeCE(d, n); applyDatabaseProfileEvidence(PROFILE_PRIUS_GEN2, 90, false, "NHW20 21CE/14 blocks"); }
      break;
    case DBR_GEN2_CF:
      // Latest boundary: T1-T3 and fan are confirmed; intake is PROBABLE.
      // Do not promote unrelated CF aux/delta semantics merely because the PID
      // contains confirmed fields.
      if (n >= 16) {
        live.intakeTempF = rawTemperatureF(d[0], d[1]);
        live.batteryFanMonitorV1 = (d[2] - 128.0f) * 0.2f;
        live.batteryFanMonitorV2 = 0.0f;
        live.batteryFanMonitorMs = nowMs; live.batteryFanMonitorCount = 1;
        live.batteryFanMonitorValid = true; live.batteryFanMonitorProbable = false;
        live.fanLevel = d[8];
        live.hvTemp1F = rawTemperatureF(d[10], d[11]);
        live.hvTemp2F = rawTemperatureF(d[12], d[13]);
        live.hvTemp3F = rawTemperatureF(d[14], d[15]);
        live.hvAvgF = (live.hvTemp1F + live.hvTemp2F + live.hvTemp3F) / 3.0f;
        live.intakeTempsF[0] = live.intakeTempF; live.intakeTempCount = 1;
        live.batteryTempsF[0] = live.hvTemp1F; live.batteryTempsF[1] = live.hvTemp2F; live.batteryTempsF[2] = live.hvTemp3F;
        live.batteryTempCount = 3;
        live.cfMs = nowMs; live.cfValid = true;
        live.batteryTempMs = nowMs; live.batteryTempValid = true;
      }
      break;
    case DBR_GEN2_D0:
      // R1-R14 are confirmed. Extrema/index semantics remain lower-grade, so
      // normal-page dV continues to be derived from the confirmed CE array.
      if (n >= 29) {
        live.blockCount = 14;
        for (uint8_t i = 0; i < 14; ++i) live.internalResistance[i] = d[15 + i] * 0.001f;
        live.d0Ms = nowMs; live.d0Valid = true;
        live.resistanceMs = nowMs; live.resistanceValid = true;
      }
      break;

    case DBR_CAMRY_CE: {
      if (n < 37) break;
      live.socPct = d[0] * 0.5f;
      live.packAmps = wordBE(d[1], d[2]) / 100.0f - 327.68f;
      live.packCurrentMs = nowMs; live.packCurrentValid = true;
      float sum = 0.0f;
      for (uint8_t i = 0; i < 17; ++i) {
        uint8_t p = 3 + i * 2;
        live.blockVolts[i] = (wordBE(d[p], d[p + 1]) - 32768.0f) * 0.01f;
        sum += live.blockVolts[i];
      }
      live.blockCount = 17;
      if (!passiveMetricFresh(live.passivePackVoltageValid, live.passivePackVoltageMs, nowMs)) { live.packVolts = sum; live.packVoltageMs = nowMs; live.packVoltageValid = true; }
      refreshElectricalAggregate(nowMs);
      recomputeBlockSummary();
      live.socMs = nowMs; live.socValid = true;
      live.blockVoltageMs = nowMs; live.blockVoltageValid = true;
      live.ceMs = nowMs; live.ceValid = true;
      applyDatabaseProfileEvidence(PROFILE_CAMRY_HYBRID_GEN1, 90, false, "AHV40 21CE/17 blocks");
      break;
    }
    case DBR_CAMRY_D0:
      if (n >= 32) {
        live.blockCount = 17;
        for (uint8_t i = 0; i < 17; ++i) live.internalResistance[i] = d[15 + i] * 0.001f;
        live.resistanceMs = nowMs; live.resistanceValid = true;
        live.d0Ms = nowMs; live.d0Valid = true;
      }
      break;
    case DBR_CAMRY_C3:
      if (n >= 22) {
        // CONFIRMED AHV40 temperature fields.
        live.mg1InvF = (d[18] - 50.0f) * 1.8f + 32.0f;
        live.mg2InvF = (d[19] - 50.0f) * 1.8f + 32.0f;
        live.mg1StatorF = (d[20] - 50.0f) * 1.8f + 32.0f;
        live.mg2StatorF = (d[21] - 50.0f) * 1.8f + 32.0f;
        // S0069 CONFIRMED AHV40 21C3 RPM layout using Autel MAXIAP200
        // screen-to-diagnostic correlation. Vehicle-specific AHV40 offsets;
        // do not substitute Prius Gen 2 21C3 offsets.
        //
        // MG2 RPM = BE16(d[0], d[1]) - 16383
        // MG1 RPM = BE16(d[4], d[5]) - 16383
        // Engine RPM = BE16(d[12], d[13])
        if (!passiveMetricFresh(live.passiveMg2RPMValid, live.passiveMg2RPMMs, nowMs)) { live.mg2RPM = (int32_t)wordBE(d[0], d[1]) - 16383; live.mg2RPMMs = nowMs; live.mg2RPMValid = true; }
        live.mg2TorqueNm = ((int32_t)wordBE(d[2], d[3]) - 4000) / 8.0f; live.mg2TorqueMs = nowMs; live.mg2TorqueValid = true;
        live.mg1RPM = (int32_t)wordBE(d[4], d[5]) - 16383; live.mg1RPMMs = nowMs; live.mg1RPMValid = true;
        live.mg1TorqueNm = ((int32_t)wordBE(d[6], d[7]) - 4000) / 8.0f;
        live.mg1TorqueMs = nowMs; live.mg1TorqueValid = true; live.mg1TorqueProbable = true;
        if (!passiveMetricFresh(live.passiveEngineRPMValid, live.passiveEngineRPMMs, nowMs)) { live.engineRPM = (int32_t)wordBE(d[12], d[13]); live.engineRPMMs = nowMs; live.engineRPMValid = true; }
        refreshMgAggregate(nowMs);
        live.c3Ms = nowMs;
        live.c3Valid = true;
        live.inverterTempMs = nowMs; live.inverterTempValid = true;
        live.motorTempMs = nowMs; live.motorTempValid = true;
      }
      break;
    case DBR_CAMRY_C4:
      if (n >= 6) {
        live.converterTempF = (d[5] - 50.0f) * 1.8f + 32.0f;
        live.c4Ms = nowMs; live.c4Valid = true;
      }
      break;
    case DBR_CAMRY_CF:
      if (n >= 18) {
        auto ftemp = [&](uint8_t p) { return ((wordBE(d[p], d[p+1]) - 32768.0f) / 100.0f) * 1.8f + 32.0f; };
        live.intakeTempF = ftemp(0); live.intakeTempsF[0] = live.intakeTempF; live.intakeTempCount = 1;
        live.batteryFanMonitorV1 = (d[2] - 128.0f) * 0.2f;
        live.batteryFanMonitorV2 = 0.0f;
        live.batteryFanMonitorMs = nowMs; live.batteryFanMonitorCount = 1;
        // S0229+S0230 MAX level6 response and observable VMF/mode feedback.
        live.batteryFanMonitorValid = true; live.batteryFanMonitorProbable = false;
        live.fanLevel = (d[8] >> 3) & 0x07; // AHV40 21CF B8 fan-mode ordinal.
        live.hvTemp1F = ftemp(10); live.hvTemp2F = ftemp(12); live.hvTemp3F = ftemp(14); live.hvTemp4F = ftemp(16);
        live.batteryTempsF[0] = live.hvTemp1F; live.batteryTempsF[1] = live.hvTemp2F;
        live.batteryTempsF[2] = live.hvTemp3F; live.batteryTempsF[3] = live.hvTemp4F; live.batteryTempCount = 4;
        live.hvAvgF = (live.hvTemp1F + live.hvTemp2F + live.hvTemp3F + live.hvTemp4F) / 4.0f;
        live.cfMs = nowMs; live.cfValid = true; live.batteryTempMs = nowMs; live.batteryTempValid = true;
      }
      break;
    case DBR_CAMRY_2105:
      if (n >= 1 && !passiveMetricFresh(live.passiveCoolantValid, live.passiveCoolantMs, nowMs)) { live.engineCoolantF = (d[0] - 40.0f) * 1.8f + 32.0f; live.coolantMs = nowMs; live.coolantValid = true; }
      break;
    case DBR_CAMRY_210F:
      if (n >= 1 && !passiveMetricFresh(live.passiveIntakeValid, live.passiveIntakeMs, nowMs)) { live.engineIntakeAirF = (d[0] - 40.0f) * 1.8f + 32.0f; live.engineIntakeMs = nowMs; live.engineIntakeValid = true; }
      break;
    case DBR_CAMRY_210C:
      if (n >= 2 && !passiveMetricFresh(live.passiveEngineRPMValid, live.passiveEngineRPMMs, nowMs)) { live.engineRPM = wordBE(d[0], d[1]) / 4; live.engineRPMMs = nowMs; live.engineRPMValid = true; }
      break;
    case DBR_CAMRY_211F:
      break;
    case DBR_CAMRY_FUEL_2129:
      // S0229 19 repeated screen anchors: raw 0x2B=43 -> Fuel Input 21.5 L.
      if (n >= 1 && vehicleProfile == PROFILE_CAMRY_HYBRID_GEN1) {
        live.fuelRaw = d[0]; live.fuelMs = nowMs; live.fuelValid = true;
      }
      break;

    case DBR_MODEL_SIGNATURE:
      if (containsAsciiToken(d, n, "ZVW35")) applyDatabaseProfileEvidence(PROFILE_PRIUS_PHV_GEN1, 100, true, "ZVW35 model signature");
      else if (containsAsciiToken(d, n, "AHV40L")) applyDatabaseProfileEvidence(PROFILE_CAMRY_HYBRID_GEN1, 100, true, "AHV40L model signature");
      break;

    case DBR_PHV_2101:
      if (n >= 22) {
        // CONFIRMED fields used normally.
        // Coolant and SOC are CONFIRMED 2101 fields and remain eligible fallbacks.
        if (!passiveMetricFresh(live.passiveCoolantValid, live.passiveCoolantMs, nowMs)) { live.engineCoolantF = (d[5] - 40.0f) * 1.8f + 32.0f; live.coolantMs = nowMs; live.coolantValid = true; }
        if (!passiveMetricFresh(live.passiveSocValid, live.passiveSocMs, nowMs)) { live.socPct = d[21] * 20.0f / 51.0f; live.socMs = nowMs; live.socValid = true; }
        // 2101 engine RPM and intake-air are PROBABLE. Confirmed passive 1C4/3CF
        // own the normal display, so these bytes remain evidence-only here.
      }
      break;
    case DBR_PHV_2161:
      if (n >= 1) {
        if (!passiveMetricFresh(live.passiveMotorTempValid, live.passiveMotorTempMs, nowMs)) { live.mg1StatorF = (d[0] - 40.0f) * 1.8f + 32.0f; live.motorTempMs = nowMs; live.motorTempValid = true; }
        if (n >= 5 && !passiveMetricFresh(live.passiveMg1RPMValid, live.passiveMg1RPMMs, nowMs)) { live.mg1RPM = (int32_t)wordBE(d[3], d[4]) - 32768; live.mg1RPMMs = nowMs; live.mg1RPMValid = true; refreshMgAggregate(nowMs); }
      }
      break;
    case DBR_PHV_2162:
      if (n >= 1) {
        if (!passiveMetricFresh(live.passiveMotorTempValid, live.passiveMotorTempMs, nowMs)) { live.mg2StatorF = (d[0] - 40.0f) * 1.8f + 32.0f; live.motorTempMs = nowMs; live.motorTempValid = true; }
        if (n >= 5 && !passiveMetricFresh(live.passiveMg2RPMValid, live.passiveMg2RPMMs, nowMs)) { live.mg2RPM = (int32_t)wordBE(d[3], d[4]) - 32768; live.mg2RPMMs = nowMs; live.mg2RPMValid = true; refreshMgAggregate(nowMs); }
      }
      break;
    case DBR_PHV_2167:
      if (n >= 4) {
        // Both command and execution are CONFIRMED in v0.9.50; use execution for the generic MG1 torque display.
        live.mg1TorqueNm = wordBE(d[2], d[3]) / 8.0f - 4096.0f;
        live.mg1TorqueMs = nowMs; live.mg1TorqueValid = true; live.mg1TorqueProbable = false;
      }
      break;
    case DBR_PHV_2168:
      if (n >= 2) {
        // MG2 command is CONFIRMED; execution remains PROBABLE, so normal display uses command.
        live.mg2TorqueNm = wordBE(d[0], d[1]) / 8.0f - 4096.0f;
        live.mg2TorqueMs = nowMs; live.mg2TorqueValid = true;
      }
      break;
    case DBR_PHV_2170:
      if (n >= 1 && !passiveMetricFresh(live.passiveInverterTempValid, live.passiveInverterTempMs, nowMs)) { live.mg1InvF = (d[0] - 40.0f) * 1.8f + 32.0f; live.inverterTempMs = nowMs; live.inverterTempValid = true; }
      break;
    case DBR_PHV_2171:
      if (n >= 1 && !passiveMetricFresh(live.passiveInverterTempValid, live.passiveInverterTempMs, nowMs)) { live.mg2InvF = (d[0] - 40.0f) * 1.8f + 32.0f; live.inverterTempMs = nowMs; live.inverterTempValid = true; }
      break;
    case DBR_PHV_2175:
      if (n >= 4) {
        live.inverterPumpRPM = wordBE(d[1], d[2]);
        if (!passiveMetricFresh(live.passiveInverterCoolantValid, live.passiveInverterCoolantMs, nowMs))
          live.inverterCoolantF = (d[3] - 40.0f) * 1.8f + 32.0f;
      }
      break;
    case DBR_PHV_2181:
      if (n >= 22) {
        float sum = 0.0f;
        for (uint8_t i = 0; i < 8; ++i) {
          live.blockVolts[i] = wordBE(d[i*2], d[i*2+1]) * 79.99f / 65535.0f;
          sum += live.blockVolts[i];
        }
        live.blockCount = 8;
        live.auxVolts = wordBE(d[16], d[17]) * 79.9f / 65535.0f - 40.0f;
        live.packVolts = wordBE(d[18], d[19]) / 10.0f;
        if (live.packVolts < 100.0f || live.packVolts > 400.0f) live.packVolts = sum;
        live.packVoltageMs = nowMs; live.packVoltageValid = true;
        live.batteryFanMonitorV1 = d[20] / 10.0f;
        live.batteryFanMonitorV2 = d[21] / 10.0f;
        live.batteryFanMonitorMs = nowMs; live.batteryFanMonitorCount = 2;
        live.batteryFanMonitorValid = true; live.batteryFanMonitorProbable = false;
        refreshElectricalAggregate(nowMs);
        recomputeBlockSummary();
        // 2181 confirms pack/block voltage but not pack current. Current
        // freshness is owned by 2198 so MAIN/HV cannot make a stale A value
        // look fresh merely because a new voltage response arrived.
        live.blockVoltageMs = nowMs; live.blockVoltageValid = true;
        applyDatabaseProfileEvidence(PROFILE_PRIUS_PHV_GEN1, 90, false, "ZVW35 2181/8 blocks");
      }
      break;
    case DBR_PHV_2187:
      if (n >= 32) {
        auto phvTempF = [&](uint8_t p) { return (wordBE(d[p], d[p+1]) * 255.9f / 65535.0f - 50.0f) * 1.8f + 32.0f; };
        live.intakeTempsF[0] = phvTempF(0);
        for (uint8_t i = 0; i < 12; ++i) live.batteryTempsF[i] = phvTempF(2 + i*2);
        live.intakeTempsF[1] = phvTempF(26); live.intakeTempsF[2] = phvTempF(28); live.intakeTempsF[3] = phvTempF(30);
        live.intakeTempCount = 4; live.batteryTempCount = 12;
        live.intakeTempF = live.intakeTempsF[0];
        live.hvTemp1F = live.batteryTempsF[0]; live.hvTemp2F = live.batteryTempsF[1]; live.hvTemp3F = live.batteryTempsF[2]; live.hvTemp4F = live.batteryTempsF[3];
        float sum = 0.0f; for (uint8_t i=0;i<12;++i) sum += live.batteryTempsF[i]; live.hvAvgF = sum / 12.0f;
        live.batteryTempMs = nowMs; live.batteryTempValid = true; live.cfMs = nowMs; live.cfValid = true;
      }
      break;
    case DBR_PHV_218A:
      if (n >= 4) { live.powerResourceCurrent1 = wordBE(d[0], d[1]) / 100.0f - 327.68f; live.powerResourceCurrent2 = wordBE(d[2], d[3]) / 100.0f - 327.68f; }
      break;
    case DBR_PHV_2192:
      if (n >= 7) {
        // S0062 confirms minimum block voltage and block count. The maximum
        // voltage and min/max block-number semantics failed direct OCR checks,
        // so they remain evidence-only and must not overwrite the confirmed
        // delta derived from the eight 2181 aggregate voltages.
        live.blockMinV = wordBE(d[0], d[1]) * 79.99f / 65535.0f;
        if (d[6] > 0 && d[6] <= MAX_HV_BLOCKS) live.blockCount = d[6];
      }
      break;
    case DBR_PHV_2195:
      if (n >= 8) {
        live.blockCount = 8;
        for (uint8_t i = 0; i < 8; ++i) live.internalResistance[i] = d[i] * 0.001f;
        live.resistanceMs = nowMs; live.resistanceValid = true; live.d0Ms = nowMs; live.d0Valid = true;
      }
      break;
    case DBR_PHV_2198:
      if (n >= 8) {
        if (!passiveMetricFresh(live.passivePackCurrentValid, live.passivePackCurrentMs, nowMs)) {
          live.packAmps = wordBE(d[0], d[1]) / 100.0f - 327.68f;
          live.packCurrentMs = nowMs; live.packCurrentValid = true;
        }
        live.chargeLimitKW = d[2] / 2.0f - 64.0f;
        live.dischargeLimitKW = d[3] / 2.0f - 64.0f;
        live.deltaSocPct = d[4] / 2.0f;
        live.socAfterIgPct = d[5] / 2.0f; live.socMaxPct = d[6] / 2.0f; live.socMinPct = d[7] / 2.0f;
        refreshElectricalAggregate(nowMs);
      }
      break;
    case DBR_ASCII_ONLY:
    case DBR_OBSERVE_ONLY:
    default:
      break;
  }
}

static void resetExternalObserverResponse(ExternalDiagObserver &o) {
  o.responseActive = false; o.expectedLength = 0; o.receivedLength = 0; o.nextSequence = 0;
}

static void configureExternalRequest(ExternalDiagObserver &o, uint32_t requestId, uint32_t responseId,
                                     const uint8_t *payload, uint8_t length, uint64_t timeUs) {
  memset(&o, 0, sizeof(o));
  if (length < 1) return;
  o.requestValid = true; o.requestId = requestId; o.responseId = responseId; o.service = payload[0];
  o.requestTimeUs = timeUs; o.lastActivityUs = timeUs;
  if ((o.service == 0x21 || o.service == 0x01 || o.service == 0x09 || o.service == 0x13) && length >= 2) {
    uint8_t maxPid = min((uint8_t)8, (uint8_t)(length - 1));
    if (o.service == 0x21) {
      o.pidCount = maxPid;
      for (uint8_t i = 0; i < o.pidCount; ++i) o.pids[i] = payload[i + 1];
    } else {
      o.pidCount = 1; o.pids[0] = payload[1];
    }
  }
}

void observeExternalDiagnosticFrame(const CapturedFrame &frame) {
  if (frame.direction != 0 || frame.extended || frame.rtr || frame.dlc == 0) return;
  uint8_t pciType = frame.data[0] >> 4;

  if (frame.identifier == 0x7DF || (frame.identifier >= 0x7E0 && frame.identifier <= 0x7E7)) {
    if (pciType != 0x0) return; // Requests used by current apps fit in a single ISO-TP frame.
    uint8_t length = frame.data[0] & 0x0F;
    if (length == 0 || length > 7 || length > frame.dlc - 1) return;
    ++externalObserverRequests;
    if (frame.identifier == 0x7DF) {
      memset(&externalFunctionalRequest, 0, sizeof(externalFunctionalRequest));
      externalFunctionalRequest.valid = true;
      externalFunctionalRequest.service = frame.data[1];
      externalFunctionalRequest.requestTimeUs = frame.timeUs;
      if (length >= 2) {
        externalFunctionalRequest.pidCount = 1;
        externalFunctionalRequest.pids[0] = frame.data[2];
      }
    } else {
      uint8_t slot = frame.identifier - 0x7E0;
      configureExternalRequest(externalObservers[slot], frame.identifier, frame.identifier + 8,
                               &frame.data[1], length, frame.timeUs);
    }
    return;
  }

  if (frame.identifier < 0x7E8 || frame.identifier > 0x7EF) return;
  uint8_t slot = frame.identifier - 0x7E8;
  ExternalDiagObserver &o = externalObservers[slot];
  if ((!o.requestValid || frame.timeUs < o.requestTimeUs ||
       frame.timeUs - o.requestTimeUs > EXTERNAL_OBSERVER_TIMEOUT_MS * 1000ULL) &&
      externalFunctionalRequest.valid && frame.timeUs >= externalFunctionalRequest.requestTimeUs &&
      frame.timeUs - externalFunctionalRequest.requestTimeUs <= EXTERNAL_OBSERVER_TIMEOUT_MS * 1000ULL) {
    uint8_t requestPayload[9] = {}; requestPayload[0] = externalFunctionalRequest.service;
    for (uint8_t i=0;i<externalFunctionalRequest.pidCount;++i) requestPayload[i+1]=externalFunctionalRequest.pids[i];
    configureExternalRequest(o, 0x7DF, frame.identifier, requestPayload,
                             1 + externalFunctionalRequest.pidCount, externalFunctionalRequest.requestTimeUs);
  }
  if (!o.requestValid || frame.timeUs < o.requestTimeUs) return;
  o.lastActivityUs = frame.timeUs;

  if (pciType == 0x0) {
    uint8_t length = frame.data[0] & 0x0F;
    if (length > 7 || length > frame.dlc - 1 || length > sizeof(o.payload)) { ++externalObserverReassemblyErrors; return; }
    memcpy(o.payload, &frame.data[1], length); o.receivedLength = length; o.expectedLength = length;
    completeExternalDiagnosticResponse(o); resetExternalObserverResponse(o); return;
  }
  if (pciType == 0x1) {
    uint16_t expected = ((uint16_t)(frame.data[0] & 0x0F) << 8) | frame.data[1];
    if (expected <= 7 || expected > sizeof(o.payload) || frame.dlc < 8) { ++externalObserverReassemblyErrors; resetExternalObserverResponse(o); return; }
    o.responseActive = true; o.expectedLength = expected; o.receivedLength = min((uint16_t)6, expected);
    memcpy(o.payload, &frame.data[2], o.receivedLength); o.nextSequence = 1; return;
  }
  if (pciType == 0x2 && o.responseActive) {
    uint8_t sequence = frame.data[0] & 0x0F;
    if (sequence != o.nextSequence) { ++externalObserverReassemblyErrors; resetExternalObserverResponse(o); return; }
    o.nextSequence = (o.nextSequence + 1) & 0x0F;
    uint16_t remaining = o.expectedLength - o.receivedLength;
    uint16_t count = min((uint16_t)7, remaining);
    memcpy(&o.payload[o.receivedLength], &frame.data[1], count); o.receivedLength += count;
    if (o.receivedLength >= o.expectedLength) { completeExternalDiagnosticResponse(o); resetExternalObserverResponse(o); }
  }
}

void completeExternalDiagnosticResponse(ExternalDiagObserver &o) {
  ++externalObserverCompleted;
  if (o.receivedLength == 0) return;
  uint8_t positiveService = o.service + 0x40;
  if (o.payload[0] == 0x7F) return;
  if (o.payload[0] != positiveService) { ++externalObserverUnknown; return; }

  if (o.pidCount > 1 && o.service == 0x21) {
    uint16_t pos = 1;
    bool anyMatched = false;
    for (uint8_t i = 0; i < o.pidCount; ++i) {
      uint8_t pid = o.pids[i];
      if (pos >= o.receivedLength || o.payload[pos] != pid) { ++externalObserverReassemblyErrors; break; }
      const DbRuntimeSignal *def = findRuntimeSignal(o.requestId, o.responseId, o.service, pid);
      if (!def || def->expectedDataLength == 0 || pos + 1 + def->expectedDataLength > o.receivedLength) {
        noteExternalDefinition(o.requestId, o.responseId, o.service, pid, o.receivedLength, def);
        break;
      }
      noteExternalDefinition(o.requestId, o.responseId, o.service, pid, o.receivedLength, def);
      // When an external tester owns the bus, validated normal-display
      // definitions feed the same live decoder. CANDIDATE/observe-only rows
      // remain evidence-only because normalDisplay is false.
      if (def->normalDisplay && profileNameMatches(def->profile, vehicleProfile))
        decodeRuntimeSignal(*def, &o.payload[pos + 1], def->expectedDataLength);
      pos += 1 + def->expectedDataLength;
      anyMatched = true;
    }
    if (anyMatched) ++externalObserverBundledDecoded;
    return;
  }

  uint8_t pid = o.pidCount ? o.pids[0] : 0;
  uint16_t dataOffset = 1;
  if (o.pidCount) {
    if (o.receivedLength < 2 || o.payload[1] != pid) { ++externalObserverUnknown; return; }
    dataOffset = 2;
  }
  const DbRuntimeSignal *def = findRuntimeSignal(o.requestId, o.responseId, o.service, pid);

  // 7E0/21C1 is shared across Toyota hybrid platforms. Inspect the payload
  // regardless of the current heuristic profile so an externally observed
  // ZVW35 signature can correct the historical false AHV40 classification.
  if (o.service == 0x21 && pid == 0xC1) {
    const uint8_t *modelData = &o.payload[dataOffset];
    uint16_t modelLength = o.receivedLength - dataOffset;
    if (containsAsciiToken(modelData, modelLength, "ZVW35"))
      applyDatabaseProfileEvidence(PROFILE_PRIUS_PHV_GEN1, 100, true, "ZVW35 model signature");
    else if (containsAsciiToken(modelData, modelLength, "AHV40L"))
      applyDatabaseProfileEvidence(PROFILE_CAMRY_HYBRID_GEN1, 100, true, "AHV40L model signature");
    else if (containsAsciiToken(modelData, modelLength, "NHW20"))
      applyDatabaseProfileEvidence(PROFILE_PRIUS_GEN2,
        (nhw20VariantConfirmedBy529 && priusScore>=4 && camryScore<4) ? 100U : 95U,
        false, "NHW20 model signature");
    def = findRuntimeSignal(o.requestId, o.responseId, o.service, pid);
  }

  noteExternalDefinition(o.requestId, o.responseId, o.service, pid, o.receivedLength, def);
  // External tester values may refresh MAIN/TEMP/HV only when the tuple matches
  // the established vehicle profile and the runtime definition explicitly
  // permits normal display. Candidate/observe-only rows never reach live.*.
  if (def && def->normalDisplay && profileNameMatches(def->profile, vehicleProfile) &&
      dataOffset <= o.receivedLength)
    decodeRuntimeSignal(*def, &o.payload[dataOffset], o.receivedLength - dataOffset);
}

void serviceExternalDiagnosticObserver() {
  uint64_t nowUs = nowMicros64();
  for (uint8_t i = 0; i < 8; ++i) {
    ExternalDiagObserver &o = externalObservers[i];
    if (!o.requestValid) continue;
    if (nowUs >= o.lastActivityUs && nowUs - o.lastActivityUs > EXTERNAL_OBSERVER_TIMEOUT_MS * 1000ULL) {
      if (o.responseActive) ++externalObserverTimeouts;
      memset(&o, 0, sizeof(o));
    }
  }
  if (externalFunctionalRequest.valid && nowUs >= externalFunctionalRequest.requestTimeUs &&
      nowUs - externalFunctionalRequest.requestTimeUs > EXTERNAL_OBSERVER_TIMEOUT_MS * 1000ULL)
    externalFunctionalRequest.valid = false;
}

// --------------------------- Vehicle identification --------------------------
const char *profileLabel(VehicleProfile profile) {
  switch (profile) {
    case PROFILE_PRIUS_GEN2: return "PRIUS GEN 2";
    case PROFILE_PRIUS_GEN3: return "PRIUS GEN 3";
    case PROFILE_PRIUS_ALPHA_ZVW45: return "PRIUS ALPHA ZVW45";
    case PROFILE_PRIUS_PHV_GEN1: return "PRIUS PHV G1";
    case PROFILE_CAMRY_HYBRID_GEN1: return "CAMRY HYB G1";
    case PROFILE_PRIUS_GEN3_OR_PHV: return "GEN3/PHV AMBIG";
    case PROFILE_UNKNOWN: return "UNKNOWN";
    case PROFILE_CONFLICT: return "CONFLICT";
    default: return "SCANNING";
  }
}

void observeFingerprint(uint32_t identifier) {
  for (size_t i = 0; i < sizeof(PRIUS_G2_FINGERPRINT_IDS) / sizeof(uint16_t); ++i) {
    if (identifier == PRIUS_G2_FINGERPRINT_IDS[i] && !priusSeen[i]) {
      priusSeen[i] = true;
      ++priusScore;
    }
  }
  for (size_t i = 0; i < sizeof(CAMRY_AHV40_FINGERPRINT_IDS) / sizeof(uint16_t); ++i) {
    if (identifier == CAMRY_AHV40_FINGERPRINT_IDS[i] && !camrySeen[i]) {
      camrySeen[i] = true;
      ++camryScore;
    }
  }
}

void evaluateVehicleProfile() {
  const bool strongPrius=priusScore>=4;
  const bool strongCamry=camryScore>=4;
  if (strongPrius && !strongCamry && nhw20Variant==NHW20_VARIANT_UNKNOWN &&
      !gen2PersistFallbackChecked) {
    gen2PersistFallbackChecked=true;
    const Nhw20Variant prior=gen2PersistRecoverSoleVariant();
    if (prior!=NHW20_VARIANT_UNKNOWN) {
      nhw20Variant=prior;
      gen2PersistActivate(prior);
      Serial.printf("# GEN2 VARIANT,NVS_FALLBACK,%u,UNCONFIRMED\n",(unsigned)prior);
    }
  }
  if (databaseProfileAuthoritative) return;
  if (databaseProfileHint != PROFILE_SCANNING && millis() - databaseProfileHintMs < 30000 &&
      databaseProfileHintConfidence >= 90) {
    const uint8_t chosen = (databaseProfileHint==PROFILE_PRIUS_GEN2 &&
        nhw20VariantConfirmedBy529 && strongPrius && !strongCamry) ? 100U : databaseProfileHintConfidence;
    if (vehicleProfile != databaseProfileHint || profileConfidence != chosen) {
      vehicleProfile = databaseProfileHint;
      profileConfidence = chosen;
    }
    return;
  }
  VehicleProfile next = PROFILE_SCANNING;
  uint8_t confidence = 0;


  if (strongPrius && strongCamry) {
    next = PROFILE_CONFLICT;
  } else if (strongCamry) {
    next = PROFILE_CAMRY_HYBRID_GEN1;
    confidence = (uint8_t)min(95, 55 + (int)camryScore * 5);
  } else if (strongPrius) {
    next = PROFILE_PRIUS_GEN2;
    confidence = nhw20VariantConfirmedBy529 ? 100U : (uint8_t)min(85, 45 + (int)priusScore * 5);
  } else if (millis() - detectionStartedMs >= 10000) {
    next = PROFILE_UNKNOWN;
  }

  if (next != vehicleProfile || confidence != profileConfidence) {
    String details = String(profileLabel(vehicleProfile)) + " to " + profileLabel(next) +
                     ";P=" + String(priusScore) + ";C=" + String(camryScore) +
                     ";confidence=" + String(confidence);
    if (next != vehicleProfile) revokeControlAuthorization("PASSIVE_PROFILE_CHANGE");
    vehicleProfile = next;
    profileConfidence = confidence;
    writeEvent("INFO", "PROFILE_CHANGE", details);
    if (diagnosticEnabled && !diagnosticCanBeEnabledForProfile(vehicleProfile)) {
      setDiagnosticCapture(false, "Vehicle profile is outside supported read-only plans");
    }
  }
}

// --------------------------- Passive Gen 2 decoding --------------------------
uint16_t wordBE(uint8_t highByte, uint8_t lowByte) {
  return ((uint16_t)highByte << 8) | lowByte;
}

int16_t signExtend12(uint16_t raw) {
  raw &= 0x0FFF;
  return (raw & 0x0800) ? (int16_t)(raw | 0xF000) : (int16_t)raw;
}

float rawTemperatureF(uint8_t highByte, uint8_t lowByte) {
  return wordBE(highByte, lowByte) * 9.0f / 500.0f - 557.824f;
}

void parsePassiveGen2(const CapturedFrame &frame) {
  if (!ENABLE_GEN2_PASSIVE_CONFIRMED) return;
  const uint32_t nowMs = millis();
  constexpr float KMH_TO_MPH = 0.621371192f;

  if (frame.identifier == 0x0B4 && frame.dlc >= 7) {
    setValidatedVehicleSpeedMph(wordBE(frame.data[5], frame.data[6]) * 10.0f / 1024.0f * KMH_TO_MPH, nowMs);
  }
  if (frame.identifier == 0x0B1 && frame.dlc >= 4) {
    gen2FrontRightMph = wordBE(frame.data[0], frame.data[1]) / 100.0f * KMH_TO_MPH;
    gen2FrontLeftMph = wordBE(frame.data[2], frame.data[3]) / 100.0f * KMH_TO_MPH;
    gen2FrontWheelMs = nowMs; gen2FrontWheelValid = true;
    if (gen2RearWheelValid && nowMs - gen2RearWheelMs <= 250U) {
      setValidatedWheelSpeedsMph(gen2FrontLeftMph, gen2FrontRightMph, gen2RearLeftMph, gen2RearRightMph, nowMs);
      live.wheelPositionProbable = false;
    }
  }
  if (frame.identifier == 0x0B3 && frame.dlc >= 4) {
    gen2RearRightMph = wordBE(frame.data[0], frame.data[1]) / 100.0f * KMH_TO_MPH;
    gen2RearLeftMph = wordBE(frame.data[2], frame.data[3]) / 100.0f * KMH_TO_MPH;
    gen2RearWheelMs = nowMs; gen2RearWheelValid = true;
    if (gen2FrontWheelValid && nowMs - gen2FrontWheelMs <= 250U) {
      setValidatedWheelSpeedsMph(gen2FrontLeftMph, gen2FrontRightMph, gen2RearLeftMph, gen2RearRightMph, nowMs);
      live.wheelPositionProbable = false;
    }
  }
  if (frame.identifier == 0x120 && frame.dlc >= 6 && frame.data[5] >= 0x10 && frame.data[5] <= 0x14) {
    live.gearCode = frame.data[5] - 0x10; live.gearMs = nowMs; live.gearValid = true;
  }
  if (frame.identifier == 0x3C8 && frame.dlc >= 3) {
    live.engineRPM = frame.data[2] * 32; live.engineRPMMs = nowMs; live.engineRPMValid = true;
    live.passiveEngineRPMMs = nowMs; live.passiveEngineRPMValid = true;
  }
  if (frame.identifier == 0x039 && frame.dlc >= 1) {
    live.engineCoolantF = frame.data[0] * 1.8f + 32.0f; live.coolantMs = nowMs; live.coolantValid = true;
    live.passiveCoolantMs = nowMs; live.passiveCoolantValid = true;
  }
  if (frame.identifier == 0x3CF && frame.dlc >= 3) {
    live.engineIntakeAirF = frame.data[2] * 1.8f + 32.0f; live.engineIntakeMs = nowMs; live.engineIntakeValid = true;
    live.passiveIntakeMs = nowMs; live.passiveIntakeValid = true;
  }
  if (frame.identifier == 0x244 && frame.dlc >= 6) {
    live.mg2RPM = (int16_t)wordBE(frame.data[4], frame.data[5]); live.mg2RPMMs = nowMs; live.mg2RPMValid = true;
    live.passiveMg2RPMMs = nowMs; live.passiveMg2RPMValid = true; refreshMgAggregate(nowMs);
  }
  if (frame.identifier == 0x348 && frame.dlc >= 5) {
    uint16_t raw10 = ((uint16_t)(frame.data[3] & 0x03) << 8) | frame.data[4];
    int16_t signed10 = (raw10 & 0x0200) ? (int16_t)(raw10 | 0xFC00) : (int16_t)raw10;
    live.mg1TorqueNm = -(5.0f/18.0f) * signed10; live.mg1TorqueMs = nowMs; live.mg1TorqueValid = true;
    live.passiveMg1TorqueMs = nowMs; live.passiveMg1TorqueValid = true; live.mg1TorqueProbable = false;
  }
  if (frame.identifier == 0x03B && frame.dlc == 5) {
    int16_t rawCurrent = signExtend12(((uint16_t)(frame.data[0] & 0x0F) << 8) | frame.data[1]);
    const float amps = rawCurrent * 0.1f;
    const float volts = wordBE(frame.data[2], frame.data[3]);
    if (amps >= -500.0f && amps <= 500.0f && volts >= 100.0f && volts <= 400.0f) {
      live.packAmps = amps; live.packCurrentMs = nowMs; live.packCurrentValid = true; live.passivePackCurrentMs = nowMs; live.passivePackCurrentValid = true;
      live.packVolts = volts; live.packVoltageMs = nowMs; live.packVoltageValid = true; live.passivePackVoltageMs = nowMs; live.passivePackVoltageValid = true;
      live.passiveElectricalMs = nowMs; live.passiveElectricalValid = true; refreshElectricalAggregate(nowMs);
    }
  }
  if (frame.identifier == 0x3CB && frame.dlc == 7) {
    const float soc = frame.data[3] * 0.5f;
    if (soc <= 100.0f) {
      live.socPct = soc; live.socMs = nowMs; live.socValid = true;
      live.passiveSocMs = nowMs; live.passiveSocValid = true;
      live.passiveSocTempMs = nowMs; live.passiveSocTempValid = true;
    }
  }
  if (frame.identifier == 0x529) {
    if (frame.dlc == 6 || frame.dlc == 7) {
      const Nhw20Variant found = frame.dlc == 6 ? NHW20_VARIANT_0405 : NHW20_VARIANT_0609;
      nhw20VariantConfirmedBy529 = true;
      nhw20Variant=found;
      gen2PersistActivate(found);
    }
  }
  if (frame.identifier == 0x5A4 && frame.dlc >= 2 && frame.data[1] <= 40U) {
    live.fuelRaw=frame.data[1]; live.fuelMs=nowMs; live.fuelValid=true;
    gen2PersistFuel(live.fuelRaw);
  }
  if (frame.identifier == 0x230 && frame.dlc >= 2) {
    const uint16_t counter = wordBE(frame.data[0], frame.data[1]);
    if (nhw20RunCounterPriorValid) {
      const uint16_t delta = runtimeCounterDelta16(counter, nhw20RunCounterPrior);
      // A legitimate 0x230 cadence delta is tiny. Reject a vehicle power-cycle reset
      // masquerading as a 16-bit wrap rather than adding ~655 m spuriously.
      if (delta <= 5000U) {
        const double deltaMiles=runtimeMetersToMiles(delta * 0.01);
        live.runDistanceMiles += deltaMiles;
        gen2PersistDistance(deltaMiles);
      }
    }
    nhw20RunCounterPrior = counter; nhw20RunCounterPriorValid = true;
    live.runDistanceMs = nowMs; live.runDistanceValid = true;
  }
  if (frame.identifier == 0x53F && frame.dlc >= 4 && nhw20Variant == NHW20_VARIANT_0609) {
    live.odometerMiles = runtimeOdometer24(frame.data[1], frame.data[2], frame.data[3]);
    live.odometerMs=nowMs; live.odometerValid=true; live.odometerProbable=false;
    gen2PersistCanOdo(live.odometerMiles);
  }
}

// ---------------------- Passive Camry AHV40 confirmed sources ----------------------
// These read-only sources are profile-gated to AHV40 and reflect current CONFIRMED carrier/scale evidence.
// Wheel corner labels remain PROBABLE and are marked on-screen.
const char *gearLabel(uint8_t gearCode) {
  switch (gearCode) {
    case 0: return "P";
    case 1: return "R";
    case 2: return "N";
    case 3: return "D";
    case 4: return "B";
    default: return "?";
  }
}

void parsePassiveCamry(const CapturedFrame &frame) {
  if (!ENABLE_CAMRY_AHV40_PASSIVE_CONFIRMED) return;
  const uint32_t nowMs = millis();
  constexpr float KMH_TO_MPH = 0.621371192f;

  if (frame.identifier == 0x120 && frame.dlc >= 6 && frame.data[5] >= 0x10 && frame.data[5] <= 0x14) {
    live.gearCode = frame.data[5] - 0x10; live.gearMs = nowMs; live.gearValid = true;
    live.camryGearMs = nowMs; live.camryGearValid = true;
  }
  if (frame.identifier == 0x0B4 && frame.dlc >= 7) {
    setValidatedVehicleSpeedMph(wordBE(frame.data[5], frame.data[6]) * 10.0f / 1024.0f * KMH_TO_MPH, nowMs);
  } else if (frame.identifier == 0x610 && frame.dlc >= 3 && (!live.vehicleSpeedValid || nowMs - live.vehicleSpeedMs > 500U)) {
    setValidatedVehicleSpeedMph(frame.data[2] * KMH_TO_MPH, nowMs);
  }
  if (frame.identifier == 0x0B0 && frame.dlc >= 4) {
    camryFrontRightMph = wordBE(frame.data[0],frame.data[1]) / 100.0f * KMH_TO_MPH;
    camryFrontLeftMph = wordBE(frame.data[2],frame.data[3]) / 100.0f * KMH_TO_MPH;
    camryFrontWheelMs=nowMs; camryFrontWheelValid=true;
    if (camryRearWheelValid && nowMs-camryRearWheelMs<=250U) { setValidatedWheelSpeedsMph(camryFrontLeftMph,camryFrontRightMph,camryRearLeftMph,camryRearRightMph,nowMs); live.wheelPositionProbable=true; }
  }
  if (frame.identifier == 0x0B2 && frame.dlc >= 4) {
    camryRearRightMph = wordBE(frame.data[0],frame.data[1]) / 100.0f * KMH_TO_MPH;
    camryRearLeftMph = wordBE(frame.data[2],frame.data[3]) / 100.0f * KMH_TO_MPH;
    camryRearWheelMs=nowMs; camryRearWheelValid=true;
    if (camryFrontWheelValid && nowMs-camryFrontWheelMs<=250U) { setValidatedWheelSpeedsMph(camryFrontLeftMph,camryFrontRightMph,camryRearLeftMph,camryRearRightMph,nowMs); live.wheelPositionProbable=true; }
  }
  if (frame.identifier == 0x2C4 && frame.dlc >= 2) {
    live.engineRPM = (int32_t)((uint32_t)wordBE(frame.data[0],frame.data[1]) * 25U / 32U); live.engineRPMMs=nowMs; live.engineRPMValid=true;
    live.passiveEngineRPMMs=nowMs; live.passiveEngineRPMValid=true; live.camryEngineMs=nowMs; live.camryEngineValid=true;
  }
  if (frame.identifier == 0x3C1 && frame.dlc >= 3) {
    const float c = (frame.data[2] * 5U) / 8U; live.engineCoolantF=c*1.8f+32.0f; live.coolantMs=nowMs; live.coolantValid=true;
    live.passiveCoolantMs=nowMs; live.passiveCoolantValid=true; live.camryCoolantMs=nowMs; live.camryCoolantValid=true;
  }
  if (frame.identifier == 0x3CF && frame.dlc >= 3) {
    live.engineIntakeAirF=frame.data[2]*1.8f+32.0f; live.engineIntakeMs=nowMs; live.engineIntakeValid=true; live.passiveIntakeMs=nowMs; live.passiveIntakeValid=true;
  }
  if (frame.identifier == 0x244 && frame.dlc >= 6) {
    live.mg2RPM=(int16_t)wordBE(frame.data[4],frame.data[5]); live.mg2RPMMs=nowMs; live.mg2RPMValid=true; live.passiveMg2RPMMs=nowMs; live.passiveMg2RPMValid=true; refreshMgAggregate(nowMs);
  }
  if (frame.identifier == 0x38B && frame.dlc >= 6) {
    live.packVolts = 17.0f * (frame.data[5] + 43.0f) / 8.0f; live.packVoltageMs=nowMs; live.packVoltageValid=true; live.passivePackVoltageMs=nowMs; live.passivePackVoltageValid=true; refreshElectricalAggregate(nowMs);
  }
  if (frame.identifier == 0x611 && frame.dlc >= 8) {
    live.odometerMiles = runtimeOdometer20(frame.data[5], frame.data[6], frame.data[7]);
    live.odometerMs = nowMs; live.odometerValid = true; live.odometerProbable = false;
  }
}

void parsePassivePhv(const CapturedFrame &frame) {
  if (!ENABLE_PHV_PASSIVE_CONFIRMED) return;
  const uint32_t nowMs = millis();
  constexpr float KMH_TO_MPH = 0.621371192f;

  if (frame.identifier == 0x612 && frame.dlc >= 6) {
    // S0228 raw26 and S0231 raw34 both occurred with two dash bars.
    // Preserve raw fuel-sender code, do NOT infer a dashboard bar/percent scale.
    live.fuelRaw = frame.data[5]; live.fuelMs = nowMs; live.fuelValid = true;
  }

  if (frame.identifier == 0x0B4 && frame.dlc >= 7) {
    setValidatedVehicleSpeedMph(wordBE(frame.data[5],frame.data[6]) * 10.0f / 1024.0f * KMH_TO_MPH, nowMs);
  }
  if (frame.identifier == 0x0AA && frame.dlc >= 8) {
    uint16_t w[4]; for (uint8_t i=0;i<4;++i) w[i]=wordBE(frame.data[i*2],frame.data[i*2+1]);
    bool ok=true; for(uint8_t i=0;i<4;++i) if(w[i]<0x1A6F) ok=false;
    if(ok) {
      const float fr=(w[0]-0x1A6F)/100.0f*KMH_TO_MPH, fl=(w[1]-0x1A6F)/100.0f*KMH_TO_MPH;
      const float rr=(w[2]-0x1A6F)/100.0f*KMH_TO_MPH, rl=(w[3]-0x1A6F)/100.0f*KMH_TO_MPH;
      setValidatedWheelSpeedsMph(fl,fr,rl,rr,nowMs); live.wheelPositionProbable=true;
    }
  }
  if (frame.identifier == 0x127 && frame.dlc >= 6) {
    uint8_t code=(frame.data[5]>>4)&0x0F; if(code<=4){ live.gearCode=code; live.gearMs=nowMs; live.gearValid=true; }
  }
  if (frame.identifier == 0x1C4 && frame.dlc >= 2) {
    live.engineRPM=(int32_t)((uint32_t)wordBE(frame.data[0],frame.data[1])*25U/32U); live.engineRPMMs=nowMs; live.engineRPMValid=true; live.passiveEngineRPMMs=nowMs; live.passiveEngineRPMValid=true;
  }
  if (frame.identifier == 0x3B9 && frame.dlc >= 1) {
    const float c=frame.data[0]/2.0f-1.0f; live.engineCoolantF=c*1.8f+32.0f; live.coolantMs=nowMs; live.coolantValid=true; live.passiveCoolantMs=nowMs; live.passiveCoolantValid=true;
  }
  if (frame.identifier == 0x3CF && frame.dlc >= 3) {
    live.engineIntakeAirF=frame.data[2]*1.8f+32.0f; live.engineIntakeMs=nowMs; live.engineIntakeValid=true; live.passiveIntakeMs=nowMs; live.passiveIntakeValid=true;
  }
  if (frame.identifier == 0x4A8 && frame.dlc >= 3) {
    const uint16_t q=wordBE(frame.data[1],frame.data[2])>>4; const float soc=q*20.0f/51.0f;
    if(soc>=0.0f && soc<=100.0f){ live.socPct=soc; live.socMs=nowMs; live.socValid=true; live.passiveSocMs=nowMs; live.passiveSocValid=true; live.passiveSocTempMs=nowMs; live.passiveSocTempValid=true; }
  }
  if (frame.identifier == 0x49D && frame.dlc >= 8) {
    uint16_t raw9=((uint16_t)frame.data[2]<<1)|((frame.data[3]>>7)&1); int16_t s9=(raw9&0x100)?(int16_t)(raw9|0xFE00):(int16_t)raw9;
    live.packAmps=s9*0.8f+0.17f; live.packCurrentMs=nowMs; live.packCurrentValid=true; live.passivePackCurrentMs=nowMs; live.passivePackCurrentValid=true; refreshElectricalAggregate(nowMs);
  }
  if (frame.identifier == 0x49A && frame.dlc >= 6) {
    uint16_t raw12=((uint16_t)frame.data[0]<<4)|(frame.data[1]>>4); int16_t s12=signExtend12(raw12);
    live.mg1RPM=(s12-1)*10; live.mg1RPMMs=nowMs; live.mg1RPMValid=true; live.passiveMg1RPMMs=nowMs; live.passiveMg1RPMValid=true;
    float m1c=34.0f+2.0f*(((frame.data[1]&0x0F)<<1)|(frame.data[2]>>7)); float m2c=34.0f+2.0f*(frame.data[2]&0x1F);
    live.mg1StatorF=m1c*1.8f+32.0f; live.mg2StatorF=m2c*1.8f+32.0f; live.motorTempMs=nowMs; live.motorTempValid=true; live.passiveMotorTempMs=nowMs; live.passiveMotorTempValid=true;
    float i1c=20.0f+2.0f*(frame.data[4]>>3); float i2c=20.0f+2.0f*(((frame.data[4]&0x03)<<3)|(frame.data[5]>>5));
    live.mg1InvF=i1c*1.8f+32.0f; live.mg2InvF=i2c*1.8f+32.0f; live.inverterTempMs=nowMs; live.inverterTempValid=true; live.passiveInverterTempMs=nowMs; live.passiveInverterTempValid=true; refreshMgAggregate(nowMs);
  }
  if (frame.identifier == 0x245 && frame.dlc >= 2) {
    live.mg2RPM=(int16_t)wordBE(frame.data[0],frame.data[1]); live.mg2RPMMs=nowMs; live.mg2RPMValid=true; live.passiveMg2RPMMs=nowMs; live.passiveMg2RPMValid=true; refreshMgAggregate(nowMs);
  }
  if (frame.identifier == 0x49B && frame.dlc >= 3) {
    const float c=2.0f*(frame.data[2]&0x3F)-30.0f; live.inverterCoolantF=c*1.8f+32.0f; live.passiveInverterCoolantMs=nowMs; live.passiveInverterCoolantValid=true;
  }
  if (frame.identifier == 0x611 && frame.dlc >= 8 && (((frame.data[3] >> 1) & 0x03) == 2)) {
    live.odometerMiles = runtimeOdometer20(frame.data[5], frame.data[6], frame.data[7]);
    live.odometerMs = nowMs; live.odometerValid = true; live.odometerProbable = false;
  }
}

// ------------------------------ Diagnostics ----------------------------------
static const char *fanUiStateLabel(FanUiState state);

bool operatorDiagnosticWorkActive() {
  return dtcScan.active || dtcClear.active || dtcClear.confirmationPending ||
         fanOverride.enabled || fanOverride.overrideActive || fanOverride.releasePending;
}

void abortOperatorDiagnostics(const char *reason) {
  const bool hadWork = operatorDiagnosticWorkActive() ||
                       (diag.active && diag.owner != DIAG_OWNER_PERIODIC);
  if (diag.active && diag.owner != DIAG_OWNER_PERIODIC) completeDiagnostic("OPERATOR_ABORT");
  dtcAbortOperatorWork(dtcScan, dtcClear);
  const FanUiState priorFanState = fanOverride.state;
  fanRevokeControl(fanOverride, true);
  if (priorFanState != fanOverride.state)
    writeEvent("INFO", "OP_FAN_STATE", String(fanUiStateLabel(priorFanState)) + "->EXTERNAL TESTER");
  fanOverrideCommandProfile = PROFILE_UNKNOWN;
  diagnosticDisablePendingAfterFanRelease = false;
  if (hadWork) writeEvent("WARNING", "OP_DIAG_ABORT", reason ? reason : "UNKNOWN");
}

void revokeControlAuthorization(const char *reason) {
  const bool hadWork = operatorDiagnosticWorkActive() ||
                       (diag.active && diag.owner != DIAG_OWNER_PERIODIC);
  const bool fanCommandInFlight = diag.active && diag.owner == DIAG_OWNER_FAN_REFRESH && diag.contextIndex != 0;
  if (diag.active && diag.owner != DIAG_OWNER_PERIODIC) completeDiagnostic("CONTROL_REVOKED");
  dtcAbortOperatorWork(dtcScan, dtcClear);
  const FanUiState priorFanState = fanOverride.state;
  fanRevokeControl(fanOverride, false);
  if (priorFanState != fanOverride.state)
    writeEvent("INFO", "OP_FAN_STATE", String(fanUiStateLabel(priorFanState)) + "->CONTROL LOCKED");
  if (fanCommandInFlight) {
    fanOverride.overrideActive = true;
    fanOverride.releasePending = true;
  }
  if (hadWork) writeEvent("WARNING", "OP_DIAG_ABORT", reason ? reason : "CONTROL_REVOKED");
}

bool startOperatorDtcRead(uint32_t selectedMask) {
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  if (!profile || externalTesterOwnsSession || dtcScan.active) return false;
  const uint32_t allowed = diagnosticSelectableReadMask(profile);
  const uint32_t filtered = selectedMask & allowed;
  if (filtered == 0) return false;
  if (!diagnosticEnabled) {
    diagnosticAutoStartPending = true;
    if (!setDiagnosticCapture(true, "DTC/INF operator read")) return false;
    diagnosticAutoStartPending = false;
  }
  dtcOperatorSelectedMask = filtered;
  dtcStartRead(dtcScan, filtered);
  writeEvent("INFO", "OP_DTC_SCAN_START", String("mask=0x") + String(filtered, HEX));
  return true;
}


static bool operatorControlIdentityReady() {
  if (diagnosticIdentityVerified && controlIdentityVerifiedFor(vehicleProfile)) return true;
  return vehicleProfile == PROFILE_PRIUS_GEN2 && profileConfidence >= 80;
}

bool beginOperatorDtcClearConfirmation(uint32_t selectedMask) {
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  if (!profile || diag.active || dtcScan.active || dtcClear.active || externalTesterOwnsSession) return false;
  const bool controlIdentityOk = operatorControlIdentityReady();
  const bool ok = dtcBeginClearConfirmation(dtcClear, profile, selectedMask,
                                             controlIdentityOk, externalTesterOwnsSession);
  if (ok) writeEvent("INFO", "OP_DTC_CLEAR_CONFIRM", String("eligible=0x") + String(dtcClear.eligibleMask, HEX));
  return ok;
}

bool confirmOperatorDtcClear() {
  if (!dtcClear.confirmationPending || externalTesterOwnsSession) return false;
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  const bool controlIdentityOk = profile && operatorControlIdentityReady();
  if (!controlIdentityOk) return false;
  // Re-evaluate the exact mask at the irreversible confirmation boundary.
  const uint32_t stillEligible = dtcClearEligibleMask(profile, dtcClear.requestedMask,
                                                       controlIdentityOk, externalTesterOwnsSession);
  if (stillEligible != dtcClear.eligibleMask || stillEligible == 0) return false;
  if (!diagnosticEnabled) {
    diagnosticAutoStartPending = true;
    if (!setDiagnosticCapture(true, "Confirmed DTC clear")) return false;
    diagnosticAutoStartPending = false;
    if (!operatorControlIdentityReady()) return false;
  }
  const bool started = dtcConfirmClear(dtcClear, externalTesterOwnsSession);
  if (started) writeEvent("WARNING", "OP_DTC_CLEAR_START", String("eligible=0x") + String(dtcClear.eligibleMask, HEX));
  return started;
}

void cancelOperatorDtcClear() {
  dtcCancelClear(dtcClear);
}

static const char *fanUiStateLabel(FanUiState state) {
  switch (state) {
    case FAN_UI_AUTO: return "AUTO";
    case FAN_UI_ARMED: return "ARMED";
    case FAN_UI_OVERRIDE: return "OVERRIDE";
    case FAN_UI_TEMP_STALE: return "TEMP STALE";
    case FAN_UI_CONTROL_LOCKED: return "CONTROL LOCKED";
    case FAN_UI_EXTERNAL_TESTER: return "EXTERNAL TESTER";
    default: return "AUTO";
  }
}

static bool fanTemperatureSnapshot(int16_t *hottestF) {
  const uint32_t nowMs = millis();
  const bool fresh = live.batteryTempValid && live.batteryTempCount > 0 &&
                     (uint32_t)(nowMs - live.batteryTempMs) <= DIAGNOSTIC_DISPLAY_FRESH_MS;
  if (!fresh) return false;
  return fanHottestTempWholeF(live.batteryTempsF, live.batteryTempCount, hottestF);
}

static bool fanControlAllowedForProfile(const VehicleDiagnosticProfile *profile) {
  return profile && profile->fan.overrideRequest.capability == VERIFIED &&
         (profile->fan.releaseRequest.capability == VERIFIED ||
          profile->vehicleProfile == PROFILE_PRIUS_PHV_GEN1 ||
          profile->vehicleProfile == PROFILE_CAMRY_HYBRID_GEN1) &&
         operatorControlIdentityReady() &&
         !externalTesterOwnsSession;
}

static bool fanOverrideMustUseMax(const VehicleDiagnosticProfile *profile) {
  return profile && (profile->vehicleProfile == PROFILE_PRIUS_PHV_GEN1 ||
                     profile->vehicleProfile == PROFILE_CAMRY_HYBRID_GEN1);
}

bool setOperatorFanOverrideEnabled(bool enable) {
  if (!enable) {
    fanOverride.enabled = false;
    fanOverride.releasePending = fanOverride.overrideActive;
    writeEvent("INFO", "OP_FAN_SETTING", "enabled=0");
    return true;
  }
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  if (!profile || profile->fan.overrideRequest.capability != VERIFIED ||
      !controlIdentityVerifiedFor(vehicleProfile) || externalTesterOwnsSession) {
    fanOverride.enabled = false;
    fanOverride.state = externalTesterOwnsSession ? FAN_UI_EXTERNAL_TESTER : FAN_UI_CONTROL_LOCKED;
    return false;
  }
  if (!diagnosticEnabled) {
    diagnosticAutoStartPending = true;
    if (!setDiagnosticCapture(true, "HV battery fan override arm")) return false;
    diagnosticAutoStartPending = false;
  }
  // Identity preflight may still be pending. The checkbox may arm, but scheduler
  // will not transmit until fanControlAllowedForProfile() becomes true.
  if (fanOverrideMustUseMax(profile)) fanOverride.speed = FAN_SPEED_MAX;
  fanOverride.enabled = true;
  fanOverride.state = operatorControlIdentityReady() ? FAN_UI_ARMED : FAN_UI_CONTROL_LOCKED;
  writeEvent("INFO", "OP_FAN_SETTING", String("enabled=1;triggerF=") + String(fanOverride.triggerF) +
             ";speed=" + (fanOverride.speed == FAN_SPEED_MAX ? "MAX" : "HIGH"));
  return true;
}

static DiagnosticRequestDef fanLevelRequest(const VehicleDiagnosticProfile *profile, uint8_t level) {
  DiagnosticRequestDef request = profile ? profile->fan.overrideRequest : DIAG_REQ_NONE;
  if (request.requestLength >= 4) request.request[3] = level;
  return request;
}

void serviceFanOverrideScheduler() {
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  if (diag.active) return;
  if (fanOverride.releasePending && fanOverride.overrideActive) {
    const VehicleDiagnosticProfile *releaseProfile = diagnosticProfileFor(fanOverrideCommandProfile);
    if (!externalTesterOwnsSession && releaseProfile && releaseProfile->fan.releaseRequest.capability == VERIFIED) {
      if (beginDiagnosticRequest(releaseProfile->fan.releaseRequest, DIAG_OWNER_FAN_REFRESH, 0)) {
        char details[64];
        snprintf(details, sizeof(details), "profile=%s", releaseProfile->platformLabel);
        writeOperatorEvent("INFO", "OP_FAN_RELEASE", details);
      }
    } else if (!externalTesterOwnsSession) {
      if (releaseProfile && fanOverrideMustUseMax(releaseProfile))
        writeOperatorEvent("INFO", "OP_FAN_RELEASE_TIMEOUT", "MAX refresh stopped; await ECU timeout");
      fanOverride.overrideActive = false;
      fanOverride.releasePending = false;
      fanOverrideCommandProfile = PROFILE_UNKNOWN;
    }
    return;
  }
  int16_t hottestF = 0;
  const bool tempFresh = fanTemperatureSnapshot(&hottestF);
  const bool controlAllowed = fanControlAllowedForProfile(profile);
  FanDecision decision = evaluateFanOverride(fanOverride, tempFresh, hottestF,
                                             controlAllowed, externalTesterOwnsSession);
  if (decision.disableEnabled) {
    fanOverride.enabled = false;
    fanOverride.overrideActive = false;
    fanOverride.releasePending = false;
    fanOverride.state = decision.uiState;
    fanOverrideCommandProfile = PROFILE_UNKNOWN;
    return;
  }
  const FanUiState previousState = fanOverride.state;
  fanOverride.state = decision.uiState;
  if (previousState != fanOverride.state) {
    char details[64];
    snprintf(details, sizeof(details), "%s->%s", fanUiStateLabel(previousState), fanUiStateLabel(fanOverride.state));
    writeOperatorEvent("INFO", "OP_FAN_STATE", details);
  }

  if (decision.action == FAN_ACTION_RELEASE && fanOverride.overrideActive) {
    const VehicleDiagnosticProfile *releaseProfile = diagnosticProfileFor(fanOverrideCommandProfile);
    if (!externalTesterOwnsSession && releaseProfile && releaseProfile->fan.releaseRequest.capability == VERIFIED) {
      if (beginDiagnosticRequest(releaseProfile->fan.releaseRequest, DIAG_OWNER_FAN_REFRESH, 0)) {
        fanOverride.releasePending = true;
      }
    } else {
      if (releaseProfile && fanOverrideMustUseMax(releaseProfile))
        writeOperatorEvent("INFO", "OP_FAN_RELEASE_TIMEOUT", "MAX refresh stopped; await ECU timeout");
      fanOverride.overrideActive = false;
      fanOverride.releasePending = false;
      fanOverrideCommandProfile = PROFILE_UNKNOWN;
    }
    return;
  }

  if (decision.action != FAN_ACTION_OVERRIDE || !controlAllowed || !profile) return;
  const uint32_t nowMs = millis();
  const bool due = !fanOverride.overrideActive || fanOverride.lastCommandMs == 0 ||
                   (uint32_t)(nowMs - fanOverride.lastCommandMs) >= profile->fan.refreshMs;
  if (!due) return;
  const uint8_t level = (fanOverride.speed == FAN_SPEED_HIGH && !fanOverrideMustUseMax(profile)) ?
                        profile->fan.highLevel : profile->fan.maxLevel;
  DiagnosticRequestDef request = fanLevelRequest(profile, level);
  if (beginDiagnosticRequest(request, DIAG_OWNER_FAN_REFRESH, level)) {
    fanOverride.releasePending = false;
    fanOverrideCommandProfile = vehicleProfile;
    char details[64];
    snprintf(details, sizeof(details), "level=%u;profile=%s", (unsigned)level, profile->platformLabel);
    writeOperatorEvent("INFO", "OP_FAN_COMMAND", details);
  }
}

void serviceDiagnosticScheduler() {
  if (externalTesterOwnsSession) {
    abortOperatorDiagnostics("EXTERNAL_TESTER_OWNERSHIP");
    // Preserve the proven logging RX path: session ownership is a software TX inhibit.
    // Do not reconfigure/reinstall TWAI while an Android-controlled session is active.
    fastDiagActive = false;
    if (diag.active) completeDiagnostic("EXTERNAL_TESTER_LATCH");
    diagnosticEnabled = false;
    diagnosticIdentityVerified = false;
    return;
  }
  // R2.5 normal-display behavior: MAIN/TEMP/HV is a hardwired live monitor,
  // independent of SD logging. The CYD may issue only the explicit read-only
  // profile whitelist. An external tester suppresses CYD transmission while
  // its validated responses may still refresh the live display.
  if (!diagnosticEnabled && diagnosticAutoStartPending &&
      profileSupportsActiveDiagnostics(vehicleProfile)) {
    bool externalRecent = externalTesterLastUs != 0 &&
                          (nowMicros64() - externalTesterLastUs) / 1000ULL < EXTERNAL_TESTER_HOLD_MS;
    if (!externalRecent && setDiagnosticCapture(true, "Automatic normal-display read-only polling"))
      diagnosticAutoStartPending = false;
  }

  if (diag.active) {
    if (!diagnosticEnabled) {
      completeDiagnostic("USER_DISABLED");
      return;
    }
    const uint32_t timeoutUs = diag.pendingResponse ? DIAGNOSTIC_PENDING_TIMEOUT_US : DIAGNOSTIC_TIMEOUT_US;
    if (nowMicros64() - diag.lastActivityUs > timeoutUs) {
      ++diagnosticTimeouts;
      completeDiagnostic("TIMEOUT");
    }
    return;
  }
  if (!diagnosticEnabled || !twaiNormalMode) return;
  if (millis() - lastDiagnosticCompleteMs < DIAGNOSTIC_GAP_MS) return;

  // A release of a previously commanded fan belongs to the profile that issued
  // it and must be attempted before any new identity/profile work while CYD
  // still owns the bus. Never do this after external ownership transfer.
  if (fanOverride.releasePending && fanOverride.overrideActive) {
    serviceFanOverrideScheduler();
    if (diag.active) return;
  }
  if (diagnosticDisablePendingAfterFanRelease && !fanOverride.overrideActive && !fanOverride.releasePending) {
    diagnosticDisablePendingAfterFanRelease = false;
    setDiagnosticCapture(false, "Deferred after fan AUTO/release");
    return;
  }

  // Before any Camry/PHV profile-specific polling, verify the model using the
  // explicit read-only 7E0/21C1 identity request. This prevents the historical
  // passive heuristic from applying the AHV40 schedule to a ZVW35 PHV.
  if (!diagnosticIdentityVerified && !operatorControlIdentityReady()) {
    uint32_t nowMs = millis();
    if (lastDiagnosticIdentityRequestMs != 0 &&
        nowMs - lastDiagnosticIdentityRequestMs < DB_IDENTITY_DISCOVERY_REQUEST.periodMs) return;
    lastDiagnosticIdentityRequestMs = nowMs;
    ++diagnosticIdentityAttempts;
    activeDiagnosticLastGrade = DB_IDENTITY_DISCOVERY_REQUEST.grade;
    activeDiagnosticLastKey = DB_IDENTITY_DISCOVERY_REQUEST.key;
    startDiagnosticRequest(DB_IDENTITY_DISCOVERY_REQUEST);
    return;
  }

  // Priority when the single ISO-TP owner is idle: fan refresh/release,
  // then operator DTC work, then periodic display polling.
  serviceFanOverrideScheduler();
  if (diag.active) return;

  if (dtcClear.active) {
    const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
    const bool controlIdentityOk = profile && operatorControlIdentityReady();
    if (!controlIdentityOk || externalTesterOwnsSession) {
      dtcCancelClear(dtcClear);
      return;
    }
    const int next = dtcNextPendingClearEcu(dtcClear, profile);
    if (next < 0) {
      const uint32_t postReadMask = dtcClear.postReadMask;
      char details[64];
      snprintf(details, sizeof(details), "ok=0x%lX;fail=0x%lX",
               (unsigned long)dtcClear.successMask, (unsigned long)dtcClear.failedMask);
      writeOperatorEvent("INFO", "OP_DTC_CLEAR_END", details);
      dtcClear.active = false;
      dtcClear.postReadPending = postReadMask != 0;
      if (postReadMask != 0) {
        if (startOperatorDtcRead(postReadMask)) dtcClear.postReadPending = false;
      }
      return;
    }
    dtcClear.pendingEcuIndex = (uint8_t)next;
    if (!beginDiagnosticRequest(profile->ecus[next].clear, DIAG_OWNER_DTC_CLEAR, (uint8_t)next))
      dtcMarkClearResult(dtcClear, (uint8_t)next, false);
    return;
  }

  if (dtcScan.active) {
    const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
    const int next = dtcNextPendingEcu(dtcScan, profile);
    if (next < 0) {
      char details[80];
      snprintf(details, sizeof(details), "responded=0x%lX;results=%u;truncated=%u",
               (unsigned long)dtcScan.respondingMask, (unsigned)dtcScan.resultCount, dtcScan.truncated ? 1U : 0U);
      writeOperatorEvent("INFO", "OP_DTC_SCAN_END", details);
      dtcScan.active = false;
      dtcScan.pendingEcuIndex = 0xFF;
      return;
    }
    dtcScan.pendingEcuIndex = (uint8_t)next;
    const DiagnosticRequestDef *read = dtcReadRequestForStep(profile->ecus[next],
                                                             dtcScan.pendingReadStep);
    if (!read || !beginDiagnosticRequest(*read, DIAG_OWNER_DTC_READ, (uint8_t)next))
      dtcRecordReadStep(dtcScan, profile->ecus[next], (uint8_t)next, false);
    return;
  }

  if (!profileSupportsActiveDiagnostics(vehicleProfile)) {
    setDiagnosticCapture(false, "Verified profile has no active read-only display plan");
    return;
  }

  uint32_t nowMs = millis();
  int selected = -1;
  uint64_t bestDueRatio = 0;
  for (size_t i = 0; i < DB_ACTIVE_DIAGNOSTIC_REQUEST_COUNT; ++i) {
    const DbActiveDiagnosticRequest &request = DB_ACTIVE_DIAGNOSTIC_REQUESTS[i];
    if (!profileNameMatches(request.profile, vehicleProfile)) continue;
    uint32_t age = nowMs - activeDiagnosticLastPollMs[i];
    if (age < request.periodMs) continue;
    uint64_t dueRatio = ((uint64_t)age * 1000ULL) / request.periodMs;
    if (selected < 0 || dueRatio > bestDueRatio) {
      selected = (int)i;
      bestDueRatio = dueRatio;
    }
  }
  if (selected < 0) return;

  const DbActiveDiagnosticRequest &request = DB_ACTIVE_DIAGNOSTIC_REQUESTS[selected];
  activeDiagnosticLastPollMs[selected] = nowMs;
  activeDiagnosticLastGrade = request.grade;
  activeDiagnosticLastKey = request.key;
  startDiagnosticRequest(request);
}

bool beginDiagnosticRequest(const DiagnosticRequestDef &request, DiagnosticOwner owner, uint8_t contextIndex) {
  if (diag.active || request.requestLength < 1 || request.requestLength > 7 ||
      request.requestId == 0 || request.responseId == 0) return false;
  if (request.targetAddress && request.requestLength > 6) return false;
  memset(&diag, 0, sizeof(diag));
  diag.active = true;
  diag.owner = owner;
  diag.contextIndex = contextIndex;
  diag.targetAddress = request.targetAddress;
  diag.requestLength = request.requestLength;
  memcpy(diag.requestBytes, request.request, request.requestLength);
  diag.positivePrefixLength = request.positivePrefixLength > 3 ? 3 : request.positivePrefixLength;
  memcpy(diag.positivePrefix, request.positivePrefix, diag.positivePrefixLength);
  diag.decoder = request.decoder;
  diag.requestId = request.requestId;
  diag.responseId = request.responseId;
  diag.service = request.request[0];
  diag.pid = request.requestLength > 1 ? request.request[1] : 0;
  diag.requestTimeUs = nowMicros64();
  diag.lastActivityUs = diag.requestTimeUs;
  fastDiagResponseId = diag.responseId;
  fastDiagRequestTimeUs = diag.requestTimeUs;
  fastDiagActive = true;

  uint8_t data[8] = {0,0,0,0,0,0,0,0};
  if (!encodeDiagnosticSingleFrame(request, data)) {
    fastDiagActive = false; diag.active = false; return false;
  }
  if (!transmitCAN(request.requestId, data, 8, "DIAGNOSTIC_REQUEST")) {
    fastDiagActive = false;
    diag.active = false;
    lastDiagnosticCompleteMs = millis();
    return false;
  }
  return true;
}

static bool diagnosticPositivePrefixMatches(const uint8_t *payload, uint16_t length) {
  if (diag.positivePrefixLength == 0) return true;
  if (!payload || length < diag.positivePrefixLength) return false;
  for (uint8_t i=0;i<diag.positivePrefixLength;++i)
    if (payload[i] != diag.positivePrefix[i]) return false;
  return true;
}

void startDiagnosticRequest(const DbActiveDiagnosticRequest &request) {
  DiagnosticRequestDef def = {
    request.requestId, request.responseId, 2,
    {request.service, request.pid, 0,0,0,0,0},
    2, {(uint8_t)(request.service + 0x40), request.pid, 0},
    DTC_DECODER_RAW, READ_ONLY
  };
  beginDiagnosticRequest(def, DIAG_OWNER_PERIODIC, 0);
}

void processDiagnosticFrame(const CapturedFrame &frame) {
  if (!diag.active || frame.identifier != diag.responseId || frame.timeUs < diag.requestTimeUs) return;
  if (frame.dlc == 0) return;
  const uint8_t offset = diag.targetAddress ? 1U : 0U;
  if (diag.targetAddress && (frame.dlc < 2 || frame.data[0] != diag.targetAddress)) return;
  uint8_t pciType = frame.data[offset] >> 4;

  if (pciType == 0x0) {
    uint8_t length = frame.data[offset] & 0x0F;
    if (length > 7U-offset || length > frame.dlc - 1U-offset) {
      completeDiagnostic("BAD_SINGLE_FRAME");
      return;
    }
    const uint8_t *responseData = &frame.data[offset + 1U];
    bool positiveMatch = diagnosticPositivePrefixMatches(responseData, length);
    bool negativeMatch = length >= 3 && responseData[0] == 0x7F && responseData[1] == diag.requestBytes[0];
    if (!positiveMatch && !negativeMatch) {
      writeExternalDiagnosticFrame(frame, "EXTERNAL_DIAGNOSTIC_TRAFFIC");
      return; // Do not abort or extend the logger's active transaction.
    }
    diag.lastActivityUs = frame.timeUs;
    ++diag.frameCount;
    memcpy(diag.payload, responseData, length);
    diag.receivedLength = length;
    diag.expectedLength = length;
    if (length >= 3 && diag.payload[0] == 0x7F && diag.payload[2] == 0x78) {
      // UDS response-pending: retain the transaction and extend its inactivity
      // timeout. This does not transmit any additional request.
      diag.pendingResponse = true;
      return;
    }
    if (length >= 3 && diag.payload[0] == 0x7F) {
      ++diagnosticNegativeResponses;
      completeDiagnostic("NEGATIVE_RESPONSE");
    } else if (!diagnosticPositivePrefixMatches(diag.payload, length)) {
      completeDiagnostic("RESPONSE_VALIDATION_ERROR");
    } else {
      completeDiagnostic("OK");
    }
    return;
  }

  if (diag.targetAddress) {
    // No unverified Toyota target-addressed multi-frame flow-control TX.
    // Short Smart Key/Main Body reads, including NRC78 + delayed SF, are supported.
    completeDiagnostic("TARGET_MULTIFRAME_UNSUPPORTED");
    return;
  }

  if (pciType == 0x1) {
    if (frame.dlc >= 2 + diag.positivePrefixLength &&
        !diagnosticPositivePrefixMatches(&frame.data[2], frame.dlc - 2)) {
      writeExternalDiagnosticFrame(frame, "EXTERNAL_DIAGNOSTIC_TRAFFIC");
      return;
    }
    diag.lastActivityUs = frame.timeUs;
    ++diag.frameCount;
    diag.expectedLength = ((uint16_t)(frame.data[0] & 0x0F) << 8) | frame.data[1];
    if (diag.expectedLength <= 7 || frame.dlc < 8) {
      completeDiagnostic("BAD_FIRST_FRAME");
      return;
    }
    if (diag.expectedLength > sizeof(diag.payload)) {
      completeDiagnostic("PAYLOAD_TOO_LARGE");
      return;
    }
    diag.multiFrame = true;
    diag.receivedLength = min((uint16_t)6, diag.expectedLength);
    memcpy(diag.payload, &frame.data[2], diag.receivedLength);
    diag.nextSequence = 1;
    // Flow control was already sent immediately by the high-priority CAN_RX
    // task. Keeping it out of loop() avoids the 12-173 ms SD/TFT latency seen
    // in the supplied Prius capture and prevents duplicate FC frames.
    return;
  }

  if (pciType == 0x2 && diag.multiFrame) {
    diag.lastActivityUs = frame.timeUs;
    ++diag.frameCount;
    uint8_t sequence = frame.data[0] & 0x0F;
    if (sequence != diag.nextSequence) {
      completeDiagnostic("SEQUENCE_ERROR");
      return;
    }
    diag.nextSequence = (diag.nextSequence + 1) & 0x0F;
    uint16_t remaining = diag.expectedLength - diag.receivedLength;
    uint16_t count = min((uint16_t)7, remaining);
    memcpy(&diag.payload[diag.receivedLength], &frame.data[1], count);
    diag.receivedLength += count;
    if (diag.receivedLength >= diag.expectedLength) {
      if (!diagnosticPositivePrefixMatches(diag.payload, diag.expectedLength)) {
        writeExternalDiagnosticFrame(frame, "EXTERNAL_DIAGNOSTIC_TRAFFIC");
        completeDiagnostic("REASSEMBLY_MISMATCH");
      } else {
        completeDiagnostic("OK");
      }
    }
  }
}

void completeDiagnostic(const char *status) {
  uint64_t completeTimeUs = nowMicros64();
  fastDiagActive = false;
  bool identityRequest = diag.requestId == DB_IDENTITY_DISCOVERY_REQUEST.requestId &&
                         diag.responseId == DB_IDENTITY_DISCOVERY_REQUEST.responseId &&
                         diag.service == DB_IDENTITY_DISCOVERY_REQUEST.service &&
                         diag.pid == DB_IDENTITY_DISCOVERY_REQUEST.pid;
  if (strcmp(status, "OK") == 0 && diag.owner == DIAG_OWNER_PERIODIC)
    decodeDiagnosticPayload(diag.responseId, diag.payload, diag.receivedLength);

  // Preserve the hardware-proven Gen2 path if the optional identity response is
  // unavailable. Strong Gen2 passive fingerprinting was the v2.4.2 gate; this
  // fallback is never applied to a Camry/PHV heuristic match.
  if (identityRequest && !diagnosticIdentityVerified && diagnosticIdentityAttempts >= 2 &&
      vehicleProfile == PROFILE_PRIUS_GEN2 && profileConfidence >= 80 &&
      strcmp(status, "DIAGNOSTIC_DISABLED") != 0 && strcmp(status, "USER_DISABLED") != 0) {
    diagnosticIdentityVerified = true;
    writeEvent("INFO", "DIAGNOSTIC_IDENTITY_FALLBACK",
               "Strong Gen2 passive profile retained after 21C1 identity preflight did not resolve");
  }

  if (diag.owner == DIAG_OWNER_DTC_READ) {
    const uint8_t ecuIndex = diag.contextIndex;
    const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
    if (strcmp(status, "OK") == 0) {
      dtcDecodeResponse(dtcScan, ecuIndex, diag.decoder, diag.payload, diag.receivedLength);
    }
    if (profile && ecuIndex < profile->ecuCount)
      dtcRecordReadStep(dtcScan, profile->ecus[ecuIndex], ecuIndex, strcmp(status, "OK") == 0);
    else dtcMarkNoResponse(dtcScan, ecuIndex);
    char details[64];
    snprintf(details, sizeof(details), "read;ecu=%u;status=%s", (unsigned)ecuIndex, status);
    writeOperatorEvent("INFO", "OP_DTC_ECU_DONE", details);
  }

  if (diag.owner == DIAG_OWNER_DTC_CLEAR) {
    dtcMarkClearResult(dtcClear, diag.contextIndex, strcmp(status, "OK") == 0);
    char details[64];
    snprintf(details, sizeof(details), "clear;ecu=%u;status=%s", (unsigned)diag.contextIndex, status);
    writeOperatorEvent("INFO", "OP_DTC_ECU_DONE", details);
  }

  if (diag.owner == DIAG_OWNER_FAN_REFRESH) {
    if (diag.contextIndex == 0) {
      // Whether the explicit release ACKs or times out, stop refreshing the high
      // command. NHW20 falls back to factory control when refresh stops.
      fanOverride.overrideActive = false;
      fanOverride.releasePending = false;
      fanOverrideCommandProfile = PROFILE_UNKNOWN;
      writeEvent(strcmp(status, "OK") == 0 ? "INFO" : "WARNING", "OP_FAN_RELEASE", status);
    } else if (strcmp(status, "OK") == 0) {
      fanOverride.overrideActive = true;
      fanOverride.releasePending = false;
      fanOverride.lastCommandMs = millis();
    }
  }

  writeDiagnosticRecord(status, completeTimeUs);
  diag.active = false;
  lastDiagnosticCompleteMs = millis();
}

void decodeDiagnosticPayload(uint32_t responseId, const uint8_t *payload, uint16_t length) {
  if (length < 2) return;
  uint8_t expectedService = diag.service + 0x40;
  if (payload[0] != expectedService || payload[1] != diag.pid) return;
  const uint8_t *data = &payload[2]; // A is data[0], B is data[1], etc.
  uint16_t dataLength = length - 2;

  // Profile identity is resolved before profile-specific runtime lookup. The
  // same 7E0/21C1 tuple is used by multiple Toyota hybrid platforms.
  if (diag.service == 0x21 && diag.pid == 0xC1) {
    if (containsAsciiToken(data, dataLength, "ZVW30")) {
      applyDatabaseProfileEvidence(PROFILE_PRIUS_GEN3, 100, true, "ZVW30 model signature");
      diagnosticIdentityVerified = true;
    } else if (containsAsciiToken(data, dataLength, "ZVW45")) {
      applyDatabaseProfileEvidence(PROFILE_PRIUS_ALPHA_ZVW45, 100, true, "ZVW45 model signature");
      diagnosticIdentityVerified = true;
    } else if (containsAsciiToken(data, dataLength, "ZVW35")) {
      applyDatabaseProfileEvidence(PROFILE_PRIUS_PHV_GEN1, 100, true, "ZVW35 model signature");
      diagnosticIdentityVerified = true;
    } else if (containsAsciiToken(data, dataLength, "AHV40L")) {
      applyDatabaseProfileEvidence(PROFILE_CAMRY_HYBRID_GEN1, 100, true, "AHV40L model signature");
      diagnosticIdentityVerified = true;
    } else if (containsAsciiToken(data, dataLength, "NHW20")) {
      applyDatabaseProfileEvidence(PROFILE_PRIUS_GEN2,
        (nhw20VariantConfirmedBy529 && priusScore>=4 && camryScore<4) ? 100U : 95U,
        false, "NHW20 model signature");
      diagnosticIdentityVerified = true;
    } else {
      writeEvent("WARNING", "DIAGNOSTIC_IDENTITY_UNRESOLVED", "21C1 response did not match NHW20/AHV40L/ZVW35");
    }
    return;
  }

  const DbRuntimeSignal *definition =
      findRuntimeSignal(diag.requestId, responseId, diag.service, diag.pid);
  if (!definition || definition->decoder == DBR_OBSERVE_ONLY) {
    writeEvent("WARNING", "DIAGNOSTIC_RUNTIME_DECODE_MISSING",
               String("req=") + String(diag.requestId, HEX) + ";resp=" + String(responseId, HEX) +
               ";service=" + String(diag.service, HEX) + ";pid=" + String(diag.pid, HEX));
    return;
  }
  decodeRuntimeSignal(*definition, data, dataLength);
}

void decodeC3(const uint8_t *d, uint16_t n) {
  if (n < 31) return; // Through AE.
  live.mg2RPM = (int32_t)wordBE(d[0], d[1]) - 16383;
  live.mg2TorqueNm = ((int32_t)wordBE(d[2], d[3]) - 4000) / 8.0f;
  live.mg1RPM = (int32_t)wordBE(d[6], d[7]) - 16383;
  live.mg1TorqueNm = ((int32_t)wordBE(d[8], d[9]) - 4000) / 8.0f;
  live.engineRPM = wordBE(d[14], d[15]);
  live.engineRPMMs = millis();
  live.engineRPMValid = true;
  live.mgPowertrainMs = live.engineRPMMs;
  live.mgPowertrainValid = true;
  live.socPct = 0.392f * d[18];
  // Current v0.9.50 field order: Y=MG1 inverter, Z=MG2 inverter,
  // AA=MG1 motor, AB=MG2 motor.
  live.mg1InvF = 1.8f * d[24] - 58.0f;
  live.mg2InvF = 1.8f * d[25] - 58.0f;
  live.mg1StatorF = 1.8f * d[26] - 58.0f;
  live.mg2StatorF = 1.8f * d[27] - 58.0f;
  live.packVolts = 2.0f * d[28];
  live.packAmps = 2.0f * d[30] - 256.0f;
  live.packKW = live.packVolts * live.packAmps / 1000.0f;
  live.c3Ms = millis();
  live.c3Valid = true;
  live.socMs = live.c3Ms; live.socValid = true;
  live.electricalMs = live.c3Ms; live.electricalValid = true;
  live.inverterTempMs = live.c3Ms; live.inverterTempValid = true;
  live.motorTempMs = live.c3Ms; live.motorTempValid = true;
}

void decodeC4(const uint8_t *d, uint16_t n) {
  if (n < 6) return;
  float beforeBoost = 2.0f * d[3];
  float afterBoost = 2.0f * d[4];
  float converterF = 1.8f * d[5] - 58.0f;
  if (beforeBoost < 0 || afterBoost < 0 || converterF < -1000) return;
  live.converterTempF = converterF;
  live.c4Ms = millis();
  live.c4Valid = true;
}

void decodeCE(const uint8_t *d, uint16_t n) {
  if (n < 31) return;
  const uint32_t nowMs = millis();
  if (!passiveMetricFresh(live.passiveSocValid, live.passiveSocMs, nowMs)) { live.socPct = 0.5f * d[0]; live.socMs = nowMs; live.socValid = true; }
  if (!passiveMetricFresh(live.passivePackCurrentValid, live.passivePackCurrentMs, nowMs)) { live.packAmps = 2.56f * d[1] + 0.01f * d[2] - 327.68f; live.packCurrentMs = nowMs; live.packCurrentValid = true; }
  float sum = 0.0f;
  for (uint8_t i = 0; i < 14; ++i) {
    uint8_t p = 3 + i * 2;
    live.blockVolts[i] = 2.56f * d[p] + 0.01f * d[p + 1] - 327.68f;
    sum += live.blockVolts[i];
  }
  if (!passiveMetricFresh(live.passivePackVoltageValid, live.passivePackVoltageMs, nowMs)) { live.packVolts = sum; live.packVoltageMs = nowMs; live.packVoltageValid = true; }
  live.blockCount = 14;
  recomputeBlockSummary();
  live.ceMs = nowMs; live.ceValid = true;
  live.blockVoltageMs = nowMs; live.blockVoltageValid = true;
  refreshElectricalAggregate(nowMs);
}

void decodeCF(const uint8_t *d, uint16_t n) {
  if (n < 16) return;
  live.intakeTempF = rawTemperatureF(d[0], d[1]);
  live.auxVolts = 0.2f * d[3] - 25.6f;
  live.deltaSocPct = 0.01f * d[6];
  live.fanLevel = d[8];
  live.hvTemp1F = rawTemperatureF(d[10], d[11]);
  live.hvTemp2F = rawTemperatureF(d[12], d[13]);
  live.hvTemp3F = rawTemperatureF(d[14], d[15]);
  live.hvAvgF = (live.hvTemp1F + live.hvTemp2F + live.hvTemp3F) / 3.0f;
  live.intakeTempsF[0] = live.intakeTempF;
  live.intakeTempCount = 1;
  live.batteryTempsF[0] = live.hvTemp1F;
  live.batteryTempsF[1] = live.hvTemp2F;
  live.batteryTempsF[2] = live.hvTemp3F;
  live.batteryTempCount = 3;
  live.cfMs = millis();
  live.cfValid = true;
  live.batteryTempMs = live.cfMs; live.batteryTempValid = true;
}

void decodeD0(const uint8_t *d, uint16_t n) {
  if (n < 29) return;
  live.blockMinV = 2.56f * d[9] + 0.01f * d[10] - 327.68f;
  live.blockMinNumber = d[11] + 1;
  live.blockMaxV = 2.56f * d[12] + 0.01f * d[13] - 327.68f;
  live.blockMaxNumber = d[14] + 1;
  live.blockDeltaV = live.blockMaxV - live.blockMinV;
  for (uint8_t i = 0; i < 14; ++i) live.internalResistance[i] = 0.001f * d[15 + i];
  live.blockCount = 14;
  live.d0Ms = millis();
  live.d0Valid = true;
  live.resistanceMs = live.d0Ms; live.resistanceValid = true;
}

// -------------------------------- SD logging ---------------------------------
const char *sessionName() {
  return sessionDir[0] ? &sessionDir[8] : "NONE";
}

void setLoggerStatus(const char *status) {
  if (status == nullptr) status = "UNKNOWN";
  strncpy(loggerStatus, status, sizeof(loggerStatus) - 1);
  loggerStatus[sizeof(loggerStatus) - 1] = '\0';
}

bool sessionTrafficRecent() {
  if (!loggingActive || !sessionHasCanTraffic || sessionLastCanUs == 0) return false;
  uint64_t nowUs = nowMicros64();
  return nowUs >= sessionLastCanUs && nowUs - sessionLastCanUs <= CAN_TRAFFIC_RECENT_US;
}


static uint32_t readSessionCounterNvs() {
  Preferences prefs;
  if (!prefs.begin(SESSION_NVS_NAMESPACE, true)) return 0;
  uint32_t value = prefs.getUInt(SESSION_NVS_KEY, 0);
  prefs.end();
  return value;
}

static bool writeSessionCounterNvs(uint32_t value) {
  Preferences prefs;
  if (!prefs.begin(SESSION_NVS_NAMESPACE, false)) return false;
  size_t written = prefs.putUInt(SESSION_NVS_KEY, value);
  prefs.end();
  return written == sizeof(uint32_t);
}

static bool writeSessionCounterSd(uint32_t value) {
  if (SD.exists(SESSION_COUNTER_NEW_PATH)) SD.remove(SESSION_COUNTER_NEW_PATH);
  File file = SD.open(SESSION_COUNTER_NEW_PATH, FILE_WRITE);
  bool fileOk = false;
  if (file) {
    file.println(value); file.flush(); file.close();
    if (SD.exists(SESSION_COUNTER_PATH)) SD.remove(SESSION_COUNTER_PATH);
    fileOk = SD.rename(SESSION_COUNTER_NEW_PATH, SESSION_COUNTER_PATH);
  }
  if (!fileOk && SD.exists(SESSION_COUNTER_NEW_PATH)) SD.remove(SESSION_COUNTER_NEW_PATH);
  return fileOk;
}

static void serviceDeferredSessionCounterSdSync() {
  if (!sessionCounterSdSyncPending || !sdReady || loggingActive) return;
  const bool ok = writeSessionCounterSd(sessionCounterSdSyncValue);
  Serial.printf("# SESSION COUNTER SD SYNC,next=%lu,result=%s\n", (unsigned long)sessionCounterSdSyncValue, ok?"PASS":"FAIL");
  sessionCounterSdSyncPending = !ok;
}

static void loadDistanceBases() {
  Preferences prefs;
  if (!prefs.begin(SESSION_NVS_NAMESPACE, true)) return;
  String o = prefs.getString(ODO_BASE_NVS_KEY, "");
  String t = prefs.getString(TRIP_BASE_NVS_KEY, "");
  prefs.end();
  if (o.length()) { odoBaseMiles = o.toDouble(); odoBaseValid = true; }
  if (t.length()) { tripBaseMiles = t.toDouble(); tripBaseValid = true; }
}

static void saveDistanceBase(const char *key, double value) {
  Preferences prefs; if (!prefs.begin(SESSION_NVS_NAMESPACE, false)) return;
  prefs.putString(key, String(value, 3)); prefs.end();
}

#include "gen2_persist.h"

static bool readSessionCounterFile(uint32_t &value) {
  value = 0;
  File file = SD.open(SESSION_COUNTER_PATH, FILE_READ);
  if (!file) return false;
  String line = file.readStringUntil('\n');
  file.close();
  line.trim();
  if (line.length() == 0) return false;
  char *endp = nullptr;
  unsigned long parsed = strtoul(line.c_str(), &endp, 10);
  if (endp == line.c_str() || *endp != '\0' || parsed < 1UL || parsed > 10000UL) return false;
  value = (uint32_t)parsed;
  return true;
}

uint32_t recoverNextSessionNumberFromCard() {
  uint32_t highest = 0;
  File root = SD.open("/CANLOG");
  if (!root || !root.isDirectory()) {
    if (root) root.close();
    return 1;
  }
  File entry = root.openNextFile();
  while (entry) {
    if (entry.isDirectory()) {
      const char *name = entry.name();
      const char *base = strrchr(name, '/');
      base = base ? base + 1 : name;
      if (base && strlen(base) == 5 && base[0] == 'S' &&
          isdigit((unsigned char)base[1]) && isdigit((unsigned char)base[2]) &&
          isdigit((unsigned char)base[3]) && isdigit((unsigned char)base[4])) {
        uint32_t number = (uint32_t)atoi(base + 1);
        if (number >= 1 && number <= 9999 && number > highest) highest = number;
      }
    }
    entry.close();
    entry = root.openNextFile();
  }
  root.close();
  return highest < 9999 ? highest + 1U : 10000U;
}

bool persistNextSessionNumber(uint32_t value) {
  const bool nvsOk = writeSessionCounterNvs(value);
  const bool fileOk = writeSessionCounterSd(value);
  if (!nvsOk || !fileOk)
    Serial.printf("# SESSION COUNTER WARN,nvs=%u,sd=%u,next=%lu\n", nvsOk ? 1U : 0U, fileOk ? 1U : 0U, (unsigned long)value);
  return nvsOk || fileOk;
}

bool initializeSessionAllocator() {
  uint32_t fileNext = 0;
  const bool fileValid = readSessionCounterFile(fileNext);
  const uint32_t nvsNext = readSessionCounterNvs();
  const uint32_t cardNext = recoverNextSessionNumberFromCard();
  uint32_t candidate = cardNext;
  if (fileValid && fileNext > candidate) candidate = fileNext;
  if (nvsNext > candidate) candidate = nvsNext;
  if (candidate < 1) candidate = 1;
  if (candidate > 10000) candidate = 10000;
  nextSessionNumber = candidate;
  sessionAllocatorReady = persistNextSessionNumber(candidate);
  Serial.printf("# SESSION ALLOCATOR,card_next=%lu,file_next=%lu,nvs_next=%lu,next=%lu,ready=%u\n",
                (unsigned long)cardNext, (unsigned long)(fileValid ? fileNext : 0),
                (unsigned long)nvsNext, (unsigned long)nextSessionNumber,
                sessionAllocatorReady ? 1U : 0U);
  return sessionAllocatorReady;
}

bool reserveNextSessionNumber(uint32_t &sessionNumber) {
  if (!sessionAllocatorReady && !initializeSessionAllocator()) return false;
  uint32_t candidate = nextSessionNumber;
  while (candidate <= 9999U) {
    char candidatePath[32];
    snprintf(candidatePath, sizeof(candidatePath), "/CANLOG/S%04lu", (unsigned long)candidate);
    if (!SD.exists(candidatePath)) {
      // START-PERF1: reserve in NVS before mkdir, then defer the SD mirror until
      // capture is active. Cross-device recovery remains safe because mkdir creates
      // the authoritative Sxxxx directory before any session data is accepted.
      const uint32_t following = candidate + 1U;
      if (!writeSessionCounterNvs(following)) return false;
      nextSessionNumber = following;
      sessionCounterSdSyncValue = following;
      sessionCounterSdSyncPending = true;
      sessionNumber = candidate;
      return true;
    }
    ++candidate; // stale counter/collision: walk forward only from the high-water mark.
  }
  return false;
}


static uint32_t currentCanQueueDepthPerf() {
  return canQueue ? (uint32_t)uxQueueMessagesWaiting(canQueue) : 0U;
}

static void sampleRuntimeHeapTelemetry(bool pressureEntry, uint64_t longStorageUs,
                                       uint32_t qBefore, uint32_t qAfter) {
  if (!loggingActive) return;
  const uint32_t freeNow=(uint32_t)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  const uint32_t largestNow=(uint32_t)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  const uint32_t minFreeNow=(uint32_t)heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (sessionMinInternalFree == 0 || minFreeNow < sessionMinInternalFree) sessionMinInternalFree=minFreeNow;
  if (sessionMinInternalLargest == 0 || largestNow < sessionMinInternalLargest) sessionMinInternalLargest=largestNow;
  if (pressureEntry) { pressureEntryFreeHeap=freeNow; pressureEntryLargestBlock=largestNow; }
  if (longStorageUs >= 100000ULL) {
    ++longStorageCount;
    if (longStorageUs >= longStorageElapsedUs) {
      longStorageElapsedUs=longStorageUs; longStorageEventUs=nowMicros64(); longStorageFreeHeap=freeNow; longStorageLargestBlock=largestNow;
      longStorageQueueBefore=qBefore; longStorageQueueAfter=qAfter;
    }
  }
}

static void noteStorageTiming(uint64_t elapsedUs, uint64_t &maxField, uint32_t qBefore, uint32_t qAfter) {
  if (elapsedUs > maxField) maxField = elapsedUs;
  if (elapsedUs >= 25000ULL) ++storageTiming.stall_over_25ms;
  if (elapsedUs >= 50000ULL) ++storageTiming.stall_over_50ms;
  if (elapsedUs >= 100000ULL) ++storageTiming.stall_over_100ms;
  if (elapsedUs >= 250000ULL) ++storageTiming.stall_over_250ms;
  if (startTiming.active && startTiming.logging_active_us != 0 && startTiming.steady_state_us == 0 &&
      elapsedUs > startTiming.startup_max_blocking_us) startTiming.startup_max_blocking_us = elapsedUs;
  if (elapsedUs >= maxField) {
    storageTiming.queue_before_max = qBefore;
    storageTiming.queue_after_max = qAfter;
  }
  if (elapsedUs >= 100000ULL) sampleRuntimeHeapTelemetry(false, elapsedUs, qBefore, qAfter);
}

static void consumeCachedSdBytes(uint64_t bytes) {
  if (!sdFreeSpaceCacheValid) return;
  cachedSdFreeBytes = cachedSdFreeBytes > bytes ? cachedSdFreeBytes - bytes : 0;
}

static bool refreshSdFreeSpaceCache() {
  const uint32_t qBefore = currentCanQueueDepthPerf();
  const uint64_t t0 = nowMicros64();
  const uint64_t cardBytes = SD.cardSize();
  const uint64_t usedBytes = SD.usedBytes();
  const uint64_t elapsed = nowMicros64() - t0;
  noteStorageTiming(elapsed, storageTiming.used_bytes_max_us, qBefore, currentCanQueueDepthPerf());
  cachedSdCardBytes = cardBytes;
  cachedSdFreeBytes = cardBytes > usedBytes ? cardBytes - usedBytes : 0;
  sdFreeSpaceCacheValid = cardBytes != 0;
  return sdFreeSpaceCacheValid;
}

static bool ensureSdSpaceForStart() {
  if (!sdFreeSpaceCacheValid || cachedSdFreeBytes < MIN_SD_FREE_BYTES + SD_FREE_EXACT_REFRESH_MARGIN) {
    if (!refreshSdFreeSpaceCache()) return false;
  }
  return cachedSdFreeBytes >= MIN_SD_FREE_BYTES;
}

static void queueBleMetaEvent(uint16_t eventCode, uint16_t sequence, uint8_t opcode,
                              uint8_t status, uint8_t linkState, uint64_t timeUs) {
  if (bleMetaEventQueue == nullptr) { ++bleMetaEventDrops; return; }
  PendingBleMetaEvent event = {eventCode, sequence, opcode, status, linkState, 0, timeUs};
  if (xQueueSend(bleMetaEventQueue, &event, 0) != pdTRUE) ++bleMetaEventDrops;
}

static void serviceBleMetaEvents(uint8_t budget = 4) {
  if (!loggingActive || !sessionMeta.active() || bleMetaEventQueue == nullptr) return;
  PendingBleMetaEvent event;
  while (budget-- && xQueueReceive(bleMetaEventQueue, &event, 0) == pdTRUE)
    sessionMeta.writeBleControlEvent(event.timeUs, event.eventCode, event.sequence, event.opcode,
                                     event.status, event.linkState);
}

static void emitRuntimePerf(uint64_t timeUs) {
  if (!loggingActive || !sessionMeta.active()) return;
  uint64_t values[] = {
    storageTiming.raw_write_max_us, storageTiming.raw_flush_max_us, storageTiming.meta_flush_max_us,
    storageTiming.flush_service_max_us, storageTiming.used_bytes_max_us,
    storageTiming.session_open_open_us, storageTiming.session_open_write_us,
    storageTiming.session_open_close_us, storageTiming.session_open_total_us,
    storageTiming.rotation_max_us, storageTiming.stop_finalize_max_us, storageTiming.postamble_step_max_us,
    storageTiming.stall_over_25ms, storageTiming.stall_over_50ms,
    storageTiming.stall_over_100ms, storageTiming.stall_over_250ms,
    storageTiming.queue_before_max, storageTiming.queue_after_max,
    startTiming.drops_before_first_raw, startTiming.drops_during_postamble,
    startTiming.startup_max_raw_gap_us, startTiming.startup_max_blocking_us,
    postLatchDiagnosticTxAttempts, postLatchDiagnosticTxFrames, externalTesterOwnsSession ? 1ULL : 0ULL,
    externalTesterLastUs, twaiBusErrorCount, twaiArbLostCount, diagnosticEnabled ? 1ULL : 0ULL,
    bleMetaEventDrops, SD_SPI_FREQUENCY
  };
  sessionMeta.writeRuntimePerf(timeUs, values, (uint8_t)(sizeof(values)/sizeof(values[0])));
}

void emitResiliencePerf(uint64_t timeUs) {
  if (!loggingActive || !sessionMeta.active()) return;
  const uint64_t stopRequestToCloseUs = (stopTiming.stop_request_us && stopTiming.session_close_us >= stopTiming.stop_request_us)
      ? stopTiming.session_close_us - stopTiming.stop_request_us : 0ULL;
  const uint64_t pressureCurrentUs = (capturePressureMode && pressureEnterUs) ? nowMicros64() - pressureEnterUs : 0ULL;
  const uint64_t pressureReportedMaxDuration = pressureCurrentUs > pressureMaxDurationUs ? pressureCurrentUs : pressureMaxDurationUs;
  const uint32_t pressureReportedDrops = pressureDropTotal +
      ((capturePressureMode && canQueueDrops >= pressureDropBaseline) ? (canQueueDrops - pressureDropBaseline) : 0U);
  uint64_t values[] = {
    CAN_QUEUE_LENGTH,
    queuePreFreeHeap, queuePreLargestBlock, queuePostFreeHeap, queuePostLargestBlock, queueMinFreeHeap, queueAllocationOk ? 1ULL : 0ULL,
    pressureEntryCount, pressureTotalUs + pressureCurrentUs, pressureReportedMaxDuration, pressureMaxDepth,
    pressureRawRecordsDrained, pressureReportedDrops, capturePressureMode ? 1ULL : 0ULL,
    flushDeferredCount, flushDeferredMaxUs, checkpointDeferredCount, checkpointCoalescedCount,
    startTiming.postamble_begin_us, startTiming.postamble_complete_us, startTiming.steady_state_us,
    stopRequestToCloseUs, lastRawFlushUs, lastMetaFlushUs, storageTiming.stop_finalize_max_us,
    stall650Injected ? 1ULL : 0ULL, stall650StartUs, stall650EndUs,
    stall650QueueBefore, stall650QueueAfter, stall650DropDelta
  };
  sessionMeta.writeResiliencePerf(timeUs, values, (uint8_t)(sizeof(values)/sizeof(values[0])));
}

void emitOptimizationPerf(uint64_t timeUs) {
  if (!loggingActive || !sessionMeta.active()) return;
  uint64_t values[] = {
    tftSoftRenderSkipped, tftGraphRenderSkippedSoftPressure, tftGraphRenderSkippedUnchanged,
    sessionMinInternalFree, sessionMinInternalLargest, pressureEntryFreeHeap, pressureEntryLargestBlock,
    pressureLastEntryUs, pressureLastEntryDepth, pressureLastExitUs, pressureLastExitDepth,
    longStorageFreeHeap, longStorageLargestBlock, longStorageElapsedUs, longStorageEventUs,
    longStorageQueueBefore, longStorageQueueAfter, longStorageCount
  };
  sessionMeta.writeOptimizationPerf(timeUs, values, (uint8_t)(sizeof(values)/sizeof(values[0])));
}

void markStartCommandReceived(uint64_t commandUs, uint16_t sequence = 0, bool bleAckRequired = false) {
  memset(&startTiming, 0, sizeof(startTiming));
  startTiming.active = true;
  startTiming.bleAckRequired = bleAckRequired;
  startTiming.commandSequence = sequence;
  startTiming.start_command_received_us = commandUs;
}

void serviceStartTimingTelemetry() {
  if (!startTiming.active || startTiming.emitted || !loggingActive || !sessionMeta.active()) return;
  if (startTiming.start_ack_us == 0 || startTiming.first_post_start_raw_us == 0 || startTiming.steady_state_us == 0) return;
  const uint64_t nowUs = nowMicros64();
  if (canQueue != nullptr && uxQueueMessagesWaiting(canQueue) > (CAN_QUEUE_LENGTH / 4U) &&
      nowUs - startTiming.first_post_start_raw_us < 500000ULL) return;
  const uint64_t recordUs = nowUs;
  if (!sessionMeta.writeStartTiming(recordUs,
                                    startTiming.start_command_received_us,
                                    startTiming.start_logging_enter_us,
                                    startTiming.session_dir_ready_us,
                                    startTiming.raw_open_us,
                                    startTiming.meta_open_us,
                                    startTiming.logging_active_us,
                                    startTiming.first_post_start_raw_us,
                                    startTiming.start_ack_us,
                                    startTiming.first_raw_frame_time_us)) return;
  Serial.printf("# START TIMING,seq=%u,command=%llu,enter=%llu,dir=%llu,raw=%llu,meta=%llu,active=%llu,first_raw=%llu,ack=%llu,first_frame=%llu,total_us=%llu\n",
                (unsigned)startTiming.commandSequence,
                (unsigned long long)startTiming.start_command_received_us,
                (unsigned long long)startTiming.start_logging_enter_us,
                (unsigned long long)startTiming.session_dir_ready_us,
                (unsigned long long)startTiming.raw_open_us,
                (unsigned long long)startTiming.meta_open_us,
                (unsigned long long)startTiming.logging_active_us,
                (unsigned long long)startTiming.first_post_start_raw_us,
                (unsigned long long)startTiming.start_ack_us,
                (unsigned long long)startTiming.first_raw_frame_time_us,
                (unsigned long long)(startTiming.start_ack_us - startTiming.start_command_received_us));
  emitRuntimePerf(recordUs);
  startTiming.emitted = true;
}

void serviceDeferredStartPostamble() {
  if (!startPostamblePending || !loggingActive || !sessionMeta.active()) return;
  const uint64_t nowUs = nowMicros64();
  if (startTiming.first_post_start_raw_us == 0) {
    const uint32_t pending = canQueue ? (uint32_t)uxQueueMessagesWaiting(canQueue) : 0U;
    if (pending != 0 || nowUs - startTiming.logging_active_us < 250000ULL) return;
    // Quiet/bench session: there is no queued RAW to protect, so do not withhold ACK/postamble forever.
  }
  if (canQueue != nullptr && uxQueueMessagesWaiting(canQueue) > (CAN_QUEUE_LENGTH / 4U)) return;
  const uint64_t stepStartUs = nowUs;
  if (startTiming.postamble_begin_us == 0) startTiming.postamble_begin_us = stepStartUs;

  switch (startPostambleStep) {
    case START_POSTAMBLE_BLE_ACK:
      if (pendingStartBleAck) {
        writeEvent("INFO", "BLE_CAPTURE_START", "deferred_after_first_raw");
        sendBleControlResponse(pendingStartBleCommand, 0, nowMicros64());
        pendingStartBleAck = false;
      }
      ++startPostambleStep;
      break;
    case START_POSTAMBLE_MANIFEST:
      writeManifest(false);
      ++startPostambleStep;
      break;
    case START_POSTAMBLE_COUNTER_MIRROR:
      serviceDeferredSessionCounterSdSync();
      ++startPostambleStep;
      break;
    case START_POSTAMBLE_EVENT:
      writeEvent("INFO", "LOGGING_STARTED", String(sessionDir) + ";state=ARMED_WAIT_CAN");
      ++startPostambleStep;
      break;
    case START_POSTAMBLE_PRESTART_SYNC:
      if (startPostambleSyncIndex < pendingSyncCount) {
        writeSyncRecord(pendingSync[startPostambleSyncIndex++], "BLE_PRESTART");
      } else {
        pendingSyncCount = 0;
        startPostambleSyncIndex = 0;
        ++startPostambleStep;
      }
      break;
    case START_POSTAMBLE_COMPLETE:
      startTiming.postamble_complete_us = nowMicros64();
      ++startPostambleStep;
      break;
    case START_POSTAMBLE_STEADY:
    default:
      startTiming.steady_state_us = nowMicros64();
      startPostamblePending = false;
      emitRuntimePerf(startTiming.steady_state_us);
      serviceStartTimingTelemetry();
      break;
  }
  const uint64_t elapsed = nowMicros64() - stepStartUs;
  noteStorageTiming(elapsed, storageTiming.postamble_step_max_us,
                    currentCanQueueDepthPerf(), currentCanQueueDepthPerf());
}


bool initializeSD() {
  sdSPI.begin(SD_SCK_PIN, SD_MISO_PIN, SD_MOSI_PIN, SD_CS_PIN);
  // v2.4.0 used the SD library default of five descriptors while retaining six
  // session files and opening metadata files. Ten provides measured peak-seven
  // headroom without reserving the 16 descriptors that starved BLE in v2.4.1.
  if (!SD.begin(SD_CS_PIN, sdSPI, SD_SPI_FREQUENCY, "/sd", SD_MAX_OPEN_FILES, false)) {
    Serial.println("# SD initialization failed");
    setLoggerStatus("SD MOUNT FAILED");
    return false;
  }
  if (!SD.exists("/CANLOG") && !SD.mkdir("/CANLOG")) {
    Serial.println("# SD /CANLOG creation failed");
    setLoggerStatus("SD DIR FAILED");
    return false;
  }
  // Build the persistent high-water allocator once at mount time. Normal START
  // no longer scans S0001..Sxxxx.
  if (!initializeSessionAllocator()) {
    Serial.println("# SD session allocator initialization failed");
    setLoggerStatus("SD COUNTER FAILED");
    return false;
  }
  // A powered bench test no longer consumes a session number or creates files.
  sessionDir[0] = '\0';
  loadDistanceBases();
  refreshSdFreeSpaceCache();
  setLoggerStatus("READY / STOPPED");
  Serial.printf("# SD READY,max_open_files=%u,session=deferred\n", SD_MAX_OPEN_FILES);
  return true;
}

bool createSessionDirectory() {
  uint32_t sessionNumber = 0;
  if (!reserveNextSessionNumber(sessionNumber)) {
    sessionDir[0] = '\0';
    return false;
  }
  snprintf(sessionDir, sizeof(sessionDir), "/CANLOG/S%04lu", (unsigned long)sessionNumber);
  if (SD.mkdir(sessionDir)) return true;
  // The ID was intentionally reserved before mkdir; do not roll it back or reuse it.
  sessionDir[0] = '\0';
  return false;
}

bool openRawFile() {
  if (rawFile) rawFile.close();
  snprintf(rawPath, sizeof(rawPath), "%s/RAW_%03u.TCB", sessionDir, rawFileIndex);
  rawFile = SD.open(rawPath, FILE_WRITE);
  if (!rawFile) return false;
  const uint8_t header[16] = {'T','C','B','1', 1,24,0,0, 0,0,0,0, 0,0,0,0};
  if (rawFile.write(header, sizeof(header)) != sizeof(header)) {
    rawFile.close();
    return false;
  }
  rawFilePersistedRecords = 0;
  rawFilePersistedBytes = sizeof(header);
  return true;
}

void closeSessionFiles() {
  if (rawFile) rawFile.close();
  if (decodedFile) decodedFile.close();
  if (diagnosticFile) diagnosticFile.close();
  if (eventFile) eventFile.close();
  if (syncFile) syncFile.close();
  if (externalDiagnosticFile) externalDiagnosticFile.close();
  if (metaFile) metaFile.close();
  sessionMeta.end();
}

void cleanupFailedSession() {
  closeSessionFiles();
  if (sessionDir[0] == 0) return;
  const char *fileNames[] = {
    "RAW_000.TCB", "SESSION.META", "DECODED.CSV", "DIAGNOSTICS.CSV", "EVENTS.CSV",
    "SYNC.CSV", "EXTERNAL_DIAGNOSTICS.CSV", "SESSION.OPEN"
  };
  char path[72];
  for (const char *name : fileNames) {
    snprintf(path, sizeof(path), "%s/%s", sessionDir, name);
    if (SD.exists(path)) SD.remove(path);
  }
  SD.rmdir(sessionDir);
  sessionDir[0] = '\0';
  rawPath[0] = '\0';
}

bool failLogStart(const char *stage) {
  startPostamblePending = false;
  startTiming.active = false;
  sessionMetricsActive = false;
  Serial.printf("# LOG START FAILED,%s\n", stage);
  cleanupFailedSession();
  manifestClosed = true;
  setLoggerStatus("LOG START FAILED");
  return false;
}

bool startLogging() {
  if (loggingActive) return true;
  if (!startTiming.active) markStartCommandReceived(nowMicros64(), 0, false);
  startTiming.start_logging_enter_us = nowMicros64();
  runtimeDistanceReset(sessionDistanceIntegrator, millis());
  live.runDistanceMiles = 0.0; live.runDistanceValid = false; nhw20RunCounterPriorValid = false;
  if (!sdReady) {
    Serial.println("# LOG START FAILED,SD_NOT_READY");
    setLoggerStatus("SD NOT READY");
    return false;
  }

  updateTwaiStatusSnapshot();
  sessionStartReceivedFrames = receivedFrameCount;
  sessionStartTransmittedFrames = transmittedFrameCount;
  sessionStartCanQueueDrops = canQueueDrops;
  sessionStartDiagnosticQueueDrops = diagnosticQueueDrops;
  sessionStartIsotpFlowControlFailures = isotpFlowControlFailures;
  sessionStartTwaiBusErrorCount = twaiBusErrorCount;
  sessionStartTwaiRxMissedCount = twaiRxMissedCount;
  sessionStartTwaiRxOverrunCount = twaiRxOverrunCount;
  sessionStartTwaiTxFailedCount = twaiTxFailedCount;
  sessionStartTwaiArbLostCount = twaiArbLostCount;
  sessionQueueHighWater = canQueue ? (uint32_t)uxQueueMessagesWaiting(canQueue) : 0U;
  sessionMetricsActive = true;
  resetTftSessionMetrics();
  memset(&stopTiming, 0, sizeof(stopTiming));
  memset(&storageTiming, 0, sizeof(storageTiming));
  capturePressureMode = false; pressureEnterUs = 0; pressureEntryCount = 0; pressureTotalUs = 0;
  sessionMinInternalFree = 0; sessionMinInternalLargest = 0; pressureEntryFreeHeap = 0; pressureEntryLargestBlock = 0;
  pressureLastEntryUs = 0; pressureLastEntryDepth = 0; pressureLastExitUs = 0; pressureLastExitDepth = 0;
  longStorageFreeHeap = 0; longStorageLargestBlock = 0; longStorageElapsedUs = 0; longStorageEventUs = 0; longStorageQueueBefore = 0; longStorageQueueAfter = 0; longStorageCount = 0;
  pressureMaxDurationUs = 0; pressureMaxDepth = sessionQueueHighWater; pressureRawRecordsDrained = 0;
  pressureDropBaseline = canQueueDrops; pressureDropTotal = 0;
  routineFlushPending = false; routineFlushDeferredSinceUs = 0; flushDeferredCount = 0; flushDeferredMaxUs = 0;
  checkpointPending = false; checkpointDeferredCount = 0; checkpointCoalescedCount = 0;
  stall650Injected = false; stall650StartUs = 0; stall650EndUs = 0; stall650QueueBefore = 0; stall650QueueAfter = 0; stall650DropDelta = 0;
  externalTesterOwnsSession = false;
  externalTesterLatchPending = false;
  externalTesterLatchUs = 0;
  postLatchDiagnosticTxAttempts = 0;
  postLatchDiagnosticTxFrames = 0;
  nonfiniteDistanceReported = false;

  if (!ensureSdSpaceForStart()) {
    Serial.printf("# LOG START FAILED,SD_SPACE_LOW,%llu\n", (unsigned long long)cachedSdFreeBytes);
    setLoggerStatus("SD SPACE LOW");
    sessionMetricsActive = false;
    return false;
  }

  sessionDir[0] = '\0';
  if (!createSessionDirectory()) return failLogStart("CREATE_SESSION_DIRECTORY");
  startTiming.session_dir_ready_us = nowMicros64();
  rawFileIndex = 0;
  if (!openRawFile()) return failLogStart("RAW_000.TCB");
  startTiming.raw_open_us = nowMicros64();

  rawSequence = 0;
  diagnosticSequence = 0;
  sdLogDrops = 0;
  sdLogDroppedFrames = 0;
  sessionHasCanTraffic = false;
  sessionStartUs = nowMicros64();
  sessionFirstCanUs = 0;
  sessionLastCanUs = 0;
  char path[64];
  snprintf(path, sizeof(path), "%s/SESSION.META", sessionDir);
  metaFile = SD.open(path, FILE_WRITE);
  if (!metaFile) return failLogStart("SESSION.META");
  startTiming.meta_open_us = nowMicros64();
  const uint32_t sessionNumber = (uint32_t)atoi(&sessionDir[9]);
  if (!sessionMeta.begin(metaFile, sessionNumber, sessionStartUs,
                         "Toyota_Hybrid_CYD35_HV_Health",
                         "DEV3.5.0-RAW-META",
                         "CYD35",
                         "RAW-META-R8-FUELTRIP-STARTPERF2-SD25M-STORAGERES2-TFTPERF3-FUELPROFILE1-DTCFAN2-WIFIEXIT1",
                         TOYOTA_CAN_DB_RUNTIME_REVISION,
                         CAN_BITRATE)) {
    return failLogStart("SESSION.META_HEADER");
  }
  char rawName[20];
  snprintf(rawName, sizeof(rawName), "RAW_%03u.TCB", rawFileIndex);
  if (!sessionMeta.writeRawFileOpen(rawFileIndex, rawName, nowMicros64()))
    return failLogStart("SESSION.META_RAW_OPEN");

  // Preserve the forensic crash marker, but time each synchronous stage.
  snprintf(path, sizeof(path), "%s/SESSION.OPEN", sessionDir);
  const uint32_t qBeforeMarker = currentCanQueueDepthPerf();
  const uint64_t markerTotalStart = nowMicros64();
  uint64_t t0 = nowMicros64();
  File marker = SD.open(path, FILE_WRITE);
  storageTiming.session_open_open_us = nowMicros64() - t0;
  if (!marker) return failLogStart("SESSION.OPEN");
  t0 = nowMicros64();
  marker.println("Capture was open. A clean stop removes this marker.");
  storageTiming.session_open_write_us = nowMicros64() - t0;
  t0 = nowMicros64();
  marker.close();
  storageTiming.session_open_close_us = nowMicros64() - t0;
  storageTiming.session_open_total_us = nowMicros64() - markerTotalStart;
  noteStorageTiming(storageTiming.session_open_total_us, storageTiming.session_open_total_us,
                    qBeforeMarker, currentCanQueueDepthPerf());
  consumeCachedSdBytes(4096);

  loggingActive = true;
  startTiming.logging_active_us = nowMicros64();
  manifestClosed = false;
  setLoggerStatus("ARMED / WAIT CAN");
  startPostamblePending = true;
  startPostambleStep = START_POSTAMBLE_BLE_ACK;
  startPostambleSyncIndex = 0;
  if (!startTiming.bleAckRequired) startTiming.start_ack_us = startTiming.logging_active_us;
  Serial.printf("# LOG STARTED,%s,ARMED_WAIT_CAN,files=RAW+SESSION.META,postamble=stepwise,sd_hz=%lu\n",
                sessionDir, (unsigned long)SD_SPI_FREQUENCY);
  return true;
}


void requestLoggingStop(const BleCommand *command, bool closedCleanly) {
  if (!loggingActive || stopTiming.pending) return;
  memset(&stopTiming, 0, sizeof(stopTiming));
  stopTiming.pending = true;
  stopTiming.closedCleanly = closedCleanly;
  stopTiming.stop_request_us = command != nullptr ? command->receiveUs : nowMicros64();
  stopTiming.stop_queue_depth = canQueue ? (uint32_t)uxQueueMessagesWaiting(canQueue) : 0U;
  stopTiming.last_persisted_raw_frame_us = sessionLastPersistedRawFrameUs;
  if (stopTiming.stop_queue_depth > sessionQueueHighWater)
    sessionQueueHighWater = stopTiming.stop_queue_depth;
  if (command != nullptr) {
    stopTiming.bleAckRequired = true;
    stopTiming.command = *command;
  }
  writeEvent("INFO", "LOGGING_STOP_REQUESTED",
             String("queue_depth=") + String(stopTiming.stop_queue_depth));
  setLoggerStatus("STOPPING / DRAIN");
}

void finalizeLoggingStop(bool closedCleanly) {
  if (!loggingActive) return;
  const uint64_t stopFinalizeStartUs = nowMicros64();
  startPostamblePending = false;
  startTiming.active = false;
  // Logging stop does not stop the hardwired live display or its read-only
  // diagnostic scheduler. Display acquisition and SD capture are independent.
  String stopDetails = closedCleanly ? "clean" : "unclean";
  stopDetails += sessionHasCanTraffic ? ";traffic=yes" : ";traffic=no;empty_bench_session=yes";
  stopDetails += ";drained=" + String(stopTiming.stop_frames_drained);
  writeEvent("INFO", "LOGGING_STOPPED", stopDetails);
  flushLogFiles();
  writeManifest(closedCleanly);
  stopTiming.session_close_us = nowMicros64();
  storageTiming.stop_finalize_max_us = max(storageTiming.stop_finalize_max_us, nowMicros64() - stopFinalizeStartUs);
  writeCheckpoint(closedCleanly);
  closeSessionFiles();
  capturePressureMode = false;
  pressureEnterUs = 0;
  loggingActive = false;
  manifestClosed = true;
  if (closedCleanly) {
    char markerPath[64];
    snprintf(markerPath, sizeof(markerPath), "%s/SESSION.OPEN", sessionDir);
    if (SD.exists(markerPath)) SD.remove(markerPath);
  }
  char closedStatus[28];
  snprintf(closedStatus, sizeof(closedStatus), "%s CLOSED%s", sessionName(),
           sessionHasCanTraffic ? "" : " EMPTY");
  setLoggerStatus(closedStatus);
  storageTiming.stop_finalize_max_us = max(storageTiming.stop_finalize_max_us, nowMicros64() - stopFinalizeStartUs);
  externalTesterOwnsSession = false;
  externalTesterLatchPending = false;
  Serial.printf("# LOG CLOSED,%s,records=%llu,traffic=%s,stop_request_us=%llu,queue_at_stop=%lu,drained=%lu,last_raw_us=%llu,close_us=%llu\n",
                sessionDir, (unsigned long long)rawSequence, sessionHasCanTraffic ? "yes" : "no",
                (unsigned long long)stopTiming.stop_request_us,
                (unsigned long)stopTiming.stop_queue_depth,
                (unsigned long)stopTiming.stop_frames_drained,
                (unsigned long long)stopTiming.last_persisted_raw_frame_us,
                (unsigned long long)stopTiming.session_close_us);
}

void servicePendingLoggingStop() {
  if (!stopTiming.pending || !loggingActive) return;
  // FIFO receive queue: once a post-request timestamp is observed, every older
  // frame already accepted for this session has been drained. On a quiet bus,
  // an empty queue is the equivalent completion condition.
  const bool queueEmpty = canQueue == nullptr || uxQueueMessagesWaiting(canQueue) == 0;
  if (!stopTiming.boundaryCrossed && !queueEmpty) return;

  const bool ackRequired = stopTiming.bleAckRequired;
  const BleCommand ackCommand = stopTiming.command;
  const bool clean = stopTiming.closedCleanly;
  finalizeLoggingStop(clean);
  if (ackRequired) sendBleControlResponse(ackCommand, 0, stopTiming.session_close_us);
  stopTiming.pending = false;
  sessionMetricsActive = false;
  // RAW/META close and any BLE STOP ACK have completed. Checkpoint only if queue pressure permits.
  gen2PersistCheckpoint(true);
}

void printSDDirectory(const char *dirname, uint8_t levels) {
  File root = SD.open(dirname);
  if (!root || !root.isDirectory()) {
    Serial.printf("# SD DIR OPEN FAILED,%s\n", dirname);
    return;
  }
  File entry = root.openNextFile();
  while (entry) {
    String entryPath = entry.path();
    bool isDirectory = entry.isDirectory();
    uint64_t entrySize = entry.size();
    entry.close();
    if (isDirectory) {
      Serial.printf("# SD DIR,%s\n", entryPath.c_str());
      if (levels) printSDDirectory(entryPath.c_str(), levels - 1);
    } else {
      Serial.printf("# SD FILE,%s,%llu\n", entryPath.c_str(), entrySize);
    }
    entry = root.openNextFile();
  }
  root.close();
}

void printSDCardSummary() {
  if (!sdFreeSpaceCacheValid) refreshSdFreeSpaceCache();
  const uint64_t used = cachedSdCardBytes > cachedSdFreeBytes ? cachedSdCardBytes - cachedSdFreeBytes : 0;
  Serial.printf("# SD CARD,%llu MB total,%llu MB used,spi_hz=%lu\n",
                cachedSdCardBytes / (1024ULL * 1024ULL), used / (1024ULL * 1024ULL),
                (unsigned long)SD_SPI_FREQUENCY);
  if (PRINT_SD_DIRECTORY_AT_BOOT) {
    Serial.println("# SD DIRECTORY LIST BEGIN");
    printSDDirectory("/", 3);
    Serial.println("# SD DIRECTORY LIST END");
  }
}


void rotateRawFileIfNeeded() {
  if (!loggingActive || !rawFile || rawFilePersistedBytes < RAW_ROTATE_BYTES) return;
  const uint32_t qBefore = currentCanQueueDepthPerf();
  const uint64_t rotateStart = nowMicros64();
  rawFile.flush();
  if (sessionMeta.active())
    sessionMeta.writeRawFileClose(rawFileIndex, rawFilePersistedRecords, rawFilePersistedBytes, nowMicros64());
  rawFile.close();
  ++rawFileIndex;
  if (!openRawFile()) {
    ++sdLogDrops;
    writeEvent("ERROR", "RAW_ROTATION_FAILED", String(rawFileIndex));
    return;
  }
  if (sessionMeta.active()) {
    char rawName[20];
    snprintf(rawName, sizeof(rawName), "RAW_%03u.TCB", rawFileIndex);
    sessionMeta.writeRawFileOpen(rawFileIndex, rawName, nowMicros64());
  }
  noteStorageTiming(nowMicros64()-rotateStart, storageTiming.rotation_max_us, qBefore, currentCanQueueDepthPerf());
}

void writeRawBatch(const CapturedFrame *frames, size_t count) {
  if (!loggingActive || !rawFile || count == 0) return;
  bool firstTrafficInBatch = false;
  for (size_t i = 0; i < count; ++i) {
    if (frames[i].direction != 0) continue;
    if (!sessionHasCanTraffic) {
      sessionHasCanTraffic = true;
      sessionFirstCanUs = frames[i].timeUs;
      firstTrafficInBatch = true;
      setLoggerStatus("LOGGING");
    }
    sessionLastCanUs = frames[i].timeUs;
  }
  const size_t bytes = count * sizeof(CapturedFrame);
  const uint32_t qBefore = currentCanQueueDepthPerf();
  const uint64_t t0 = nowMicros64();
  const size_t written = rawFile.write((const uint8_t *)frames, bytes);
  const uint64_t elapsed = nowMicros64() - t0;
  storageTiming.raw_write_total_us += elapsed;
  ++storageTiming.raw_write_count;
  noteStorageTiming(elapsed, storageTiming.raw_write_max_us, qBefore, currentCanQueueDepthPerf());
  consumeCachedSdBytes(written);
  const size_t persisted = written / sizeof(CapturedFrame);
  rawSequence += persisted;
  rawFilePersistedRecords += persisted;
  rawFilePersistedBytes += written;
  if (persisted > 0) {
    sessionLastPersistedRawFrameUs = frames[persisted - 1].timeUs;
    if (startTiming.active && startTiming.logging_active_us != 0 &&
        nowMicros64() - startTiming.logging_active_us <= 2000000ULL) {
      for (size_t i = 0; i < persisted; ++i) {
        const uint64_t frameUs = frames[i].timeUs;
        if (startTiming.last_startup_raw_frame_time_us != 0 &&
            frameUs > startTiming.last_startup_raw_frame_time_us) {
          const uint64_t gap = frameUs - startTiming.last_startup_raw_frame_time_us;
          if (gap > startTiming.startup_max_raw_gap_us) startTiming.startup_max_raw_gap_us = gap;
        }
        startTiming.last_startup_raw_frame_time_us = frameUs;
      }
    }
  }
  if (written > 0 && startTiming.active && startTiming.first_post_start_raw_us == 0) {
    startTiming.first_post_start_raw_us = nowMicros64();
    startTiming.first_raw_frame_time_us = frames[0].timeUs;
  }
  if (written != bytes) {
    ++sdLogDrops;
    sdLogDroppedFrames += count - persisted;
  }
  if (firstTrafficInBatch)
    writeEvent("INFO", "CAN_TRAFFIC_STARTED", "First received CAN frame committed to RAW");
  rotateRawFileIfNeeded();
  serviceStartTimingTelemetry();
}


void printCsvFloat(File &file, bool valid, float value, uint8_t decimals) {
  if (valid) file.print(value, decimals);
}

void printCsvInt(File &file, bool valid, int32_t value) {
  if (valid) file.print(value);
}

static bool anyConfirmedPassiveFresh(uint32_t nowMs) {
  return passiveMetricFresh(live.passiveEngineRPMValid, live.passiveEngineRPMMs, nowMs, 2000) ||
         passiveMetricFresh(live.passiveCoolantValid, live.passiveCoolantMs, nowMs, 2000) ||
         passiveMetricFresh(live.passiveIntakeValid, live.passiveIntakeMs, nowMs, 2000) ||
         passiveMetricFresh(live.passiveSocValid, live.passiveSocMs, nowMs, 3000) ||
         passiveMetricFresh(live.passivePackVoltageValid, live.passivePackVoltageMs, nowMs, 3000) ||
         passiveMetricFresh(live.passivePackCurrentValid, live.passivePackCurrentMs, nowMs, 3000) ||
         passiveMetricFresh(live.passiveMg1RPMValid, live.passiveMg1RPMMs, nowMs, 2000) ||
         passiveMetricFresh(live.passiveMg2RPMValid, live.passiveMg2RPMMs, nowMs, 2000) ||
         passiveMetricFresh(live.passiveMg1TorqueValid, live.passiveMg1TorqueMs, nowMs, 2000) ||
         passiveMetricFresh(live.passiveMotorTempValid, live.passiveMotorTempMs, nowMs, 3000) ||
         passiveMetricFresh(live.passiveInverterTempValid, live.passiveInverterTempMs, nowMs, 3000) ||
         passiveMetricFresh(live.passiveInverterCoolantValid, live.passiveInverterCoolantMs, nowMs, 3000);
}

const char *dataQualityLabel() {
  uint32_t nowMs = millis();
  bool blockFresh = live.blockVoltageValid && nowMs - live.blockVoltageMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool resistanceFresh = live.resistanceValid && nowMs - live.resistanceMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool tempFresh = live.batteryTempValid && nowMs - live.batteryTempMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool electricalFresh = live.electricalValid && nowMs - live.electricalMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool passiveFresh = anyConfirmedPassiveFresh(nowMs);
  if (vehicleProfile == PROFILE_PRIUS_PHV_GEN1) {
    if (passiveFresh) return "PHV_PASSIVE_CONFIRMED";
    if (blockFresh || resistanceFresh || tempFresh || electricalFresh) return "PHV_DIAG_CONFIRMED";
    return "PHV_STALE";
  }
  if (vehicleProfile == PROFILE_CAMRY_HYBRID_GEN1) {
    if (passiveFresh) return "CAMRY_PASSIVE_CONFIRMED";
    if (blockFresh || resistanceFresh || tempFresh ||
        (live.inverterTempValid && nowMs - live.inverterTempMs < DIAGNOSTIC_DISPLAY_FRESH_MS))
      return "CAMRY_DIAG_CONFIRMED";
    return "CAMRY_STALE";
  }
  if (vehicleProfile != PROFILE_PRIUS_GEN2) return "PROFILE_AMBIGUOUS";
  if (passiveFresh) return "GEN2_PASSIVE_CONFIRMED";
  if (blockFresh || resistanceFresh || electricalFresh ||
      (live.motorTempValid && nowMs - live.motorTempMs < DIAGNOSTIC_DISPLAY_FRESH_MS))
    return "GEN2_DIAG_CONFIRMED";
  return "STALE";
}

void writeDecodedSample() {
  uint32_t nowMs = millis();
  bool activeCanTraffic = sessionTrafficRecent();
  // Normalized engineering output uses independent component freshness.
  // A fresh current must never make a stale voltage look fresh (or vice versa).
  bool currentFresh = live.packCurrentValid && nowMs - live.packCurrentMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool voltageFresh = live.packVoltageValid && nowMs - live.packVoltageMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool electrical = currentFresh && voltageFresh;
  bool soc = (live.socValid && nowMs - live.socMs < DIAGNOSTIC_DISPLAY_FRESH_MS) ||
             (live.passiveSocTempValid && nowMs - live.passiveSocTempMs < 2000);
  bool c3 = (live.inverterTempValid && nowMs - live.inverterTempMs < DIAGNOSTIC_DISPLAY_FRESH_MS) ||
            (live.motorTempValid && nowMs - live.motorTempMs < DIAGNOSTIC_DISPLAY_FRESH_MS);
  bool mg1Rpm = live.mg1RPMValid && nowMs - live.mg1RPMMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool mg2Rpm = live.mg2RPMValid && nowMs - live.mg2RPMMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool c4 = live.c4Valid && nowMs - live.c4Ms < 5000;
  bool camryEngine = live.camryEngineValid && nowMs - live.camryEngineMs < 2000;
  bool gear = live.gearValid && nowMs - live.gearMs < 2000;
  bool camryCoolant = live.camryCoolantValid && nowMs - live.camryCoolantMs < 2000;
  bool engine = (live.engineRPMValid && nowMs - live.engineRPMMs < DIAGNOSTIC_DISPLAY_FRESH_MS) || camryEngine;
  bool coolant = (live.coolantValid && nowMs - live.coolantMs < DIAGNOSTIC_DISPLAY_FRESH_MS) || camryCoolant;
  bool engineIntake = live.engineIntakeValid && nowMs - live.engineIntakeMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool catalyst = live.catalystValid && nowMs - live.catalystMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool cf = live.batteryTempValid && nowMs - live.batteryTempMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool d0 = false; // extrema/index columns are legacy; current normal engineering dV is derived from block arrays.
  bool ce = live.blockVoltageValid && nowMs - live.blockVoltageMs < DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool passiveTemps = false; // Passive 0x3CB temperature bytes remain evidence-only; SOC alone is confirmed.

  if (USB_DECODED_CSV && activeCanTraffic) {
    Serial.printf("D,%lu,%s,%u,", (unsigned long)nowMs, profileLabel(vehicleProfile), profileConfidence);
    if (soc) Serial.printf("%.1f", live.socPct);
    Serial.print(','); if (voltageFresh) Serial.printf("%.1f", live.packVolts);
    Serial.print(','); if (currentFresh) Serial.printf("%.2f", live.packAmps);
    Serial.print(','); if (electrical) Serial.printf("%.3f", live.packKW);
    Serial.printf(",%s\n", dataQualityLabel());
  }

  // Do not fill an armed bench session with repeated UNKNOWN/empty rows. Raw
  // capture remains complete, and decoded sampling resumes with live traffic.
  if (!loggingActive || !decodedFile || !activeCanTraffic) return;
  decodedFile.print(nowMs); decodedFile.print(',');
  decodedFile.print(profileLabel(vehicleProfile)); decodedFile.print(',');
  decodedFile.print(profileConfidence); decodedFile.print(',');
  printCsvFloat(decodedFile, soc, live.socPct, 2); decodedFile.print(',');
  printCsvFloat(decodedFile, voltageFresh, live.packVolts, 3); decodedFile.print(',');
  printCsvFloat(decodedFile, currentFresh, live.packAmps, 3); decodedFile.print(',');
  printCsvFloat(decodedFile, electrical, live.packKW, 3); decodedFile.print(',');
  printCsvInt(decodedFile, mg1Rpm, live.mg1RPM); decodedFile.print(',');
  printCsvInt(decodedFile, mg2Rpm, live.mg2RPM); decodedFile.print(',');
  printCsvInt(decodedFile, engine, live.engineRPM); decodedFile.print(',');
  if (gear) decodedFile.print(gearLabel(live.gearCode));
  decodedFile.print(',');
  printCsvFloat(decodedFile, coolant, live.engineCoolantF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, engineIntake, live.engineIntakeAirF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, catalyst, live.catalystB1S1F, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, c4, live.converterTempF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, c3, live.mg1InvF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, c3, live.mg2InvF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, c3, live.mg1StatorF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, c3, live.mg2StatorF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, cf || passiveTemps, live.hvTemp1F, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, cf || passiveTemps, live.hvTemp2F, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, cf, live.hvTemp3F, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, cf || passiveTemps, live.hvAvgF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, cf, live.intakeTempF, 1); decodedFile.print(',');
  printCsvFloat(decodedFile, cf, live.auxVolts, 2); decodedFile.print(',');
  printCsvInt(decodedFile, cf, live.fanLevel); decodedFile.print(',');
  printCsvFloat(decodedFile, cf, live.deltaSocPct, 2); decodedFile.print(',');
  printCsvFloat(decodedFile, d0, live.blockMinV, 2); decodedFile.print(',');
  printCsvInt(decodedFile, d0, live.blockMinNumber); decodedFile.print(',');
  printCsvFloat(decodedFile, d0, live.blockMaxV, 2); decodedFile.print(',');
  printCsvInt(decodedFile, d0, live.blockMaxNumber); decodedFile.print(',');
  printCsvFloat(decodedFile, d0, live.blockDeltaV, 3);
  for (uint8_t i = 0; i < 14; ++i) {
    decodedFile.print(',');
    printCsvFloat(decodedFile, ce, live.blockVolts[i], 2);
  }
  decodedFile.print(','); decodedFile.println(dataQualityLabel());
}

void writeDiagnosticRecord(const char *status, uint64_t completeTimeUs) {
  ++diagnosticSequence;
  if (!loggingActive || !diagnosticFile) return;
  diagnosticFile.print(diagnosticSequence); diagnosticFile.print(',');
  diagnosticFile.printf("%llu", (unsigned long long)diag.requestTimeUs); diagnosticFile.print(',');
  diagnosticFile.printf("%llu", (unsigned long long)completeTimeUs); diagnosticFile.print(',');
  diagnosticFile.print(diag.requestId, HEX); diagnosticFile.print(',');
  diagnosticFile.print(diag.responseId, HEX); diagnosticFile.print(',');
  if (diag.service < 16) diagnosticFile.print('0');
  diagnosticFile.print(diag.service, HEX); diagnosticFile.print(',');
  if (diag.pid < 16) diagnosticFile.print('0');
  diagnosticFile.print(diag.pid, HEX); diagnosticFile.print(',');
  diagnosticFile.print(status); diagnosticFile.print(',');
  diagnosticFile.print(diag.receivedLength); diagnosticFile.print(',');
  for (uint16_t i = 0; i < diag.receivedLength; ++i) {
    if (diag.payload[i] < 16) diagnosticFile.print('0');
    diagnosticFile.print(diag.payload[i], HEX);
  }
  diagnosticFile.print(','); diagnosticFile.print(diag.frameCount); diagnosticFile.print(',');
  diagnosticFile.println((completeTimeUs - diag.requestTimeUs) / 1000.0f, 3);
}

void writeEvent(const char *severity, const char *eventName, const String &details) {
  const uint64_t eventUs = nowMicros64();
  Serial.printf("# EVENT,%llu,%s,%s,%s\n", (unsigned long long)eventUs, severity, eventName, details.c_str());
  if (!loggingActive || !sessionMeta.active()) return;
  const bool profileEvent = strcmp(eventName, "PROFILE_CHANGE") == 0 ||
                            strcmp(eventName, "DATABASE_PROFILE_EVIDENCE") == 0;
  sessionMeta.writeEvent(eventUs, severity, eventName,
                         profileEvent ? (int32_t)vehicleProfile : -1,
                         profileEvent ? (int32_t)profileConfidence : -1);
}

void writeOperatorEvent(const char *severity, const char *eventName, const char *details) {
  const uint64_t eventUs = nowMicros64();
  if (!severity) severity = "INFO";
  if (!eventName) eventName = "OP_EVENT";
  if (!details) details = "";
  Serial.printf("# EVENT,%llu,%s,%s,%s\n", (unsigned long long)eventUs, severity, eventName, details);
  if (!loggingActive || !sessionMeta.active()) return;
  sessionMeta.writeEvent(eventUs, severity, eventName, -1, -1);
}

void writeReadme() {
  // Intentionally omitted in RAW+META mode. The offline preprocessor rebuilds
  // the legacy Evidence Builder package from authoritative RAW plus SESSION.META.
}

void writeSignalsDictionary() {
  // Intentionally omitted in RAW+META mode. Decoder dictionaries remain in the
  // standardized offline database/preprocessor rather than being copied per session.
}

void writeManifest(bool closedCleanly) {
  (void)closedCleanly;
  if (!loggingActive || !sessionMeta.active()) return;
  const uint64_t timeUs = nowMicros64();
  sessionMeta.writeEvent(timeUs, "INFO", "PROFILE_CHANGE",
                         (int32_t)vehicleProfile, (int32_t)profileConfidence);
  sessionMeta.writeDiagnosticState(timeUs, diagnosticEnabled,
                                   (uint32_t)vehicleProfile, (uint32_t)profileConfidence);
  const bool externalRecent = externalTesterLastUs != 0 &&
                              timeUs >= externalTesterLastUs &&
                              timeUs - externalTesterLastUs < EXTERNAL_TESTER_HOLD_MS * 1000ULL;
  sessionMeta.writeBusState(timeUs, twaiNormalMode, CAN_BITRATE, externalRecent ? 1U : 0U);
}

void writeCheckpoint(bool closedCleanly) {
  if (!loggingActive || !sessionMeta.active()) return;
  sampleRuntimeHeapTelemetry();
  updateTwaiStatusSnapshot();
  const uint64_t timeUs = (closedCleanly && stopTiming.session_close_us != 0)
                            ? stopTiming.session_close_us : nowMicros64();
  const uint64_t rxRecords = (uint64_t)(receivedFrameCount - sessionStartReceivedFrames);
  const uint64_t txRecords = (uint64_t)(transmittedFrameCount - sessionStartTransmittedFrames);
  const uint64_t queueDrops = (uint64_t)(canQueueDrops - sessionStartCanQueueDrops);
  const uint32_t diagnosticQueueDropsSession = diagnosticQueueDrops - sessionStartDiagnosticQueueDrops;
  const uint32_t isotpFlowControlFailuresSession = isotpFlowControlFailures - sessionStartIsotpFlowControlFailures;
  const uint32_t twaiBusErrorsSession = twaiBusErrorCount - sessionStartTwaiBusErrorCount;
  const uint32_t twaiRxMissedSession = twaiRxMissedCount - sessionStartTwaiRxMissedCount;
  const uint32_t twaiRxOverrunSession = twaiRxOverrunCount - sessionStartTwaiRxOverrunCount;
  const uint32_t twaiTxFailedSession = twaiTxFailedCount - sessionStartTwaiTxFailedCount;
  const uint32_t twaiArbLostSession = twaiArbLostCount - sessionStartTwaiArbLostCount;
  uint64_t protocolErrorTotal = (uint64_t)diagnosticQueueDropsSession +
                                (uint64_t)isotpFlowControlFailuresSession +
                                (uint64_t)twaiBusErrorsSession;
  if (protocolErrorTotal > 0xFFFFFFFFULL) protocolErrorTotal = 0xFFFFFFFFULL;
  const uint32_t protocolErrors = (uint32_t)protocolErrorTotal;
  sessionMeta.writeCounters(timeUs, rxRecords, txRecords, rawSequence, queueDrops,
                            sdLogDroppedFrames, sessionQueueHighWater, protocolErrors);
  sessionMeta.writeCaptureHealth(timeUs,
                                 diagnosticQueueDropsSession, isotpFlowControlFailuresSession,
                                 twaiBusErrorsSession, twaiRxMissedSession, twaiRxOverrunSession,
                                 twaiTxFailedSession, twaiArbLostSession, sessionQueueHighWater,
                                 stopTiming.stop_request_us, stopTiming.stop_queue_depth,
                                 stopTiming.stop_frames_drained, stopTiming.last_persisted_raw_frame_us,
                                 stopTiming.session_close_us,
                                 tftRenderCalls, tftRenderTotalUs, tftRenderMaxUs,
                                 tftRenderSkippedPressure, tftDirtyRegionsDrawn, tftFullRedraws,
                                 tftQueueDepthBeforeMax, tftQueueDepthAfterMax,
                                 tftDirtyRenderEnabled ? 1ULL : 0ULL,
                                 tftPressureShedEnabled ? 1ULL : 0ULL,
                                 tftBatchTransactionEnabled ? 1ULL : 0ULL,
                                 tftForcedFullRedraws);
  sessionMeta.writeTftPageHealth(timeUs, tftPageRenderCalls, tftPageRenderTotalUs, 12);
  sessionMeta.writeStorageHealth(timeUs, cachedSdCardBytes, cachedSdCardBytes > cachedSdFreeBytes ? cachedSdCardBytes - cachedSdFreeBytes : 0);
  emitRuntimePerf(timeUs);
  emitResiliencePerf(timeUs);
  emitOptimizationPerf(timeUs);
  consumeCachedSdBytes(65536);

  if (closedCleanly) {
    sessionMeta.writeRawFileClose(rawFileIndex, rawFilePersistedRecords, rawFilePersistedBytes, timeUs);
    sessionMeta.writeStreamStop(0, timeUs);
    sessionMeta.writeSessionClose(true, 0, timeUs);
  }
  sessionMeta.flush();
}

void updateTwaiStatusSnapshot() {
  twai_status_info_t status = {};
  if (twai_get_status_info(&status) == ESP_OK) {
    twaiRxMissedCount = status.rx_missed_count;
    twaiRxOverrunCount = status.rx_overrun_count;
    twaiTxFailedCount = status.tx_failed_count;
    twaiArbLostCount = status.arb_lost_count;
    twaiBusErrorCount = status.bus_error_count;
    twaiRxQueued = status.msgs_to_rx;
    twaiTxQueued = status.msgs_to_tx;
  }
}

void serviceTwaiHealth() {
  uint32_t alerts = 0;
  if (twai_read_alerts(&alerts, 0) == ESP_OK && alerts) {
    if (alerts & TWAI_ALERT_BUS_OFF) {
      ++twaiBusOffEvents;
      diagnosticEnabled = false;
      if (diag.active) completeDiagnostic("BUS_OFF");
      writeEvent("ERROR", "TWAI_BUS_OFF", "Diagnostics disabled; automatic recovery requested");
      if (!twaiRecovering && twai_initiate_recovery() == ESP_OK) twaiRecovering = true;
    }
    if (alerts & TWAI_ALERT_BUS_RECOVERED) {
      bool restored = twaiNormalMode ? configureTwai(TWAI_MODE_LISTEN_ONLY) : (twai_start() == ESP_OK);
      twaiRecovering = false;
      writeEvent(restored ? "INFO" : "ERROR", "TWAI_BUS_RECOVERED",
                 restored ? "Controller restarted in passive mode; diagnostics remain off" : "Controller restart failed");
    }
  }

  uint32_t nowMs = millis();
  if (nowMs - lastTwaiStatusMs < TWAI_STATUS_PERIOD_MS) return;
  lastTwaiStatusMs = nowMs;
  updateTwaiStatusSnapshot();
}

void flushLogFiles() {
  if (!loggingActive) return;
  const uint32_t qBefore = currentCanQueueDepthPerf();
  const uint64_t totalStart = nowMicros64();
  if (rawFile) {
    const uint64_t t0 = nowMicros64(); rawFile.flush();
    lastRawFlushUs = nowMicros64() - t0;
    noteStorageTiming(lastRawFlushUs, storageTiming.raw_flush_max_us, qBefore, currentCanQueueDepthPerf());
  }
  if (decodedFile) decodedFile.flush();
  if (diagnosticFile) diagnosticFile.flush();
  if (eventFile) eventFile.flush();
  if (syncFile) syncFile.flush();
  if (externalDiagnosticFile) externalDiagnosticFile.flush();
  if (sessionMeta.active()) {
    const uint64_t t0 = nowMicros64(); sessionMeta.flush();
    lastMetaFlushUs = nowMicros64() - t0;
    noteStorageTiming(lastMetaFlushUs, storageTiming.meta_flush_max_us, qBefore, currentCanQueueDepthPerf());
  }
  lastFlushServiceUs = nowMicros64() - totalStart;
  noteStorageTiming(lastFlushServiceUs, storageTiming.flush_service_max_us, qBefore, currentCanQueueDepthPerf());
}


// ---------------------------- BLE clock/session sync -------------------------
const char *bleStateLabel() {
  switch (bleLinkState) {
    case BLE_LINK_ADVERTISING: return "ADV";
    case BLE_LINK_CONNECTED: return "CON";
    case BLE_LINK_ERROR: return "ERR";
    default: return "INIT";
  }
}

void printHeapStage(const char *stage) {
  Serial.printf("# HEAP,%s,free=%u,largest=%u,min=%u\n",
                stage,
                (unsigned)ESP.getFreeHeap(),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT),
                (unsigned)ESP.getMinFreeHeap());
}

void disableBleSync(const char *stage) {
  bleConnected = false;
  bleServiceReady = false;
  bleLinkState = BLE_LINK_ERROR;
  bleServer = nullptr;
  bleResponseCharacteristic = nullptr;
  Serial.printf("# BLE ERROR,%s; BLE disabled; CAN logger continues\n", stage);
  if (bleStackInitialized) {
    BLEDevice::deinit(true);
    bleStackInitialized = false;
  }
  if (bleSyncQueue != nullptr) {
    vQueueDelete(bleSyncQueue);
    bleSyncQueue = nullptr;
  }
  if (bleCommandQueue != nullptr) {
    vQueueDelete(bleCommandQueue);
    bleCommandQueue = nullptr;
  }
  if (bleMetaEventQueue != nullptr) {
    vQueueDelete(bleMetaEventQueue);
    bleMetaEventQueue = nullptr;
  }
  printHeapStage("BLE_DISABLED");
}

bool initializeBleSync() {
  bleLinkState = BLE_LINK_STARTING;
  uint32_t suffix = (uint32_t)(ESP.getEfuseMac() & 0xFFFF);
  snprintf(bleDeviceName, sizeof(bleDeviceName), "ToyotaCYD-%04X", suffix);
  BLEDevice::init(bleDeviceName);
  bleStackInitialized = true;
  bleServer = BLEDevice::createServer();
  if (bleServer == nullptr) {
    disableBleSync("CREATE_SERVER");
    return false;
  }
  bleServer->setCallbacks(new LoggerBleServerCallbacks());
  BLEService *service = bleServer->createService(BLE_SERVICE_UUID);
  if (service == nullptr) {
    disableBleSync("CREATE_SERVICE");
    return false;
  }
  BLECharacteristic *command = service->createCharacteristic(
      BLE_COMMAND_UUID, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  if (command == nullptr) {
    disableBleSync("CREATE_COMMAND_CHARACTERISTIC");
    return false;
  }
  command->setCallbacks(new LoggerBleCommandCallbacks());
  bleResponseCharacteristic = service->createCharacteristic(
      BLE_RESPONSE_UUID, BLECharacteristic::PROPERTY_NOTIFY | BLECharacteristic::PROPERTY_READ);
  if (bleResponseCharacteristic == nullptr) {
    disableBleSync("CREATE_RESPONSE_CHARACTERISTIC");
    return false;
  }
  bleResponseCharacteristic->addDescriptor(new BLE2902());
  uint8_t initial[20] = {0x80, BLE_PROTOCOL_VERSION};
  bleResponseCharacteristic->setValue(initial, sizeof(initial));
  service->start();
  bleServiceReady = true;
  Serial.printf("# BLE SERVICE READY,%s,advertising=deferred\n", bleDeviceName);
  return true;
}

bool startBleAdvertising() {
  if (!bleServiceReady || !bleStackInitialized) return false;
  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  if (advertising == nullptr) {
    disableBleSync("CREATE_ADVERTISING");
    return false;
  }
  advertising->addServiceUUID(BLE_SERVICE_UUID);
  advertising->setScanResponse(true);
  BLEDevice::startAdvertising();
  bleLinkState = BLE_LINK_ADVERTISING;
  Serial.printf("# BLE READY,%s,%s\n", bleDeviceName, BLE_SERVICE_UUID);
  return true;
}

void writeSyncRecord(const BleSyncRecord &record, const char *source) {
  if (!loggingActive || !sessionMeta.active()) return;
  sessionMeta.writeClockSync(record.sequence, record.receiveUs, record.sendUs, source);
}

void sendBleControlResponse(const BleCommand &command, uint8_t status, uint64_t eventUs) {
  Serial.printf("# BLE CONTROL RESPONSE,seq=%u,opcode=%u,status=%u,logging=%u,event_us=%llu\n",
                command.sequence, command.opcode, status, loggingActive?1U:0U, (unsigned long long)eventUs);
  if (bleResponseCharacteristic == nullptr) return;
  uint8_t response[20] = {};
  response[0] = 0x82;
  response[1] = BLE_PROTOCOL_VERSION;
  writeLe16(&response[2], command.sequence);
  response[4] = status;
  response[5] = loggingActive ? 1 : 0;
  uint32_t sessionNumber = sessionDir[0] ? (uint32_t)atoi(&sessionDir[9]) : 0;
  writeLe32(&response[6], sessionNumber);
  writeLe64(&response[10], eventUs);
  response[18] = diagnosticEnabled ? 1 : 0;
  response[19] = twaiNormalMode ? 1 : 0;
  bleResponseCharacteristic->setValue(response, sizeof(response));
  bleResponseCharacteristic->notify();
  queueBleMetaEvent(30, command.sequence, command.opcode, status, (uint8_t)bleLinkState, nowMicros64()); // notify_attempted
  if (command.opcode == 1 && status == 0 && startTiming.active)
    startTiming.start_ack_us = nowMicros64();
}

void processBleCommand(const BleCommand &command) {
  ++bleCommandCount;
  Serial.printf("# BLE COMMAND RX,seq=%u,opcode=%u,flags=%u,marker=%u,receive_us=%llu,connected=%u\n",
                command.sequence, command.opcode, command.flags, command.marker,
                (unsigned long long)command.receiveUs, bleConnected?1U:0U);
  if (command.opcode == 1) {
    markStartCommandReceived(command.receiveUs, command.sequence, true);
    // BLE starts/stops SD evidence capture only. It does not change the
    // hardwired live-display scheduler or its read-only diagnostic state.
    if (!loggingActive && sdReady) startLogging();
    uint64_t eventUs = nowMicros64();
    if (loggingActive) {
      pendingStartBleAck = true;
      pendingStartBleCommand = command;
    } else {
      sendBleControlResponse(command, sdReady ? 3 : 2, eventUs);
    }
    return;
  }

  if (command.opcode == 2) {
    uint64_t eventUs = nowMicros64();
    if (loggingActive && !stopTiming.pending) {
      requestLoggingStop(&command, true);
      writeEvent("INFO", "BLE_CAPTURE_STOP", "sequence=" + String(command.sequence));
    } else if (!loggingActive) {
      sendBleControlResponse(command, 3, eventUs);
    }
    return;
  }

  if (command.opcode == 3) {
    uint64_t eventUs = nowMicros64();
    if (loggingActive) {
      writeEvent("INFO", "BLE_MARKER", "marker=" + String(command.marker) + ";sequence=" + String(command.sequence));
      sendBleControlResponse(command, 0, eventUs);
    } else {
      sendBleControlResponse(command, 3, eventUs);
    }
    return;
  }

  sendBleControlResponse(command, 1, nowMicros64());
}

void serviceBleSync() {
  if (!capturePressureMode) {
    BleSyncRecord sync;
    while (bleSyncQueue != nullptr && xQueueReceive(bleSyncQueue, &sync, 0) == pdTRUE) {
    ++bleSyncSamples;
    if (loggingActive) {
      writeSyncRecord(sync, "BLE");
    } else if (pendingSyncCount < sizeof(pendingSync) / sizeof(pendingSync[0])) {
      pendingSync[pendingSyncCount++] = sync;
    } else {
      memmove(&pendingSync[0], &pendingSync[1], (pendingSyncCount - 1) * sizeof(BleSyncRecord));
      pendingSync[pendingSyncCount - 1] = sync;
    }
    }
  }

  BleCommand command;
  while (bleCommandQueue != nullptr && xQueueReceive(bleCommandQueue, &command, 0) == pdTRUE)
    processBleCommand(command);
}

// -------------------------------- Display/UI ----------------------------------
static bool signalFresh(bool valid, uint32_t stamp, uint32_t nowMs, uint32_t maxAge = DIAGNOSTIC_DISPLAY_FRESH_MS) {
  return valid && nowMs >= stamp && nowMs - stamp < maxAge;
}

static String fmtMaybe(bool valid, float value, uint8_t decimals = 1) { return valid ? String(value, (unsigned int)decimals) : String("---"); }

static uint32_t currentCanQueueDepth() {
  return canQueue != nullptr ? (uint32_t)uxQueueMessagesWaiting(canQueue) : 0U;
}

static bool shouldShedTftRender(uint32_t nowMs) {
  if (!tftPressureShedEnabled || !loggingActive || canQueue == nullptr) return false;
  const uint32_t depth = currentCanQueueDepth();
  const bool graphPage = displayPage == 5 || displayPage == 6;
  if (depth >= PRESSURE_HIGH) return true;
  if (depth > PRESSURE_LOW) {
    if (graphPage) { ++tftGraphRenderSkippedSoftPressure; return true; }
    if ((uint32_t)(nowMs - tftLastSoftPressureRenderMs) < TFT_SOFT_PRESSURE_INTERVAL_MS) {
      ++tftSoftRenderSkipped; return true;
    }
  }
  return false;
}

void resetTftSessionMetrics() {
  tftRenderCalls = 0;
  tftRenderTotalUs = 0;
  tftRenderMaxUs = 0;
  tftRenderSkippedPressure = 0;
  tftDirtyRegionsDrawn = 0;
  tftFullRedraws = 0;
  tftQueueDepthBeforeMax = 0;
  tftQueueDepthAfterMax = 0;
  tftForcedFullRedraws = 0;
  tftSoftRenderSkipped = 0;
  tftGraphRenderSkippedSoftPressure = 0;
  tftGraphRenderSkippedUnchanged = 0;
  tftLastSoftPressureRenderMs = 0;
  tftLastBlocksSourceMs = 0; tftLastBlocksFreshInitialized = false;
  tftLastTrendHead = 0xFF; tftLastTrendCount = 0xFF;
  for (uint8_t i=0; i<12; ++i) {
    tftPageRenderCalls[i] = 0;
    tftPageRenderTotalUs[i] = 0;
  }
}

static void invalidateTftDirtyCaches() {
  for (uint8_t i=0; i<6; ++i) tftSpeedCache[i] = String();
  for (uint8_t i=0; i<11; ++i) tftWheelCache[i] = String();
  for (uint8_t i=0; i<24; ++i) tftTextPageCache[i] = String();
  tftSocBarCache = -32768;
  tftFuelBarCache = -32768;
  tftLastButtonSignature = 0xFFFFFFFFUL;
}

static void drawDirtyTextBox(String &cache, const String &text,
                             int16_t rx, int16_t ry, int16_t rw, int16_t rh,
                             int16_t dx, int16_t dy, uint8_t font,
                             uint16_t color, uint8_t datum) {
  if (tftDirtyRenderEnabled && !tftForceFullRedraw && cache == text) return;
  tft.fillRect(rx, ry, rw, rh, TFT_BLACK);
  tft.setTextDatum(datum);
  tft.setTextColor(color, TFT_BLACK);
  tft.drawString(text, dx, dy, font);
  cache = text;
  ++tftDirtyRegionsDrawn;
}

static void printTftPerfStats() {
  Serial.printf("# TFT PERF,calls=%llu,total_us=%llu,max_us=%llu,skip_pressure=%llu,dirty_regions=%llu,full=%llu,forced_full=%llu,q_before_max=%llu,q_after_max=%llu,dirty=%u,shed=%u,batch=%u\n",
                (unsigned long long)tftRenderCalls,
                (unsigned long long)tftRenderTotalUs,
                (unsigned long long)tftRenderMaxUs,
                (unsigned long long)tftRenderSkippedPressure,
                (unsigned long long)tftDirtyRegionsDrawn,
                (unsigned long long)tftFullRedraws,
                (unsigned long long)tftForcedFullRedraws,
                (unsigned long long)tftQueueDepthBeforeMax,
                (unsigned long long)tftQueueDepthAfterMax,
                tftDirtyRenderEnabled ? 1U : 0U,
                tftPressureShedEnabled ? 1U : 0U,
                tftBatchTransactionEnabled ? 1U : 0U);
  for (uint8_t page=0; page<12; ++page) {
    const uint64_t calls = tftPageRenderCalls[page];
    const uint64_t avgUs = calls ? tftPageRenderTotalUs[page] / calls : 0;
    Serial.printf("# TFT PAGE,page=%u,calls=%llu,total_us=%llu,avg_us=%llu\n",
                  page, (unsigned long long)calls,
                  (unsigned long long)tftPageRenderTotalUs[page],
                  (unsigned long long)avgUs);
  }
}

static void applyTftPerfCommand(const char *cmd) {
  if (strncmp(cmd, "ODO BASE ", 9) == 0) {
    if (!odoManualEntryAllowed() || loggingActive || capturePressureMode) {
      Serial.println("# ODO BASE REJECTED,PROFILE_OR_LOGGING"); return;
    }
    const double entered=atof(cmd+9);
    if (!isfinite(entered) || entered<0.0 || entered>999999.999) return;
    odoBaseMiles=entered; odoBaseValid=true;
    gen2Persist.odoMiles=entered; gen2Persist.odoValid=true;
    if (gen2Persist.fuelValid) gen2Persist.lastFuelOdoMiles=entered;
    saveDistanceBase(ODO_BASE_NVS_KEY,entered);
    gen2PersistCheckpoint(true);
    Serial.printf("# ODO BASE,%.3f\n",entered); tftLastRenderedPage=0xFF; return;
  }
  if (strncmp(cmd, "TRIP BASE ", 10) == 0) { tripBaseMiles = atof(cmd + 10); tripBaseValid = true; saveDistanceBase(TRIP_BASE_NVS_KEY, tripBaseMiles); Serial.printf("# TRIP BASE,%.3f\n", tripBaseMiles); tftLastRenderedPage=0xFF; return; }
  if (strcmp(cmd, "TRIP RESET") == 0) { tripBaseMiles = 0.0; tripBaseValid = true; runtimeDistanceReset(sessionDistanceIntegrator,millis()); live.runDistanceMiles=0.0; live.runDistanceValid=false; saveDistanceBase(TRIP_BASE_NVS_KEY, tripBaseMiles); tftLastRenderedPage=0xFF; return; }
  if (strcmp(cmd, "TFT DIRTY ON") == 0) tftDirtyRenderEnabled = true;
  else if (strcmp(cmd, "TFT DIRTY OFF") == 0) tftDirtyRenderEnabled = false;
  else if (strcmp(cmd, "TFT SHED ON") == 0) tftPressureShedEnabled = true;
  else if (strcmp(cmd, "TFT SHED OFF") == 0) tftPressureShedEnabled = false;
  else if (strcmp(cmd, "TFT BATCH ON") == 0) tftBatchTransactionEnabled = true;
  else if (strcmp(cmd, "TFT BATCH OFF") == 0) tftBatchTransactionEnabled = false;
  else if (strcmp(cmd, "TFT FULL") == 0) { tftLastRenderedPage = 0xFF; tftForceFullRedraw = true; }
  else if (strcmp(cmd, "TFT STATS") == 0) { printTftPerfStats(); return; }
  else return;
  tftLastRenderedPage = 0xFF;
  tftForceFullRedraw = true;
  Serial.printf("# TFT CFG,dirty=%u,shed=%u,batch=%u\n",
                tftDirtyRenderEnabled ? 1U : 0U,
                tftPressureShedEnabled ? 1U : 0U,
                tftBatchTransactionEnabled ? 1U : 0U);
}

void serviceTftPerfSerial() {
  uint8_t budget = 32;
  while (budget-- && Serial.available() > 0) {
    const char c = (char)Serial.read();
    if (c == '\r' || c == '\n') {
      if (tftPerfSerialLength) {
        tftPerfSerialBuffer[tftPerfSerialLength] = 0;
        applyTftPerfCommand(tftPerfSerialBuffer);
        tftPerfSerialLength = 0;
      }
    } else if (tftPerfSerialLength + 1 < sizeof(tftPerfSerialBuffer)) {
      tftPerfSerialBuffer[tftPerfSerialLength++] = c;
    } else {
      tftPerfSerialLength = 0;
    }
  }
}

void drawStaticUI() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawRect(0, 0, 480, 245, TFT_DARKGREY);
  drawButtons();
}

void serviceHvHealthAccumulator() {
  uint32_t nowMs = millis();
  if (nowMs - hvHealth.lastSampleMs < HV_HEALTH_SAMPLE_INTERVAL_MS) return;
  if (!signalFresh(live.blockVoltageValid, live.blockVoltageMs, nowMs)) return;
  if (live.blockCount == 0 || live.blockCount > MAX_HV_BLOCKS) return;
  hvHealth.lastSampleMs = nowMs;
  hvHealth.sampleCount++;
  hvHealth.spreadSumV += live.blockDeltaV;
  if (live.blockDeltaV > hvHealth.maxSpreadV) hvHealth.maxSpreadV = live.blockDeltaV;
  if (signalFresh(live.electricalValid, live.electricalMs, nowMs)) {
    const float ah = fabsf(live.packAmps) / 3600.0f; // one-second health sample
    if (live.packAmps < -5.0f) { hvHealth.negativeCurrentSamples++; hvHealth.dischargeAh += ah; }
    else if (live.packAmps > 5.0f) { hvHealth.positiveCurrentSamples++; hvHealth.chargeAh += ah; }
  }

  uint8_t lo = 0, hi = 0;
  float sum = 0.0f;
  for (uint8_t i = 0; i < live.blockCount; ++i) {
    sum += live.blockVolts[i];
    if (live.blockVolts[i] < live.blockVolts[lo]) lo = i;
    if (live.blockVolts[i] > live.blockVolts[hi]) hi = i;
  }
  hvHealth.lowestCount[lo]++;
  hvHealth.highestCount[hi]++;
  if (signalFresh(live.electricalValid, live.electricalMs, nowMs)) {
    if (live.packAmps < -5.0f) hvHealth.lowAtNegativeCurrentCount[lo]++;
    if (live.packAmps > 5.0f) hvHealth.highAtPositiveCurrentCount[hi]++;
  }
  float avg = sum / live.blockCount;
  for (uint8_t i = 0; i < live.blockCount; ++i) {
    float dev = fabsf(live.blockVolts[i] - avg);
    if (dev > hvHealth.worstDeviationV[i]) hvHealth.worstDeviationV[i] = dev;
  }

  if (signalFresh(live.batteryTempValid, live.batteryTempMs, nowMs) && live.batteryTempCount > 0) {
    float tMin = live.batteryTempsF[0], tMax = live.batteryTempsF[0];
    for (uint8_t i = 0; i < live.batteryTempCount; ++i) {
      if (live.batteryTempsF[i] < tMin) tMin = live.batteryTempsF[i];
      if (live.batteryTempsF[i] > tMax) tMax = live.batteryTempsF[i];
    }
    if (tMax > hvHealth.maxBatteryTempF) hvHealth.maxBatteryTempF = tMax;
    if (tMax - tMin > hvHealth.maxTempSpreadF) hvHealth.maxTempSpreadF = tMax - tMin;
  }
}

static void serviceTrendSampler() {
  uint32_t nowMs = millis();
  if (nowMs - lastTrendSampleMs < 1000) return;
  lastTrendSampleMs = nowMs;
  TrendSample &s = trendSamples[trendHead];
  s.valid = signalFresh(live.blockVoltageValid, live.blockVoltageMs, nowMs);
  s.spreadV = s.valid ? live.blockDeltaV : 0.0f;
  s.socPct = signalFresh(live.socValid, live.socMs, nowMs) ? live.socPct : NAN;
  s.packAmps = signalFresh(live.electricalValid, live.electricalMs, nowMs) ? live.packAmps : NAN;
  s.packKW = signalFresh(live.electricalValid, live.electricalMs, nowMs) ? live.packKW : NAN;
  s.battMaxF = NAN;
  if (signalFresh(live.batteryTempValid, live.batteryTempMs, nowMs) && live.batteryTempCount) {
    float t = live.batteryTempsF[0];
    for (uint8_t i=1;i<live.batteryTempCount;++i) if (live.batteryTempsF[i] > t) t = live.batteryTempsF[i];
    s.battMaxF = t;
  }
  trendHead = (trendHead + 1) % TREND_SAMPLE_COUNT;
  if (trendCount < TREND_SAMPLE_COUNT) trendCount++;
}

static void drawMiniLine(const float *vals, const bool *valid, uint8_t count, int x, int y, int w, int h, float minV, float maxV, uint16_t color) {
  if (count < 2 || maxV <= minV) return;
  bool havePrev=false; int px=0,py=0;
  for (uint8_t i=0;i<count;++i) {
    if (!valid[i] || isnan(vals[i])) { havePrev=false; continue; }
    float norm=(vals[i]-minV)/(maxV-minV); if(norm<0)norm=0; if(norm>1)norm=1;
    int cx=x + (int)((uint32_t)i*(w-1)/(count-1));
    int cy=y+h-1-(int)(norm*(h-1));
    if(havePrev) tft.drawLine(px,py,cx,cy,color);
    px=cx; py=cy; havePrev=true;
  }
}


// ------------------------ DEV2 speed / wheel UI ---------------------------
// Tire geometry is a display/calculation setting, not part of CAN decoding.
// Default is the common NHW20 195/65R15 fitment and can later be made user-editable.
struct TireGeometry {
  uint16_t widthMm;
  uint8_t aspectPct;
  uint8_t rimIn;
};
static TireGeometry speedTire = {195, 65, 15};

enum SpeedDisplaySource : uint8_t {
  SPEED_SOURCE_AUTO = 0,
  SPEED_SOURCE_VEHICLE,
  SPEED_SOURCE_WHEEL_AVG,
  SPEED_SOURCE_GPS
};
static SpeedDisplaySource speedDisplaySource = SPEED_SOURCE_AUTO;
static float gpsSpeedMph = NAN;
static uint32_t gpsSpeedMs = 0;
static bool gpsSpeedValid = false;

static float tireCircumferenceM(const TireGeometry &t) {
  float sidewallMm = (float)t.widthMm * ((float)t.aspectPct / 100.0f);
  float diameterMm = (float)t.rimIn * 25.4f + 2.0f * sidewallMm;
  return 3.14159265f * diameterMm / 1000.0f;
}

static float wheelRpmFromMph(float mph) {
  float circumferenceM = tireCircumferenceM(speedTire);
  if (circumferenceM <= 0.0f) return NAN;
  return mph * 1609.344f / 60.0f / circumferenceM;
}

static bool vehicleSpeedFresh(uint32_t nowMs) {
  return live.vehicleSpeedValid && nowMs - live.vehicleSpeedMs < 2000;
}

static bool wheelSpeedsFresh(uint32_t nowMs) {
  return live.wheelSpeedValid && nowMs - live.wheelSpeedMs < 2000;
}

static float wheelAverageMph() {
  float sum = 0.0f;
  for (uint8_t i=0; i<4; ++i) sum += live.wheelSpeedMph[i];
  return sum * 0.25f;
}

static float wheelMaxDeltaMph() {
  float lo = live.wheelSpeedMph[0], hi = live.wheelSpeedMph[0];
  for (uint8_t i=1; i<4; ++i) {
    if (live.wheelSpeedMph[i] < lo) lo = live.wheelSpeedMph[i];
    if (live.wheelSpeedMph[i] > hi) hi = live.wheelSpeedMph[i];
  }
  return hi - lo;
}

static bool selectedSpeedMph(uint32_t nowMs, float &mph, const char *&source) {
  bool veh = vehicleSpeedFresh(nowMs);
  bool wheels = wheelSpeedsFresh(nowMs);
  bool gps = gpsSpeedValid && nowMs - gpsSpeedMs < 2000 && !isnan(gpsSpeedMph);
  if (speedDisplaySource == SPEED_SOURCE_VEHICLE && veh) { mph=live.vehicleSpeedMph; source="VEHICLE"; return true; }
  if (speedDisplaySource == SPEED_SOURCE_WHEEL_AVG && wheels) { mph=wheelAverageMph(); source="WHEEL AVG"; return true; }
  if (speedDisplaySource == SPEED_SOURCE_GPS && gps) { mph=gpsSpeedMph; source="GPS"; return true; }
  // AUTO preference: validated vehicle speed, then wheel average, then GPS.
  if (veh) { mph=live.vehicleSpeedMph; source="VEHICLE"; return true; }
  if (wheels) { mph=wheelAverageMph(); source="WHEEL AVG"; return true; }
  if (gps) { mph=gpsSpeedMph; source="GPS"; return true; }
  mph=NAN; source="WAITING FOR VALIDATED SOURCE"; return false;
}

// Decoder-facing setters keep SPEED/WHEELS activation separate from UI code.
// Call these only from a profile-specific decoder that has reached the project's
// normal-display evidence boundary.
static void setValidatedVehicleSpeedMph(float mph, uint32_t nowMs) {
  runtimeDistanceUpdateSpeed(sessionDistanceIntegrator, mph, nowMs);
  if (isnan(mph) || mph < -10.0f || mph > 180.0f) return;
  live.vehicleSpeedMph = mph;
  live.vehicleSpeedMs = nowMs;
  live.vehicleSpeedValid = true;
}

static void setValidatedWheelSpeedsMph(float fl, float fr, float rl, float rr, uint32_t nowMs) {
  const float v[4] = {fl,fr,rl,rr};
  for (uint8_t i=0; i<4; ++i) if (isnan(v[i]) || v[i] < 0.0f || v[i] > 180.0f) return;
  for (uint8_t i=0; i<4; ++i) live.wheelSpeedMph[i] = v[i];
  live.wheelSpeedMs = nowMs;
  live.wheelSpeedValid = true;
}

static void drawSpeedPage(uint32_t nowMs) {
  tft.drawString("SPEED", 10, 8, 2);
  float mph=NAN; const char *source="---";
  bool fresh=selectedSpeedMph(nowMs,mph,source);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(fresh?TFT_YELLOW:TFT_DARKGREY,TFT_BLACK);
  tft.drawString(fresh?String(mph,1):String("---"),240,66,7);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  tft.drawString("MPH",240,111,4);
  tft.setTextDatum(TL_DATUM);

  bool coolant=signalFresh(live.coolantValid,live.coolantMs,nowMs);
  bool eng=signalFresh(live.engineRPMValid,live.engineRPMMs,nowMs);
  bool mg = signalFresh(live.mgPowertrainValid, live.mgPowertrainMs, nowMs);
  bool soc=signalFresh(live.socValid,live.socMs,nowMs) || (live.passiveSocTempValid && nowMs-live.passiveSocTempMs<2000);
  bool hv=signalFresh(live.packVoltageValid,live.packVoltageMs,nowMs);
  bool blocks=signalFresh(live.blockVoltageValid,live.blockVoltageMs,nowMs);
  bool motor=signalFresh(live.motorTempValid,live.motorTempMs,nowMs) ||
             (live.c3Valid && nowMs-live.c3Ms<DIAGNOSTIC_DISPLAY_FRESH_MS);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  tft.drawString(String("ENG ")+(coolant?String(live.engineCoolantF,0)+"F":"---")+"     ICE "+(eng?String(live.engineRPM)+" rpm":"---"),20,138,2);
  tft.drawString(String("MG1 ")+(mg?String(live.mg1RPM)+" rpm":"---")+"   MG2 "+(mg?String(live.mg2RPM)+" rpm":"---"),20,160,2);
  tft.drawString(String("SOC ")+(soc?String(live.socPct,1)+"%":"---"),20,182,2);
  tft.drawString(String("dV ")+(blocks?String(live.blockDeltaV,3)+" V":"---")+"     HV "+(hv?String(live.packVolts,1)+" V":"---"),20,204,2);
  tft.drawString(String("MG1 MOT ")+(motor?String(live.mg1StatorF,0)+"F":"---")+"   MG2 MOT "+(motor?String(live.mg2StatorF,0)+"F":"---"),20,226,2);
}

static void drawSpeedPageDirty(uint32_t nowMs) {
  float mph=NAN; const char *source="---";
  bool fresh=selectedSpeedMph(nowMs,mph,source);
  bool coolant=signalFresh(live.coolantValid,live.coolantMs,nowMs);
  bool eng=signalFresh(live.engineRPMValid,live.engineRPMMs,nowMs);
  bool mg = signalFresh(live.mgPowertrainValid, live.mgPowertrainMs, nowMs);
  bool soc=signalFresh(live.socValid,live.socMs,nowMs) || (live.passiveSocTempValid && nowMs-live.passiveSocTempMs<2000);
  bool hv=signalFresh(live.packVoltageValid,live.packVoltageMs,nowMs);
  bool blocks=signalFresh(live.blockVoltageValid,live.blockVoltageMs,nowMs);
  bool motor=signalFresh(live.motorTempValid,live.motorTempMs,nowMs) ||
             (live.c3Valid && nowMs-live.c3Ms<DIAGNOSTIC_DISPLAY_FRESH_MS);

  if (tftForceFullRedraw) {
    tft.setTextDatum(TL_DATUM); tft.setTextColor(TFT_WHITE,TFT_BLACK);
    tft.drawString("SPEED", 10, 8, 2);
    tft.setTextDatum(MC_DATUM); tft.drawString("MPH",240,111,4); tft.setTextDatum(TL_DATUM);
  }
  drawDirtyTextBox(tftSpeedCache[0], fresh?String(mph,1):String("---"), 70,38,340,64, 240,66,7,
                   fresh?TFT_YELLOW:TFT_DARKGREY, MC_DATUM);
  drawDirtyTextBox(tftSpeedCache[1], String("ENG ")+(coolant?String(live.engineCoolantF,0)+"F":"---")+"     ICE "+(eng?String(live.engineRPM)+" rpm":"---"),
                   18,134,448,20,20,138,2,TFT_WHITE,TL_DATUM);
  drawDirtyTextBox(tftSpeedCache[2], String("MG1 ")+(mg?String(live.mg1RPM)+" rpm":"---")+"   MG2 "+(mg?String(live.mg2RPM)+" rpm":"---"),
                   18,156,448,20,20,160,2,TFT_WHITE,TL_DATUM);
  drawDirtyTextBox(tftSpeedCache[3], String("SOC ")+(soc?String(live.socPct,1)+"%":"---"),
                   18,178,448,20,20,182,2,TFT_WHITE,TL_DATUM);
  drawDirtyTextBox(tftSpeedCache[4], String("dV ")+(blocks?String(live.blockDeltaV,3)+" V":"---")+"     HV "+(hv?String(live.packVolts,1)+" V":"---"),
                   18,200,448,20,20,204,2,TFT_WHITE,TL_DATUM);
  drawDirtyTextBox(tftSpeedCache[5], String("MG1 MOT ")+(motor?String(live.mg1StatorF,0)+"F":"---")+"   MG2 MOT "+(motor?String(live.mg2StatorF,0)+"F":"---"),
                   18,222,448,20,20,226,2,TFT_WHITE,TL_DATUM);
  tft.setTextDatum(TL_DATUM);
}

static void drawWheelsPage(uint32_t nowMs) {
  tft.drawString(live.wheelPositionProbable ? "WHEELS (POS P)" : "WHEELS",10,8,2);
  if (!wheelSpeedsFresh(nowMs)) {
    tft.setTextColor(TFT_YELLOW,TFT_BLACK);
    tft.drawString("WAITING FOR VALIDATED WHEEL-SPEED DECODER",20,55,2);
    tft.setTextColor(TFT_WHITE,TFT_BLACK);
    tft.drawString("UI ready for S0077/S0078 confirmed mapping",20,88,2);
    tft.drawString(String("Tire: ")+speedTire.widthMm+"/"+speedTire.aspectPct+" R"+speedTire.rimIn,20,121,2);
    return;
  }
  static const char *lbl[4]={"FL","FR","RL","RR"};
  const int x[4]={120,360,120,360};
  const int y[4]={60,60,145,145};
  tft.setTextDatum(MC_DATUM);
  for(uint8_t i=0;i<4;++i){
    tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawString(lbl[i],x[i],y[i]-28,2);
    tft.setTextColor(TFT_YELLOW,TFT_BLACK); tft.drawString(String(live.wheelSpeedMph[i],1),x[i],y[i],4);
    tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("MPH",x[i],y[i]+25,2);
    tft.drawString(String(wheelRpmFromMph(live.wheelSpeedMph[i]),0)+" RPM",x[i],y[i]+43,1);
  }
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  tft.drawString(String("AVG ")+String(wheelAverageMph(),1)+" MPH",20,216,2);
  tft.drawString(String("MAX d ")+String(wheelMaxDeltaMph(),2)+" MPH",190,216,2);
  tft.drawString(String(speedTire.widthMm)+"/"+String(speedTire.aspectPct)+"R"+String(speedTire.rimIn),390,216,1);
}

static void drawWheelsPageDirty(uint32_t nowMs) {
  const bool wheelsFreshNow = wheelSpeedsFresh(nowMs);
  if (!tftWheelFreshStateInitialized || wheelsFreshNow != tftWheelLastFreshState) {
    if (!tftForceFullRedraw) {
      tft.fillRect(2, 2, 476, 241, TFT_BLACK);
      ++tftFullRedraws;
      tftLastFullRedrawMs = nowMs;
      invalidateTftDirtyCaches();
      tftForceFullRedraw = true;
    }
    tftWheelLastFreshState = wheelsFreshNow;
    tftWheelFreshStateInitialized = true;
  }
  if (tftForceFullRedraw) {
    tft.setTextDatum(TL_DATUM); tft.setTextColor(TFT_WHITE,TFT_BLACK);
    tft.drawString(live.wheelPositionProbable ? "WHEELS (POS P)" : "WHEELS",10,8,2);
  }
  if (!wheelsFreshNow) {
    drawDirtyTextBox(tftWheelCache[0], "WAITING FOR VALIDATED WHEEL-SPEED DECODER", 18,46,448,24,20,55,2,TFT_YELLOW,TL_DATUM);
    drawDirtyTextBox(tftWheelCache[1], "Waiting for profile-confirmed wheel-speed source", 18,78,448,24,20,88,2,TFT_WHITE,TL_DATUM);
    drawDirtyTextBox(tftWheelCache[2], String("Tire: ")+speedTire.widthMm+"/"+speedTire.aspectPct+" R"+speedTire.rimIn, 18,111,448,24,20,121,2,TFT_WHITE,TL_DATUM);
    return;
  }
  static const char *lbl[4]={"FL","FR","RL","RR"};
  const int x[4]={120,360,120,360};
  const int y[4]={60,60,145,145};
  if (tftForceFullRedraw) {
    tft.setTextDatum(MC_DATUM);
    for(uint8_t i=0;i<4;++i){
      tft.setTextColor(TFT_CYAN,TFT_BLACK); tft.drawString(lbl[i],x[i],y[i]-28,2);
      tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("MPH",x[i],y[i]+25,2);
    }
    tft.setTextDatum(TL_DATUM);
  }
  for(uint8_t i=0;i<4;++i){
    drawDirtyTextBox(tftWheelCache[i], String(live.wheelSpeedMph[i],1), x[i]-68,y[i]-14,136,30, x[i],y[i],4,TFT_YELLOW,MC_DATUM);
    drawDirtyTextBox(tftWheelCache[4+i], String(wheelRpmFromMph(live.wheelSpeedMph[i]),0)+" RPM", x[i]-68,y[i]+34,136,16, x[i],y[i]+43,1,TFT_WHITE,MC_DATUM);
  }
  drawDirtyTextBox(tftWheelCache[8], String("AVG ")+String(wheelAverageMph(),1)+" MPH", 18,210,165,22,20,216,2,TFT_WHITE,TL_DATUM);
  drawDirtyTextBox(tftWheelCache[9], String("MAX d ")+String(wheelMaxDeltaMph(),2)+" MPH", 185,210,198,22,190,216,2,TFT_WHITE,TL_DATUM);
  drawDirtyTextBox(tftWheelCache[10], String(speedTire.widthMm)+"/"+String(speedTire.aspectPct)+"R"+String(speedTire.rimIn), 385,210,82,22,390,216,1,TFT_WHITE,TL_DATUM);
  tft.setTextDatum(TL_DATUM);
}

void drawButtons() {
  if (distanceEntryActive) return;
  uint16_t logColor = !loggingActive ? TFT_DARKGREY :
                      (sessionTrafficRecent() ? TFT_GREEN : TFT_ORANGE);
  bool externalRecent = externalTesterLastUs != 0 &&
                        (nowMicros64() - externalTesterLastUs) / 1000ULL < EXTERNAL_TESTER_HOLD_MS;
  bool diagnosticAvailable = diagnosticCanBeEnabledForProfile(vehicleProfile) && !externalRecent;
  uint16_t diagColor = diagnosticEnabled ? (diagnosticIdentityVerified ? TFT_RED : TFT_ORANGE) :
                       (externalRecent ? TFT_CYAN : (diagnosticAvailable ? TFT_BLUE : TFT_DARKGREY));
  const uint32_t buttonSignature = (uint32_t)displayPage | ((uint32_t)loggingActive << 8) |
                                   ((uint32_t)sessionTrafficRecent() << 9) | ((uint32_t)diagnosticEnabled << 10) |
                                   ((uint32_t)diagnosticIdentityVerified << 11) | ((uint32_t)externalRecent << 12) |
                                   ((uint32_t)diagnosticAvailable << 13);
  if (tftDirtyRenderEnabled && !tftForceFullRedraw && buttonSignature == tftLastButtonSignature) return;
  tftLastButtonSignature = buttonSignature;
  tftDirtyRegionsDrawn += 3;
  tft.fillRoundRect(CYD_PAGE_BTN_X, CYD_PAGE_BTN_Y, CYD_PAGE_BTN_W, CYD_PAGE_BTN_H, 6, TFT_DARKCYAN);
  tft.drawRoundRect(CYD_PAGE_BTN_X, CYD_PAGE_BTN_Y, CYD_PAGE_BTN_W, CYD_PAGE_BTN_H, 6, TFT_WHITE);
  tft.fillRoundRect(CYD_LOG_BTN_X, CYD_LOG_BTN_Y, CYD_LOG_BTN_W, CYD_LOG_BTN_H, 6, logColor);
  tft.drawRoundRect(CYD_LOG_BTN_X, CYD_LOG_BTN_Y, CYD_LOG_BTN_W, CYD_LOG_BTN_H, 6, TFT_WHITE);
  tft.fillRoundRect(CYD_DIAG_BTN_X, CYD_DIAG_BTN_Y, CYD_DIAG_BTN_W, CYD_DIAG_BTN_H, 6, diagColor);
  tft.drawRoundRect(CYD_DIAG_BTN_X, CYD_DIAG_BTN_Y, CYD_DIAG_BTN_W, CYD_DIAG_BTN_H, 6, TFT_WHITE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE);
  const char *nextPage = displayPage == 0 ? "SPEED" : displayPage == 1 ? "WHEELS" : displayPage == 2 ? "TEMP PAGE" : displayPage == 3 ? "HV PAGE" : displayPage == 4 ? "BLOCKS" : displayPage == 5 ? "TREND" : displayPage == 6 ? "POWER" : displayPage == 7 ? "HEALTH" : displayPage == 8 ? "SYSTEM" : displayPage == 9 ? "DIAG EXP" : displayPage == 10 ? "FUEL/TRIP" : displayPage == 11 ? "DTC / INF" : displayPage == 12 ? "FAN" : "MAIN";
  tft.drawString(nextPage, 62, 283, 2);
  tft.drawString(loggingActive ? "STOP LOG" : "START LOG", 297, 283, 2);
  const char *diagLabel = diagnosticEnabled ? (diagnosticIdentityVerified ? "DIAG ON" : "DIAG ID") :
                          (externalRecent ? "EXT TESTER" :
                           (diagnosticAvailable ? (profileSupportsActiveDiagnostics(vehicleProfile) ? "DIAG OFF" : "DIAG ID") : "DIAG N/A"));
  tft.drawString(diagLabel, 417, 283, 2);
  tft.setTextDatum(TL_DATUM);
}

static void drawMainPage(uint32_t nowMs) {
  // Driver-at-a-glance MAIN. S0070 moves engine temperature and confirmed
  // NHW20 MG1/MG2/ICE RPM to the upper rows; HV metrics follow beneath.
  bool currentFresh = signalFresh(live.packCurrentValid, live.packCurrentMs, nowMs);
  bool packVoltageFresh = signalFresh(live.packVoltageValid, live.packVoltageMs, nowMs);
  bool powerFresh = currentFresh && packVoltageFresh;
  bool socFresh = signalFresh(live.socValid, live.socMs, nowMs) ||
                  (live.passiveSocTempValid && nowMs - live.passiveSocTempMs < 2000);
  bool engineFresh = signalFresh(live.engineRPMValid, live.engineRPMMs, nowMs);
  bool coolantFresh = signalFresh(live.coolantValid, live.coolantMs, nowMs);
  bool mgFresh = signalFresh(live.mgPowertrainValid, live.mgPowertrainMs, nowMs);
  bool batteryTemps = signalFresh(live.batteryTempValid, live.batteryTempMs, nowMs);
  bool blockFresh = signalFresh(live.blockVoltageValid, live.blockVoltageMs, nowMs);

  tft.drawString("TOYOTA HYBRID - DEV3.5.0 RAW + META", 10, 8, 2);
  tft.drawString("ENG TEMP:", 10, 35, 2);
  tft.drawString("MG1 / MG2 / ICE RPM:", 10, 58, 2);
  tft.drawString("SOC / HV:", 10, 81, 2);
  tft.drawString("CURRENT / POWER:", 10, 104, 2);
  tft.drawString("BLOCK dV / LOW:", 10, 127, 2);
  tft.drawString(vehicleProfile == PROFILE_PRIUS_PHV_GEN1 ? "TI1/TI2/TI3/TI4:" : "HV T1/T2/T3:", 10, 150, 2);
  tft.drawString("VEHICLE / QUALITY:", 10, 173, 2);
  tft.drawString("LOGGER:", 10, 196, 2);
  tft.drawString("TWAI / BLE:", 10, 219, 2);

  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.drawString(coolantFresh ? String(live.engineCoolantF,1)+" F" : "---", 205,35,2);
  String rpmRow;
  if (mgFresh) rpmRow = String(live.mg1RPM)+" / "+String(live.mg2RPM)+" / "+(engineFresh?String(live.engineRPM):String("---"));
  else rpmRow = String("--- / --- / ") + (engineFresh?String(live.engineRPM):String("---"));
  tft.drawString(rpmRow,205,58,2);

  String socHv=(socFresh?String(live.socPct,1)+"%":String("---")); socHv += " / "; socHv += packVoltageFresh?String(live.packVolts,1)+" V":String("--- V");
  tft.drawString(socHv,205,81,2);
  String curPwr=(currentFresh?String(live.packAmps,1)+" A":String("--- A")); curPwr += " / "; curPwr += powerFresh?String(live.packKW,1)+" kW":String("--- kW");
  tft.drawString(curPwr,205,104,2);
  String blockRow=blockFresh?String(live.blockDeltaV,3)+" V / B"+String(live.blockMinNumber):String("---");
  tft.drawString(blockRow,205,127,2);
  if (vehicleProfile == PROFILE_PRIUS_PHV_GEN1 && live.intakeTempCount >= 4 && batteryTemps)
    tft.drawString(String(live.intakeTempsF[0],1)+"/"+String(live.intakeTempsF[1],1)+"/"+String(live.intakeTempsF[2],1)+"/"+String(live.intakeTempsF[3],1),205,150,2);
  else if (batteryTemps)
    tft.drawString(String(live.hvTemp1F,1)+"/"+String(live.hvTemp2F,1)+"/"+String(live.hvTemp3F,1),205,150,2);
  else tft.drawString("---",205,150,2);

  bool recognizedProfile = vehicleProfile == PROFILE_PRIUS_GEN2 || vehicleProfile == PROFILE_PRIUS_PHV_GEN1 || vehicleProfile == PROFILE_CAMRY_HYBRID_GEN1;
  tft.setTextColor(recognizedProfile?TFT_GREEN:TFT_YELLOW,TFT_BLACK);
  tft.drawString(String(profileLabel(vehicleProfile))+" "+String(profileConfidence)+"% / "+dataQualityLabel(),205,173,2);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  String logText = loggingActive ? String(sessionName()) + (sessionTrafficRecent()?" LOG":" WAIT") : String(loggerStatus);
  tft.drawString(logText,205,196,2);
  bool ext = externalTesterLastUs != 0 && (nowMicros64()-externalTesterLastUs)/1000ULL < EXTERNAL_TESTER_HOLD_MS;
  String twai = ext ? "EXT TESTER - CYD POLL PAUSED" : (twaiNormalMode?"NORMAL DIAG":"LISTEN 500k"); twai += " / "; twai += bleStateLabel();
  tft.drawString(twai,205,219,2);
}

static void drawTempPage(uint32_t nowMs) {
  tft.drawString("TEMPERATURES (F)", 10, 8, 2);
  const char *labels[] = {"Engine coolant:","Engine intake air:","Catalyst B1S1:","Catalyst B1S2:","Converter:","MG1 / MG2 inverter:","MG1 / MG2 motor:","Battery T1/T2/T3:","Battery intake / avg:"};
  for (uint8_t i=0;i<9;++i) tft.drawString(labels[i],10,32+i*23,2);
  bool coolant = signalFresh(live.coolantValid, live.coolantMs, nowMs);
  bool air = signalFresh(live.engineIntakeValid, live.engineIntakeMs, nowMs);
  bool cat = signalFresh(live.catalystValid, live.catalystMs, nowMs);
  bool cat2 = signalFresh(live.catalystB1S2Valid, live.catalystB1S2Ms, nowMs);
  bool c4 = live.c4Valid && nowMs-live.c4Ms<DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool inv = signalFresh(live.inverterTempValid, live.inverterTempMs, nowMs) || (live.c3Valid && nowMs-live.c3Ms<DIAGNOSTIC_DISPLAY_FRESH_MS);
  bool motor = signalFresh(live.motorTempValid, live.motorTempMs, nowMs) || (live.c3Valid && nowMs-live.c3Ms<DIAGNOSTIC_DISPLAY_FRESH_MS);
  bool batt = signalFresh(live.batteryTempValid, live.batteryTempMs, nowMs) || (live.cfValid && nowMs-live.cfMs<DIAGNOSTIC_DISPLAY_FRESH_MS);
  String v[9];
  v[0]=coolant?String(live.engineCoolantF,1):"---"; v[1]=air?String(live.engineIntakeAirF,1):"---";
  v[2]=cat?String(live.catalystB1S1F,1):"---"; v[3]=cat2?String(live.catalystB1S2F,1):"---";
  if(vehicleProfile==PROFILE_PRIUS_PHV_GEN1){if(cat)v[2]+=" P"; if(cat2)v[3]+=" P";}
  v[4]=c4?String(live.converterTempF,1):"---";
  v[5]=inv?String(live.mg1InvF,1)+" / "+String(live.mg2InvF,1):"---";
  if(vehicleProfile==PROFILE_PRIUS_PHV_GEN1&&live.inverterCoolantF>-100.0f&&live.inverterCoolantF<400.0f)v[5]+=" / "+String(live.inverterCoolantF,1);
  v[6]=motor?String(live.mg1StatorF,1)+" / "+String(live.mg2StatorF,1):"---";
  if(batt&&live.batteryTempCount>=4)v[7]=String(live.batteryTempsF[0],1)+" / "+String(live.batteryTempsF[1],1)+" / "+String(live.batteryTempsF[2],1)+" / "+String(live.batteryTempsF[3],1); else if(batt)v[7]=String(live.hvTemp1F,1)+" / "+String(live.hvTemp2F,1)+" / "+String(live.hvTemp3F,1); else v[7]="---";
  if(vehicleProfile==PROFILE_PRIUS_PHV_GEN1&&batt&&live.intakeTempCount>=4)v[8]=String(live.intakeTempsF[0],1)+" / "+String(live.intakeTempsF[1],1)+" / "+String(live.intakeTempsF[2],1)+" / "+String(live.intakeTempsF[3],1); else {v[8]=batt?String(live.intakeTempF,1)+" / "+String(live.hvAvgF,1):String("---"); if(batt&&vehicleProfile==PROFILE_PRIUS_GEN2)v[8]+=" P-intake";}
  tft.setTextColor(TFT_YELLOW,TFT_BLACK);
  for(uint8_t i=0;i<9;++i)tft.drawString(v[i],230,32+i*23,2);
}

static void drawHvPage(uint32_t nowMs) {
  tft.drawString("HV - CONFIRMED VALUES", 10, 8, 2);
  bool vFresh = signalFresh(live.blockVoltageValid, live.blockVoltageMs, nowMs);
  bool pFresh = signalFresh(live.packVoltageValid, live.packVoltageMs, nowMs);
  bool rFresh = signalFresh(live.resistanceValid, live.resistanceMs, nowMs);
  bool sFresh = signalFresh(live.socValid, live.socMs, nowMs);
  bool eFresh = signalFresh(live.packCurrentValid, live.packCurrentMs, nowMs);
  String summary = "SOC "; summary += sFresh ? String(live.socPct,1)+"%" : "--";
  summary += "  I "; summary += eFresh ? String(live.packAmps,1)+"A" : "--";
  summary += "  dV "; summary += vFresh ? String(live.blockDeltaV,3)+"V" : "--";
  tft.drawString(summary, 10, 30, 2);
  String pack = "Pack "; pack += pFresh ? String(live.packVolts,1)+"V" : "--"; pack += "  Blocks "; pack += String(live.blockCount);
  tft.drawString(pack, 10, 48, 2);
  uint8_t count = live.blockCount;
  if (count == 0 || count > MAX_HV_BLOCKS || !vFresh) { tft.drawString("No fresh confirmed block array", 10, 82, 2); return; }
  uint8_t leftCount = (count + 1) / 2;
  for (uint8_t row = 0; row < leftCount; ++row) {
    uint8_t i = row;
    char line[32];
    if (rFresh) snprintf(line,sizeof(line),"V%02u %5.2f  R%02u %4.1fm",i+1,live.blockVolts[i],i+1,live.internalResistance[i]*1000.0f);
    else snprintf(line,sizeof(line),"V%02u %5.2f  R%02u --",i+1,live.blockVolts[i],i+1);
    tft.drawString(line, 10, 70 + row*19, 2);
    uint8_t j = i + leftCount;
    if (j < count) {
      if (rFresh) snprintf(line,sizeof(line),"V%02u %5.2f  R%02u %4.1fm",j+1,live.blockVolts[j],j+1,live.internalResistance[j]*1000.0f);
      else snprintf(line,sizeof(line),"V%02u %5.2f  R%02u --",j+1,live.blockVolts[j],j+1);
      tft.drawString(line, 250, 70 + row*19, 2);
    }
  }
}

static void drawBlocksPage(uint32_t nowMs) {
  const int gx=28,gy=58,gw=430,gh=140;
  const bool fresh=signalFresh(live.blockVoltageValid,live.blockVoltageMs,nowMs);
  if (tftForceFullRedraw) {
    tft.drawString("HV BLOCKS - GRAPH",10,8,2);
    tft.drawRect(gx,gy,gw,gh,TFT_DARKGREY);
  }
  tft.fillRect(8,24,462,26,TFT_BLACK);
  if(!fresh||live.blockCount==0||live.blockCount>MAX_HV_BLOCKS){
    tft.drawString("No fresh confirmed block array",10,38,2);
    tft.fillRect(gx+1,gy+1,gw-2,gh-2,TFT_BLACK);
    tft.fillRect(gx,199,gw,43,TFT_BLACK);
    return;
  }
  float avg=0,minV=live.blockVolts[0],maxV=live.blockVolts[0];
  for(uint8_t i=0;i<live.blockCount;++i){avg+=live.blockVolts[i];if(live.blockVolts[i]<minV)minV=live.blockVolts[i];if(live.blockVolts[i]>maxV)maxV=live.blockVolts[i];}
  avg/=live.blockCount; float span=maxV-minV; if(span<0.10f) span=0.10f; float yMin=minV-span*0.20f, yMax=maxV+span*0.20f;
  char summary[72];
  snprintf(summary,sizeof(summary),"Avg %.3fV  dV %.3fV",avg,live.blockDeltaV);
  tft.drawString(summary,10,30,2);
  // TFT-PERF3: preserve static page furniture and repaint only the dynamic graph interior.
  tft.fillRect(gx+1,gy+1,gw-2,gh-2,TFT_BLACK);
  int avgY=gy+gh-1-(int)((avg-yMin)/(yMax-yMin)*(gh-2)); tft.drawFastHLine(gx+1,avgY,gw-2,TFT_DARKGREY);
  int barW=max(4,(gw-8)/(int)live.blockCount-3);
  for(uint8_t i=0;i<live.blockCount;++i){
    int x=gx+5+i*((gw-8)/(int)live.blockCount); float n=(live.blockVolts[i]-yMin)/(yMax-yMin); if(n<0)n=0;if(n>1)n=1;
    int h=(int)(n*(gh-8)); uint16_t c=(i+1==live.blockMinNumber)?TFT_RED:((i+1==live.blockMaxNumber)?TFT_CYAN:TFT_GREEN);
    tft.fillRect(x,gy+gh-4-h,barW,h,c);
  }
  tft.fillRect(gx,199,gw,16,TFT_BLACK);
  for(uint8_t i=0;i<live.blockCount;++i){int x=gx+5+i*((gw-8)/(int)live.blockCount);tft.drawNumber(i+1,x,203,1);}
  tft.fillRect(8,214,462,28,TFT_BLACK);
  char lowHigh[104];
  snprintf(lowHigh,sizeof(lowHigh),"LOW B%u %.2fV   HIGH B%u %.2fV",live.blockMinNumber,live.blockMinV,live.blockMaxNumber,live.blockMaxV);
  tft.drawString(lowHigh,28,220,2);
}

static void drawHealthPage(uint32_t nowMs) {
  tft.drawString("HV HEALTH - LEARNED",10,8,2);
  float avgSpread=hvHealth.sampleCount?hvHealth.spreadSumV/hvHealth.sampleCount:0.0f;
  tft.drawString(String("Evidence: ")+String(hvHealth.sampleCount)+" s",10,34,2);
  tft.drawString(String("Typical / worst dV: ")+String(avgSpread,3)+" / "+String(hvHealth.maxSpreadV,3)+" V",10,57,2);
  tft.drawString(String("Neg / pos I samples: ")+String(hvHealth.negativeCurrentSamples)+" / "+String(hvHealth.positiveCurrentSamples),10,80,2);
  tft.drawString(String("Neg / pos I integral: ")+String(hvHealth.dischargeAh,2)+" / "+String(hvHealth.chargeAh,2)+" Ah",10,103,2);
  if(hvHealth.maxBatteryTempF>-500)tft.drawString(String("Max temp / spread: ")+String(hvHealth.maxBatteryTempF,1)+" / "+String(hvHealth.maxTempSpreadF,1)+" F",10,126,2);
  else tft.drawString("Max temp / spread: ---",10,126,2);
  if(hvHealth.sampleCount<120||live.blockCount==0){tft.setTextColor(TFT_YELLOW,TFT_BLACK);tft.drawString("ASSESSMENT: EVIDENCE BUILDING",10,158,2);return;}
  uint8_t low=0,regen=0,worst=0;
  for(uint8_t i=1;i<live.blockCount;++i){if(hvHealth.lowAtNegativeCurrentCount[i]>hvHealth.lowAtNegativeCurrentCount[low])low=i;if(hvHealth.highAtPositiveCurrentCount[i]>hvHealth.highAtPositiveCurrentCount[regen])regen=i;if(hvHealth.worstDeviationV[i]>hvHealth.worstDeviationV[worst])worst=i;}
  tft.setTextColor(TFT_CYAN,TFT_BLACK);
  tft.drawString(String("Low @ negative I: B")+String(low+1)+" ("+String(hvHealth.lowAtNegativeCurrentCount[low])+")",10,158,2);
  tft.drawString(String("High @ positive I: B")+String(regen+1)+" ("+String(hvHealth.highAtPositiveCurrentCount[regen])+")",10,181,2);
  tft.drawString(String("Worst deviation: B")+String(worst+1)+" "+String(hvHealth.worstDeviationV[worst],3)+"V",10,204,2);
  tft.drawString("Threshold verdicts disabled pending validated limits",10,225,1);
}

static void drawTrendRingLine(bool ampsMode, int x, int y, int w, int h, float minV, float maxV, uint16_t color) {
  if (trendCount < 2 || maxV <= minV) return;
  bool havePrev=false; int px=0,py=0;
  for(uint8_t i=0;i<trendCount;++i){
    const uint8_t pos=(trendHead + TREND_SAMPLE_COUNT - trendCount + i)%TREND_SAMPLE_COUNT;
    const TrendSample &sample=trendSamples[pos];
    const float value=ampsMode?sample.packAmps:sample.spreadV;
    const bool valid=ampsMode?!isnan(sample.packAmps):sample.valid;
    if(!valid||isnan(value)){havePrev=false;continue;}
    float norm=(value-minV)/(maxV-minV);if(norm<0)norm=0;if(norm>1)norm=1;
    int cx=x+(int)((uint32_t)i*(w-1)/(trendCount-1));
    int cy=y+h-1-(int)(norm*(h-1));
    if(havePrev)tft.drawLine(px,py,cx,cy,color);
    px=cx;py=cy;havePrev=true;
  }
}

static void drawTrendPage(uint32_t nowMs) {
  (void)nowMs;
  if (tftForceFullRedraw) tft.drawString("TREND - LAST 120 s",10,8,2);
  if (trendCount < 2) {
    tft.fillRect(8,26,462,200,TFT_BLACK);
    tft.drawString("Collecting trend samples...",10,40,2);
    return;
  }
  float maxSpread=0.10f, maxAbsA=10.0f;
  for(uint8_t i=0;i<trendCount;++i){
    const uint8_t pos=(trendHead + TREND_SAMPLE_COUNT - trendCount + i)%TREND_SAMPLE_COUNT;
    const TrendSample &sample=trendSamples[pos];
    if(sample.valid && sample.spreadV>maxSpread) maxSpread=sample.spreadV;
    if(!isnan(sample.packAmps) && fabsf(sample.packAmps)>maxAbsA) maxAbsA=fabsf(sample.packAmps);
  }
  // TFT-PERF3: no 1.2 KiB stack staging arrays; repaint only graph interiors once per new trend sample.
  // Borders/axis labels are cheap and are redrawn on each actual 1 Hz trend update so a page entered before sample #2 recovers cleanly.
  tft.drawRect(42,32,425,78,TFT_DARKGREY); tft.drawString("dV",10,55,2);
  tft.drawRect(42,132,425,78,TFT_DARKGREY); tft.drawString("A",18,155,2);
  tft.fillRect(43,33,423,76,TFT_BLACK);
  tft.fillRect(43,133,423,76,TFT_BLACK);
  drawTrendRingLine(false,43,33,423,76,0,maxSpread*1.10f,TFT_YELLOW);
  drawTrendRingLine(true,43,133,423,76,-maxAbsA,maxAbsA,TFT_CYAN);
  tft.fillRect(38,212,432,28,TFT_BLACK);
  char nowLine[80];
  snprintf(nowLine,sizeof(nowLine),"Now dV %.3fV   I %.1fA",live.blockDeltaV,live.packAmps);
  tft.drawString(nowLine,42,216,2);
}

static void drawPowerPage(uint32_t nowMs) {
  tft.drawString("POWER / DRIVETRAIN",10,8,2);
  bool vFresh=signalFresh(live.packVoltageValid,live.packVoltageMs,nowMs);
  bool iFresh=signalFresh(live.packCurrentValid,live.packCurrentMs,nowMs);
  bool elec=vFresh && iFresh;
  bool eng=signalFresh(live.engineRPMValid,live.engineRPMMs,nowMs);
  bool mg=signalFresh(live.mgPowertrainValid,live.mgPowertrainMs,nowMs);
  bool mg1T=live.mg1TorqueValid && nowMs-live.mg1TorqueMs<DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool mg2T=live.mg2TorqueValid && nowMs-live.mg2TorqueMs<DIAGNOSTIC_DISPLAY_FRESH_MS;
  tft.setTextDatum(MC_DATUM); tft.setTextColor(TFT_YELLOW,TFT_BLACK);
  tft.drawString(elec?String(live.packKW,1):String("--.-"),240,58,7);
  tft.drawString("kW",240,100,2); tft.setTextDatum(TL_DATUM);
  tft.setTextColor(TFT_WHITE,TFT_BLACK);
  tft.drawString(String("HV: ")+(vFresh?String(live.packVolts,1)+" V":String("--- V"))+" / "+(iFresh?String(live.packAmps,1)+" A":String("--- A")),20,125,2);
  tft.drawString(String("MG1: ")+(mg?String(live.mg1RPM)+" rpm"+(mg1T?String("  ")+String(live.mg1TorqueNm,1)+(live.mg1TorqueProbable?" Nm P":" Nm"):String("")):"---"),20,150,2);
  tft.drawString(String("MG2: ")+(mg?String(live.mg2RPM)+" rpm"+(mg2T?String("  ")+String(live.mg2TorqueNm,1)+" Nm":String("")):"---"),20,175,2);
  tft.drawString(String("ICE: ")+(eng?String(live.engineRPM)+" rpm":"---"),20,200,2);
}

static void drawSystemPage(uint32_t nowMs) {
  tft.drawString("SYSTEM",10,8,2);
  bool coolant=signalFresh(live.coolantValid,live.coolantMs,nowMs);
  bool air=signalFresh(live.engineIntakeValid,live.engineIntakeMs,nowMs);
  bool inv=signalFresh(live.inverterTempValid,live.inverterTempMs,nowMs);
  bool motor=signalFresh(live.motorTempValid,live.motorTempMs,nowMs);
  const char *labels[]={"Engine coolant:","Intake air:","Aux voltage:","Converter:","MG1 inv / motor:","MG2 inv / motor:","Battery fan:","Engine runtime:","Profile:"};
  for(uint8_t i=0;i<9;++i)tft.drawString(labels[i],10,34+i*23,2);
  tft.setTextColor(TFT_YELLOW,TFT_BLACK);
  tft.drawString(coolant?String(live.engineCoolantF,1)+" F":"---",210,34,2);
  tft.drawString(air?String(live.engineIntakeAirF,1)+" F":"---",210,57,2);
  tft.drawString(signalFresh(live.auxVoltsValid,live.auxVoltsMs,nowMs,30000)?String(live.auxVolts,2)+" V":"---",210,80,2);
  tft.drawString((live.c4Valid&&nowMs-live.c4Ms<DIAGNOSTIC_DISPLAY_FRESH_MS)?String(live.converterTempF,1)+" F":"---",210,103,2);
  tft.drawString(inv&&motor?String(live.mg1InvF,1)+" / "+String(live.mg1StatorF,1):"---",210,126,2);
  tft.drawString(inv&&motor?String(live.mg2InvF,1)+" / "+String(live.mg2StatorF,1):"---",210,149,2);
  tft.drawString(String(live.fanLevel),210,172,2);
  if(signalFresh(live.engineRunTimeValid,live.engineRunTimeMs,nowMs,30000)) tft.drawString(String(live.engineRunTimeS)+" s",210,195,2); else tft.drawString("---",210,195,2);
  tft.drawString(String(profileLabel(vehicleProfile))+" "+String(profileConfidence)+"%",210,218,2);
}

static void drawDiagExpPage(uint32_t nowMs) {
  tft.drawString("DIAG EXP - EVIDENCE", 10, 8, 2);
  bool extRecent = externalTesterLastUs != 0 && (nowMicros64()-externalTesterLastUs)/1000ULL < EXTERNAL_TESTER_HOLD_MS;
  tft.drawString(String("External tester: ") + (extRecent ? "ACTIVE - CYD POLL PAUSED" : "idle"), 10, 32, 2);
  tft.drawString("Requests / complete / bundle:", 10, 56, 2);
  tft.drawString(String(externalObserverRequests)+" / "+externalObserverCompleted+" / "+externalObserverBundledDecoded, 245, 56, 2);
  tft.drawString("Matched C / P / candidate:", 10, 80, 2);
  tft.drawString(String(externalObserverDecodedConfirmed)+" / "+externalObserverDecodedProbable+" / "+externalObserverCandidateHits, 245, 80, 2);
  tft.drawString("Unknown / errors / timeouts:", 10, 104, 2);
  tft.drawString(String(externalObserverUnknown)+" / "+externalObserverReassemblyErrors+" / "+externalObserverTimeouts, 245, 104, 2);
  char tuple[64]; snprintf(tuple,sizeof(tuple),"Last %03lX>%03lX %02X %02X len%u",(unsigned long)externalObserverLastRequestId,(unsigned long)externalObserverLastResponseId,externalObserverLastService,externalObserverLastPid,externalObserverLastLength);
  tft.drawString(tuple,10,132,2);
  tft.drawString(String("Grade: ")+externalObserverLastGrade,10,156,2);
  String key = String("Key: ") + externalObserverLastKey; if (key.length()>55) key = key.substring(0,55); tft.drawString(key,10,180,1);
  String poll = String("Poll: ") + (diagnosticEnabled ? activeDiagnosticLastGrade : "OFF") + " / " + activeDiagnosticLastKey;
  if (poll.length() > 66) poll = poll.substring(0,66);
  tft.drawString(poll,10,202,1);
  tft.drawString(String("DB ")+TOYOTA_CAN_DB_RUNTIME_REVISION+" CATALOG "+DB_V055_DIAGNOSTIC_CATALOG_COUNT+" S0047 "+DB_S0047_OBSERVED_DIAGNOSTIC_CANDIDATE_COUNT,10,218,1);
}


// ---------------- TFT PERF2 text-heavy dirty pages ----------------
static void drawMainPageDirty(uint32_t nowMs) {
  bool currentFresh = signalFresh(live.packCurrentValid, live.packCurrentMs, nowMs);
  bool packVoltageFresh = signalFresh(live.packVoltageValid, live.packVoltageMs, nowMs);
  bool powerFresh = currentFresh && packVoltageFresh;
  bool socFresh = signalFresh(live.socValid, live.socMs, nowMs) ||
                  (live.passiveSocTempValid && nowMs - live.passiveSocTempMs < 2000);
  bool engineFresh = signalFresh(live.engineRPMValid, live.engineRPMMs, nowMs);
  bool coolantFresh = signalFresh(live.coolantValid, live.coolantMs, nowMs);
  bool mgFresh = signalFresh(live.mgPowertrainValid, live.mgPowertrainMs, nowMs);
  bool batteryTemps = signalFresh(live.batteryTempValid, live.batteryTempMs, nowMs);
  bool blockFresh = signalFresh(live.blockVoltageValid, live.blockVoltageMs, nowMs);
  if (tftForceFullRedraw) {
    tft.setTextDatum(TL_DATUM); tft.setTextColor(TFT_WHITE,TFT_BLACK);
    tft.drawString("TOYOTA HYBRID - DEV3.5.0 RAW + META",10,8,2);
    const char *labels[]={"ENG TEMP:","MG1 / MG2 / ICE RPM:","SOC / HV:","CURRENT / POWER:","BLOCK dV / LOW:","", "VEHICLE / QUALITY:","LOGGER:","TWAI / BLE:"};
    const int ys[]={35,58,81,104,127,150,173,196,219};
    for(uint8_t i=0;i<9;++i) if(labels[i][0]) tft.drawString(labels[i],10,ys[i],2);
  }
  String rpmRow;
  if (mgFresh) rpmRow=String(live.mg1RPM)+" / "+String(live.mg2RPM)+" / "+(engineFresh?String(live.engineRPM):String("---"));
  else rpmRow=String("--- / --- / ")+(engineFresh?String(live.engineRPM):String("---"));
  String socHv=(socFresh?String(live.socPct,1)+"%":String("---")); socHv+=" / "; socHv+=packVoltageFresh?String(live.packVolts,1)+" V":String("--- V");
  String curPwr=(currentFresh?String(live.packAmps,1)+" A":String("--- A")); curPwr+=" / "; curPwr+=currentFresh?String(live.packKW,1)+" kW":String("--- kW");
  String blockRow=blockFresh?String(live.blockDeltaV,3)+" V / B"+String(live.blockMinNumber):String("---");
  String tempRow;
  if(vehicleProfile==PROFILE_PRIUS_PHV_GEN1 && live.intakeTempCount>=4 && batteryTemps) tempRow=String(live.intakeTempsF[0],1)+"/"+String(live.intakeTempsF[1],1)+"/"+String(live.intakeTempsF[2],1)+"/"+String(live.intakeTempsF[3],1);
  else if(batteryTemps) tempRow=String(live.hvTemp1F,1)+"/"+String(live.hvTemp2F,1)+"/"+String(live.hvTemp3F,1); else tempRow="---";
  drawDirtyTextBox(tftTextPageCache[0], coolantFresh?String(live.engineCoolantF,1)+" F":"---",200,29,270,19,205,35,2,TFT_YELLOW,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[1], rpmRow,200,52,270,19,205,58,2,TFT_YELLOW,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[2], socHv,200,75,270,19,205,81,2,TFT_YELLOW,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[3], curPwr,200,98,270,19,205,104,2,TFT_YELLOW,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[4], blockRow,200,121,270,19,205,127,2,TFT_YELLOW,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[5], vehicleProfile==PROFILE_PRIUS_PHV_GEN1?"TI1/TI2/TI3/TI4:":"HV T1/T2/T3:",8,144,190,19,10,150,2,TFT_WHITE,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[6], tempRow,200,144,270,19,205,150,2,TFT_YELLOW,TL_DATUM);
  bool recognizedProfile=vehicleProfile==PROFILE_PRIUS_GEN2||vehicleProfile==PROFILE_PRIUS_PHV_GEN1||vehicleProfile==PROFILE_CAMRY_HYBRID_GEN1;
  drawDirtyTextBox(tftTextPageCache[7], String(profileLabel(vehicleProfile))+" "+String(profileConfidence)+"% / "+dataQualityLabel(),200,167,270,19,205,173,2,recognizedProfile?TFT_GREEN:TFT_YELLOW,TL_DATUM);
  String logText=loggingActive?String(sessionName())+(sessionTrafficRecent()?" LOG":" WAIT"):String(loggerStatus);
  drawDirtyTextBox(tftTextPageCache[8],logText,200,190,270,19,205,196,2,TFT_WHITE,TL_DATUM);
  bool ext=externalTesterLastUs!=0&&(nowMicros64()-externalTesterLastUs)/1000ULL<EXTERNAL_TESTER_HOLD_MS;
  String twai=ext?"EXT TESTER - CYD POLL PAUSED":(twaiNormalMode?"NORMAL DIAG":"LISTEN 500k"); twai+=" / "; twai+=bleStateLabel();
  drawDirtyTextBox(tftTextPageCache[9],twai,200,213,270,20,205,219,2,ext?TFT_CYAN:TFT_WHITE,TL_DATUM);
}

static void drawTempPageDirty(uint32_t nowMs) {
  if(tftForceFullRedraw){ tft.setTextDatum(TL_DATUM); tft.setTextColor(TFT_WHITE,TFT_BLACK); tft.drawString("TEMPERATURES (F)",10,8,2); const char *labels[]={"Engine coolant:","Engine intake air:","Catalyst B1S1:","Catalyst B1S2:","Converter:","MG1 / MG2 inverter:","MG1 / MG2 motor:","Battery T1/T2/T3:","Battery intake / avg:"}; for(uint8_t i=0;i<9;++i)tft.drawString(labels[i],10,32+i*23,2); }
  bool coolant=signalFresh(live.coolantValid,live.coolantMs,nowMs), air=signalFresh(live.engineIntakeValid,live.engineIntakeMs,nowMs), cat=signalFresh(live.catalystValid,live.catalystMs,nowMs), cat2=signalFresh(live.catalystB1S2Valid,live.catalystB1S2Ms,nowMs);
  bool c4=live.c4Valid&&nowMs-live.c4Ms<DIAGNOSTIC_DISPLAY_FRESH_MS;
  bool inv=signalFresh(live.inverterTempValid,live.inverterTempMs,nowMs)||(live.c3Valid&&nowMs-live.c3Ms<DIAGNOSTIC_DISPLAY_FRESH_MS);
  bool motor=signalFresh(live.motorTempValid,live.motorTempMs,nowMs)||(live.c3Valid&&nowMs-live.c3Ms<DIAGNOSTIC_DISPLAY_FRESH_MS);
  bool batt=signalFresh(live.batteryTempValid,live.batteryTempMs,nowMs)||(live.cfValid&&nowMs-live.cfMs<DIAGNOSTIC_DISPLAY_FRESH_MS);
  String v[9]; v[0]=coolant?String(live.engineCoolantF,1):"---"; v[1]=air?String(live.engineIntakeAirF,1):"---";
  v[2]=cat?String(live.catalystB1S1F,1):"---"; v[3]=cat2?String(live.catalystB1S2F,1):"---";
  if(vehicleProfile==PROFILE_PRIUS_PHV_GEN1){if(cat)v[2]+=" P"; if(cat2)v[3]+=" P";}
  v[4]=c4?String(live.converterTempF,1):"---";
  v[5]=inv?String(live.mg1InvF,1)+" / "+String(live.mg2InvF,1):"---"; if(vehicleProfile==PROFILE_PRIUS_PHV_GEN1&&live.inverterCoolantF>-100.0f&&live.inverterCoolantF<400.0f)v[5]+=" / "+String(live.inverterCoolantF,1);
  v[6]=motor?String(live.mg1StatorF,1)+" / "+String(live.mg2StatorF,1):"---";
  if(batt&&live.batteryTempCount>=4)v[7]=String(live.batteryTempsF[0],1)+" / "+String(live.batteryTempsF[1],1)+" / "+String(live.batteryTempsF[2],1)+" / "+String(live.batteryTempsF[3],1); else if(batt)v[7]=String(live.hvTemp1F,1)+" / "+String(live.hvTemp2F,1)+" / "+String(live.hvTemp3F,1); else v[7]="---";
  if(vehicleProfile==PROFILE_PRIUS_PHV_GEN1&&batt&&live.intakeTempCount>=4)v[8]=String(live.intakeTempsF[0],1)+" / "+String(live.intakeTempsF[1],1)+" / "+String(live.intakeTempsF[2],1)+" / "+String(live.intakeTempsF[3],1); else {v[8]=batt?String(live.intakeTempF,1)+" / "+String(live.hvAvgF,1):String("---"); if(batt&&vehicleProfile==PROFILE_PRIUS_GEN2)v[8]+=" P-intake";}
  for(uint8_t i=0;i<9;++i)drawDirtyTextBox(tftTextPageCache[i],v[i],225,26+i*23,245,19,230,32+i*23,2,TFT_YELLOW,TL_DATUM);
}

static void drawHvPageDirty(uint32_t nowMs) {
  bool vFresh=signalFresh(live.blockVoltageValid,live.blockVoltageMs,nowMs), pFresh=signalFresh(live.packVoltageValid,live.packVoltageMs,nowMs), rFresh=signalFresh(live.resistanceValid,live.resistanceMs,nowMs), sFresh=signalFresh(live.socValid,live.socMs,nowMs), eFresh=signalFresh(live.packCurrentValid,live.packCurrentMs,nowMs);
  uint8_t count=live.blockCount; bool good=vFresh&&count>0&&count<=MAX_HV_BLOCKS;
  static bool lastGoodInitialized=false; static bool lastGood=false; static uint8_t lastCount=0;
  if (!tftForceFullRedraw && (!lastGoodInitialized || good!=lastGood || (good && count!=lastCount))) {
    tft.fillRect(2,2,476,241,TFT_BLACK); ++tftFullRedraws; tftLastFullRedrawMs=nowMs; invalidateTftDirtyCaches(); tftForceFullRedraw=true;
  }
  lastGoodInitialized=true; lastGood=good; lastCount=count;
  if(tftForceFullRedraw){tft.setTextDatum(TL_DATUM);tft.setTextColor(TFT_WHITE,TFT_BLACK);tft.drawString("HV - CONFIRMED VALUES",10,8,2);}
  String summary="SOC ";summary+=sFresh?String(live.socPct,1)+"%":"--";summary+="  I ";summary+=eFresh?String(live.packAmps,1)+"A":"--";summary+="  dV ";summary+=vFresh?String(live.blockDeltaV,3)+"V":"--";
  String pack="Pack ";pack+=pFresh?String(live.packVolts,1)+"V":"--";pack+="  Blocks ";pack+=String(live.blockCount);
  drawDirtyTextBox(tftTextPageCache[0],summary,8,24,460,19,10,30,2,TFT_WHITE,TL_DATUM); drawDirtyTextBox(tftTextPageCache[1],pack,8,42,460,19,10,48,2,TFT_WHITE,TL_DATUM);
  if (!good) {
    drawDirtyTextBox(tftTextPageCache[2],"No fresh confirmed block array",8,70,460,22,10,82,2,TFT_YELLOW,TL_DATUM);
    return;
  }
  uint8_t leftCount=(count+1)/2;
  for(uint8_t row=0;row<9;++row){
    String left="",right=""; if(row<leftCount){uint8_t i=row; char line[32]; if(rFresh)snprintf(line,sizeof(line),"V%02u %5.2f  R%02u %4.1fm",i+1,live.blockVolts[i],i+1,live.internalResistance[i]*1000.0f);else snprintf(line,sizeof(line),"V%02u %5.2f  R%02u --",i+1,live.blockVolts[i],i+1);left=line; uint8_t j=i+leftCount; if(j<count){if(rFresh)snprintf(line,sizeof(line),"V%02u %5.2f  R%02u %4.1fm",j+1,live.blockVolts[j],j+1,live.internalResistance[j]*1000.0f);else snprintf(line,sizeof(line),"V%02u %5.2f  R%02u --",j+1,live.blockVolts[j],j+1);right=line;}}
    drawDirtyTextBox(tftTextPageCache[3+row*2],left,8,64+row*19,232,19,10,70+row*19,2,TFT_WHITE,TL_DATUM);
    drawDirtyTextBox(tftTextPageCache[4+row*2],right,248,64+row*19,222,19,250,70+row*19,2,TFT_WHITE,TL_DATUM);
  }
}

static void drawPowerPageDirty(uint32_t nowMs) {
  bool vFresh=signalFresh(live.packVoltageValid,live.packVoltageMs,nowMs), iFresh=signalFresh(live.packCurrentValid,live.packCurrentMs,nowMs), elec=vFresh&&iFresh, eng=signalFresh(live.engineRPMValid,live.engineRPMMs,nowMs);
  bool mg=signalFresh(live.mgPowertrainValid,live.mgPowertrainMs,nowMs);
  bool mg1T=live.mg1TorqueValid&&nowMs-live.mg1TorqueMs<DIAGNOSTIC_DISPLAY_FRESH_MS, mg2T=live.mg2TorqueValid&&nowMs-live.mg2TorqueMs<DIAGNOSTIC_DISPLAY_FRESH_MS;
  if(tftForceFullRedraw){tft.setTextDatum(TL_DATUM);tft.setTextColor(TFT_WHITE,TFT_BLACK);tft.drawString("POWER / DRIVETRAIN",10,8,2);tft.setTextDatum(MC_DATUM);tft.drawString("kW",240,100,2);tft.setTextDatum(TL_DATUM);}
  drawDirtyTextBox(tftTextPageCache[0],elec?String(live.packKW,1):String("--.-"),70,30,340,60,240,58,7,TFT_YELLOW,MC_DATUM);
  drawDirtyTextBox(tftTextPageCache[1],String("HV: ")+(vFresh?String(live.packVolts,1)+" V":String("--- V"))+" / "+(iFresh?String(live.packAmps,1)+" A":String("--- A")),18,119,450,20,20,125,2,TFT_WHITE,TL_DATUM);
  String mg1=String("MG1: ")+(mg?String(live.mg1RPM)+" rpm"+(mg1T?String("  ")+String(live.mg1TorqueNm,1)+(live.mg1TorqueProbable?" Nm P":" Nm"):String("")):"---");
  String mg2=String("MG2: ")+(mg?String(live.mg2RPM)+" rpm"+(mg2T?String("  ")+String(live.mg2TorqueNm,1)+" Nm":String("")):"---");
  drawDirtyTextBox(tftTextPageCache[2],mg1,18,144,450,20,20,150,2,TFT_WHITE,TL_DATUM);drawDirtyTextBox(tftTextPageCache[3],mg2,18,169,450,20,20,175,2,TFT_WHITE,TL_DATUM);drawDirtyTextBox(tftTextPageCache[4],String("ICE: ")+(eng?String(live.engineRPM)+" rpm":"---"),18,194,450,20,20,200,2,TFT_WHITE,TL_DATUM);drawDirtyTextBox(tftTextPageCache[5],String(""),18,216,450,16,20,222,1,TFT_WHITE,TL_DATUM);
}

static void drawHealthPageDirty(uint32_t nowMs) {
  (void)nowMs; if(tftForceFullRedraw){tft.setTextDatum(TL_DATUM);tft.setTextColor(TFT_WHITE,TFT_BLACK);tft.drawString("HV HEALTH - LEARNED",10,8,2);} float avgSpread=hvHealth.sampleCount?hvHealth.spreadSumV/hvHealth.sampleCount:0.0f;
  String rows[9]; uint16_t colors[9]={TFT_WHITE,TFT_WHITE,TFT_WHITE,TFT_WHITE,TFT_WHITE,TFT_YELLOW,TFT_CYAN,TFT_CYAN,TFT_WHITE};
  rows[0]=String("Evidence: ")+String(hvHealth.sampleCount)+" s";rows[1]=String("Typical / worst dV: ")+String(avgSpread,3)+" / "+String(hvHealth.maxSpreadV,3)+" V";rows[2]=String("Neg / pos I samples: ")+String(hvHealth.negativeCurrentSamples)+" / "+String(hvHealth.positiveCurrentSamples);rows[3]=String("Neg / pos I integral: ")+String(hvHealth.dischargeAh,2)+" / "+String(hvHealth.chargeAh,2)+" Ah";rows[4]=hvHealth.maxBatteryTempF>-500?String("Max temp / spread: ")+String(hvHealth.maxBatteryTempF,1)+" / "+String(hvHealth.maxTempSpreadF,1)+" F":String("Max temp / spread: ---");
  if(hvHealth.sampleCount<120||live.blockCount==0){rows[5]="ASSESSMENT: EVIDENCE BUILDING";rows[6]="";rows[7]="";rows[8]="";}else{uint8_t low=0,regen=0,worst=0;for(uint8_t i=1;i<live.blockCount;++i){if(hvHealth.lowAtNegativeCurrentCount[i]>hvHealth.lowAtNegativeCurrentCount[low])low=i;if(hvHealth.highAtPositiveCurrentCount[i]>hvHealth.highAtPositiveCurrentCount[regen])regen=i;if(hvHealth.worstDeviationV[i]>hvHealth.worstDeviationV[worst])worst=i;}rows[5]=String("Low @ negative I: B")+String(low+1)+" ("+String(hvHealth.lowAtNegativeCurrentCount[low])+")";colors[5]=TFT_CYAN;rows[6]=String("High @ positive I: B")+String(regen+1)+" ("+String(hvHealth.highAtPositiveCurrentCount[regen])+")";rows[7]=String("Worst deviation: B")+String(worst+1)+" "+String(hvHealth.worstDeviationV[worst],3)+"V";rows[8]="Threshold verdicts disabled pending validated limits";}
  const int ys[9]={34,57,80,103,126,158,181,204,225}; for(uint8_t i=0;i<9;++i)drawDirtyTextBox(tftTextPageCache[i],rows[i],8,ys[i]-6,462,(i==8?14:20),10,ys[i],(i==8?1:2),colors[i],TL_DATUM);
}

static void drawSystemPageDirty(uint32_t nowMs) {
  if(tftForceFullRedraw){tft.setTextDatum(TL_DATUM);tft.setTextColor(TFT_WHITE,TFT_BLACK);tft.drawString("SYSTEM",10,8,2);const char *labels[]={"Engine coolant:","Intake air:","Aux voltage:","Converter:","MG1 inv / motor:","MG2 inv / motor:","Battery fan:","Engine runtime:","Profile:"};for(uint8_t i=0;i<9;++i)tft.drawString(labels[i],10,34+i*23,2);}
  bool coolant=signalFresh(live.coolantValid,live.coolantMs,nowMs),air=signalFresh(live.engineIntakeValid,live.engineIntakeMs,nowMs),inv=signalFresh(live.inverterTempValid,live.inverterTempMs,nowMs),motor=signalFresh(live.motorTempValid,live.motorTempMs,nowMs);String v[9];v[0]=coolant?String(live.engineCoolantF,1)+" F":"---";v[1]=air?String(live.engineIntakeAirF,1)+" F":"---";v[2]=signalFresh(live.auxVoltsValid,live.auxVoltsMs,nowMs,30000)?String(live.auxVolts,2)+" V":"---";v[3]=(live.c4Valid&&nowMs-live.c4Ms<DIAGNOSTIC_DISPLAY_FRESH_MS)?String(live.converterTempF,1)+" F":"---";v[4]=inv&&motor?String(live.mg1InvF,1)+" / "+String(live.mg1StatorF,1):"---";v[5]=inv&&motor?String(live.mg2InvF,1)+" / "+String(live.mg2StatorF,1):"---";v[6]=String(live.fanLevel);v[7]=signalFresh(live.engineRunTimeValid,live.engineRunTimeMs,nowMs,30000)?String(live.engineRunTimeS)+" s":"---";v[8]=String(profileLabel(vehicleProfile))+" "+String(profileConfidence)+"%";for(uint8_t i=0;i<9;++i)drawDirtyTextBox(tftTextPageCache[i],v[i],205,28+i*23,265,20,210,34+i*23,2,TFT_YELLOW,TL_DATUM);
}

static void drawDiagExpPageDirty(uint32_t nowMs) {
  (void)nowMs; bool extRecent=externalTesterLastUs!=0&&(nowMicros64()-externalTesterLastUs)/1000ULL<EXTERNAL_TESTER_HOLD_MS;
  if(tftForceFullRedraw){tft.setTextDatum(TL_DATUM);tft.setTextColor(TFT_WHITE,TFT_BLACK);tft.drawString("DIAG EXP - EVIDENCE",10,8,2);tft.drawString("Requests / complete / bundle:",10,56,2);tft.drawString("Matched C / P / candidate:",10,80,2);tft.drawString("Unknown / errors / timeouts:",10,104,2);}
  drawDirtyTextBox(tftTextPageCache[0],extRecent?String("EXT TESTER ACTIVE - CYD POLL PAUSED"):String("External tester: idle"),8,26,462,20,10,32,2,extRecent?TFT_CYAN:TFT_WHITE,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[1],String(externalObserverRequests)+" / "+externalObserverCompleted+" / "+externalObserverBundledDecoded,240,50,230,20,245,56,2,TFT_WHITE,TL_DATUM);drawDirtyTextBox(tftTextPageCache[2],String(externalObserverDecodedConfirmed)+" / "+externalObserverDecodedProbable+" / "+externalObserverCandidateHits,240,74,230,20,245,80,2,TFT_WHITE,TL_DATUM);drawDirtyTextBox(tftTextPageCache[3],String(externalObserverUnknown)+" / "+externalObserverReassemblyErrors+" / "+externalObserverTimeouts,240,98,230,20,245,104,2,TFT_WHITE,TL_DATUM);
  char tuple[64];snprintf(tuple,sizeof(tuple),"Last %03lX>%03lX %02X %02X len%u",(unsigned long)externalObserverLastRequestId,(unsigned long)externalObserverLastResponseId,externalObserverLastService,externalObserverLastPid,externalObserverLastLength);drawDirtyTextBox(tftTextPageCache[4],String(tuple),8,126,462,20,10,132,2,TFT_WHITE,TL_DATUM);drawDirtyTextBox(tftTextPageCache[5],String("Grade: ")+externalObserverLastGrade,8,150,462,20,10,156,2,TFT_WHITE,TL_DATUM);String key=String("Key: ")+externalObserverLastKey;if(key.length()>55)key=key.substring(0,55);drawDirtyTextBox(tftTextPageCache[6],key,8,174,462,14,10,180,1,TFT_WHITE,TL_DATUM);String poll=String("Poll: ")+(diagnosticEnabled?activeDiagnosticLastGrade:"OFF")+" / "+activeDiagnosticLastKey;if(poll.length()>66)poll=poll.substring(0,66);drawDirtyTextBox(tftTextPageCache[7],poll,8,196,462,14,10,202,1,extRecent?TFT_CYAN:TFT_WHITE,TL_DATUM);drawDirtyTextBox(tftTextPageCache[8],String("DB ")+TOYOTA_CAN_DB_RUNTIME_REVISION+" CATALOG "+DB_V055_DIAGNOSTIC_CATALOG_COUNT+" S0047 "+DB_S0047_OBSERVED_DIAGNOSTIC_CANDIDATE_COUNT,8,212,462,14,10,218,1,TFT_WHITE,TL_DATUM);
}


static void drawFuelTripBar(int16_t &cache, bool fresh, uint16_t value, uint16_t maxValue,
                            int16_t x, int16_t y, int16_t w, int16_t h,
                            uint16_t fillColor, const char *overlay) {
  const int16_t signature = fresh ? (int16_t)value : -1;
  if (tftDirtyRenderEnabled && !tftForceFullRedraw && cache == signature) return;
  tft.fillRect(x, y, w, h, TFT_BLACK);
  tft.drawRoundRect(x, y, w, h, 4, TFT_WHITE);
  const uint16_t innerW = (w > 4) ? (uint16_t)(w - 4) : 0;
  const uint16_t fillW = fresh ? fuelTripBarFillPixels(value, maxValue, innerW) : 0;
  if (fillW) tft.fillRect(x + 2, y + 2, fillW, h - 4, fillColor);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(fresh ? TFT_WHITE : TFT_DARKGREY);
  tft.drawString(overlay, x + w / 2, y + h / 2, 4);
  tft.setTextDatum(TL_DATUM);
  cache = signature;
  ++tftDirtyRegionsDrawn;
}

static void drawFuelTripSocPageDirty(uint32_t nowMs) {
  const bool socFresh = signalFresh(live.socValid, live.socMs, nowMs, 10000U);
  const bool odoFresh = live.odometerValid && (uint32_t)(nowMs-live.odometerMs) < 10000U;
  const bool fuelFresh = live.fuelValid && (uint32_t)(nowMs-live.fuelMs) < 10000U;
  double sessionMiles = (vehicleProfile==PROFILE_PRIUS_GEN2 && live.runDistanceValid) ? live.runDistanceMiles : sessionDistanceIntegrator.miles;
  if (!isfinite(sessionMiles)) {
    if (!nonfiniteDistanceReported) { writeEvent("ERROR", "NONFINITE_DISTANCE", "sessionMiles"); nonfiniteDistanceReported = true; }
    sessionMiles = 0.0;
  }
  const bool gen2SavedOdo = vehicleProfile==PROFILE_PRIUS_GEN2 &&
      gen2Persist.variant==nhw20Variant && gen2Persist.odoValid;
  const double shownOdo = odoFresh ? live.odometerMiles :
      (gen2SavedOdo ? gen2Persist.odoMiles :
       (nhw20EarlyProfileConfirmed() && odoBaseValid ? odoBaseMiles+sessionMiles : -1.0));
  double shownTrip = tripBaseValid ? tripBaseMiles + sessionMiles : sessionMiles;
  if (!isfinite(shownTrip)) {
    if (!nonfiniteDistanceReported) { writeEvent("ERROR", "NONFINITE_DISTANCE", "shownTrip"); nonfiniteDistanceReported = true; }
    shownTrip = 0.0;
  }
  if (tftForceFullRedraw) {
    tft.setTextDatum(TL_DATUM); tft.setTextColor(TFT_WHITE,TFT_BLACK);
    tft.drawString("FUEL / TRIP / SOC",10,8,2);
    tft.drawString("SOC",12,40,2); tft.drawString("FUEL",12,105,2);
    tft.drawString("ODO",250,40,2); tft.drawString("TRIP",250,90,2); tft.drawString("SESSION",250,140,2);
  }

  char socOverlay[12];
  const int socWhole = socFresh ? fuelTripSocWholePercent(live.socPct) : 0;
  if (socFresh) snprintf(socOverlay, sizeof(socOverlay), "%d%%", socWhole);
  else snprintf(socOverlay, sizeof(socOverlay), "---");
  drawFuelTripBar(tftSocBarCache, socFresh, (uint16_t)socWhole, 100U,
                  12,58,205,34,TFT_GREEN,socOverlay);

  const bool gen2FuelGauge = vehicleProfile==PROFILE_PRIUS_GEN2;
  const bool camryFuel = vehicleProfile==PROFILE_CAMRY_HYBRID_GEN1;
  const bool phvFuel = vehicleProfile==PROFILE_PRIUS_PHV_GEN1;
  uint8_t shownFuelRaw=live.fuelRaw;
  const char *fuelState="LIVE";
  const bool gen2FuelReady = gen2FuelGauge && gen2FuelForDisplay(nowMs,shownFuelRaw,fuelState);
  const bool showFuel = fuelFresh || gen2FuelReady;
  char fuelOverlay[24];
  uint16_t fillValue=0, fillMax=40U, fuelColor=TFT_DARKGREY;
  if (!showFuel) snprintf(fuelOverlay,sizeof(fuelOverlay),"---");
  else if (camryFuel) {
    const float liters=live.fuelRaw*0.5f;
    snprintf(fuelOverlay,sizeof(fuelOverlay),"%.2f gal E",liters/3.785411784f);
    fillValue=(uint16_t)(liters*10.0f+0.5f); fillMax=650U;
    fuelColor=TFT_YELLOW; // 65L nominal tank; sender-to-usable volume is NOT confirmed.
  } else if (phvFuel) {
    snprintf(fuelOverlay,sizeof(fuelOverlay),"RAW %u E",(unsigned)shownFuelRaw);
    fillValue=shownFuelRaw; fillMax=255U; fuelColor=TFT_CYAN; // raw-byte scale, not real bars.
  } else if (gen2FuelGauge) {
    snprintf(fuelOverlay,sizeof(fuelOverlay),"%u %s",(unsigned)shownFuelRaw,fuelState);
    fillValue=shownFuelRaw; fillMax=40U;
    const FuelBarBand band=fuelBarBand(shownFuelRaw);
    fuelColor=band==FUEL_BAR_RED?TFT_RED:(band==FUEL_BAR_YELLOW?TFT_YELLOW:TFT_GREEN);
    if (strcmp(fuelState,"LIVE")!=0) fuelColor=TFT_YELLOW;
  } else snprintf(fuelOverlay,sizeof(fuelOverlay),"RAW %u E",(unsigned)shownFuelRaw);
  // Dirty render cache normally hashes the value only; also invalidate for LIVE->LAST->EST.
  static char lastFuelOverlay[24]="";
  if (strcmp(lastFuelOverlay,fuelOverlay)!=0) {
    strncpy(lastFuelOverlay,fuelOverlay,sizeof(lastFuelOverlay)-1);
    lastFuelOverlay[sizeof(lastFuelOverlay)-1]='\0';
    tftFuelBarCache=-32768;
  }
  drawFuelTripBar(tftFuelBarCache,showFuel,showFuel?fillValue:0U,fillMax,
                  12,125,205,34,fuelColor,fuelOverlay);

  String odoText=shownOdo>=0.0?String(shownOdo,1)+" mi"+
    (odoFresh?"":(gen2SavedOdo?(nhw20Variant==NHW20_VARIANT_0405?" DER":" LAST"):" E")):String("---");
  String tripText=String(shownTrip,2)+" mi";
  String sessText=String(sessionMiles,2)+" mi";
  drawDirtyTextBox(tftTextPageCache[2],odoText,245,55,225,28,250,68,2,TFT_YELLOW,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[3],tripText,245,105,225,28,250,118,2,TFT_CYAN,TL_DATUM);
  drawDirtyTextBox(tftTextPageCache[4],sessText,245,155,225,28,250,168,2,TFT_WHITE,TL_DATUM);
  const char *note = nullptr;
  if (camryFuel) note="AHV40 Fuel Input 2129 gal E; bar proportional, experimental";
  else if (phvFuel) note="PHV 612 B5 raw 0-255 E; not calibrated bars";
  else if (loggingActive) note=odoManualEntryAllowed() ? "Gen2 LIVE/LAST/EST; STOP LOG to set ODO/TRIP" : "Gen2 LIVE/LAST/EST; CAN ODO backup";
  else note=odoManualEntryAllowed() ? "Gen2 LIVE/LAST/EST; tap ODO or TRIP" : "Gen2 LIVE/LAST/EST; backup NVS ODO";
  drawDirtyTextBox(tftTextPageCache[5],String(note),8,205,462,16,10,214,1,TFT_WHITE,TL_DATUM);
}


static uint8_t popcount32(uint32_t value) {
  uint8_t count = 0;
  while (value) { count += (uint8_t)(value & 1U); value >>= 1; }
  return count;
}

static void drawOperatorCheckbox(int16_t x, int16_t y, bool checked, bool enabled) {
  const uint16_t border = enabled ? TFT_WHITE : TFT_DARKGREY;
  tft.fillRect(x, y, 18, 18, TFT_BLACK);
  tft.drawRect(x, y, 18, 18, border);
  if (checked) {
    tft.fillRect(x + 4, y + 4, 10, 10, enabled ? TFT_GREEN : TFT_DARKGREY);
  }
}

static void drawOperatorButton(int16_t x, int16_t y, int16_t w, int16_t h,
                               const char *label, uint16_t color, bool enabled=true) {
  const uint16_t fill = enabled ? color : TFT_DARKGREY;
  tft.fillRoundRect(x, y, w, h, 4, fill);
  tft.drawRoundRect(x, y, w, h, 4, TFT_WHITE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE, fill);
  tft.drawString(label, x + w / 2, y + h / 2, 1);
  tft.setTextDatum(TL_DATUM);
}

static void formatDtcResultText(const DtcResult &result, char *out, size_t outSize) {
  if (!out || outSize == 0) return;
  if (result.flags & DTC_RESULT_RAW) {
    snprintf(out, outSize, "RAW %08lX", (unsigned long)result.normalizedCode);
    return;
  }
  const uint16_t code = (uint16_t)(result.normalizedCode & 0xFFFFU);
  static const char systemLetters[4] = {'P','C','B','U'};
  const char letter = systemLetters[(code >> 14) & 0x03U];
  const uint8_t firstDigit = (uint8_t)((code >> 12) & 0x03U);
  snprintf(out, outSize, "%c%u%03X", letter, firstDigit, code & 0x0FFFU);
}

void restoreNormalDisplayAfterModal() {
  operatorUiModal = OP_MODAL_NONE;
  operatorModalPage = 0;
  // Operator modals currently stay in y=2..242, but always clearing that entire
  // content plane makes future modal growth safe and avoids keypad-style residue.
  tft.fillRect(2, 2, 476, 241, TFT_BLACK);
  invalidateTftDirtyCaches();
  tftLastRenderedPage = 0xFF;
  tftForceFullRedraw = true;
}

static void openOperatorModal(OperatorUiModal modal) {
  operatorUiModal = modal;
  operatorModalPage = 0;
  tft.fillRect(2, 2, 476, 241, TFT_BLACK);
  invalidateTftDirtyCaches();
  tftForceFullRedraw = true;
}

static void drawDtcInfPage(uint32_t nowMs) {
  (void)nowMs;
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  const uint32_t allowed = diagnosticSelectableReadMask(profile);
  dtcOperatorSelectedMask &= allowed;
  static uint64_t lastSignature = 0xFFFFFFFFFFFFFFFFULL;
  uint64_t signature = 1469598103934665603ULL;
  auto mixSignature = [&signature](uint32_t value) { signature ^= (uint64_t)value; signature *= 1099511628211ULL; };
  mixSignature((uint32_t)vehicleProfile);
  mixSignature(allowed);
  mixSignature(dtcOperatorSelectedMask);
  mixSignature(dtcScan.respondingMask);
  mixSignature((uint32_t)dtcScan.resultCount | ((uint32_t)dtcScan.truncated << 8) |
               ((uint32_t)dtcScan.active << 9) | ((uint32_t)dtcScan.pendingEcuIndex << 16));
  mixSignature((uint32_t)dtcClear.active | ((uint32_t)dtcClear.confirmationPending << 1) |
               ((uint32_t)diagnosticIdentityVerified << 2) | ((uint32_t)externalTesterOwnsSession << 3));
  if (!tftForceFullRedraw && signature == lastSignature) return;
  lastSignature = signature;
  if (tftForceFullRedraw) {
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("DTC / INF", 10, 8, 2);
  }
  char line[72];
  snprintf(line, sizeof(line), "PROFILE: %s%s", profile ? profile->platformLabel : "UNRESOLVED",
           operatorControlIdentityReady() ? " [PROFILE OK]" : " [READ ONLY]");
  tft.fillRect(10, 27, 458, 15, TFT_BLACK);
  tft.setTextColor(operatorControlIdentityReady() ? TFT_GREEN : TFT_YELLOW, TFT_BLACK);
  tft.drawString(line, 10, 28, 1);

  const bool allSelected = allowed != 0 && (dtcOperatorSelectedMask & allowed) == allowed;
  drawOperatorCheckbox(12, 48, allSelected, allowed != 0);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString("SELECT ALL", 38, 52, 1);
  drawOperatorButton(252, 45, 210, 28, "MORE ECUs", TFT_DARKCYAN, profile != nullptr);
  drawOperatorButton(252, 79, 210, 34, dtcScan.active ? "READING..." : "READ CODES",
                     TFT_BLUE, !dtcScan.active && (dtcOperatorSelectedMask & allowed));

  const int16_t rowY[4] = {78, 106, 134, 162};
  for (uint8_t i=0; i<4; ++i) {
    const bool exists = profile && i < profile->ecuCount;
    const bool readable = exists && dtcReadCapabilityEnabled(profile->ecus[i].read.capability);
    const bool checked = readable && ((dtcOperatorSelectedMask & (1UL << i)) != 0);
    drawOperatorCheckbox(12, rowY[i], checked, readable);
    tft.fillRect(38, rowY[i], 200, 18, TFT_BLACK);
    tft.setTextColor(readable ? TFT_WHITE : TFT_DARKGREY, TFT_BLACK);
    tft.drawString(exists ? profile->ecus[i].label : "N/A", 38, rowY[i] + 3, 1);
  }

  const uint8_t selectedCount = popcount32(dtcOperatorSelectedMask & allowed);
  const uint8_t responseCount = popcount32(dtcScan.respondingMask & allowed);
  tft.fillRect(250, 121, 216, 48, TFT_BLACK);
  snprintf(line, sizeof(line), "Selected: %u  Responses: %u", selectedCount, responseCount);
  tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString(line, 252, 124, 1);
  snprintf(line, sizeof(line), "Codes: %u%s", dtcScan.resultCount, dtcScan.truncated ? " TRUNC" : "");
  tft.setTextColor(dtcScan.truncated ? TFT_ORANGE : TFT_CYAN, TFT_BLACK); tft.drawString(line, 252, 143, 1);
  if (dtcScan.active) snprintf(line, sizeof(line), "Scan active ECU %u", (unsigned)dtcScan.pendingEcuIndex);
  else snprintf(line, sizeof(line), "Scan idle");
  tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK); tft.drawString(line, 252, 160, 1);

  drawOperatorButton(252, 184, 100, 32, "VIEW RESULTS", TFT_DARKCYAN, dtcScan.resultCount != 0 || dtcScan.truncated);
  const bool controlIdentityOk = operatorControlIdentityReady();
  const uint32_t clearable = dtcClearEligibleMask(profile, dtcOperatorSelectedMask, controlIdentityOk, externalTesterOwnsSession);
  drawOperatorButton(362, 184, 100, 32, "CLEAR...", TFT_RED, clearable != 0 && !dtcScan.active && !dtcClear.active);
  tft.fillRect(10, 222, 455, 16, TFT_BLACK);
  tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  tft.drawString("READ is immediate; CLEAR requires confirmation", 10, 224, 1);
  tft.setTextDatum(TL_DATUM);
}

static void drawMoreEcusModal() {
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  const uint32_t allowed = diagnosticSelectableReadMask(profile);
  constexpr uint8_t rowsPerPage = 5;
  const uint8_t first = (uint8_t)(4U + operatorModalPage * rowsPerPage);
  tft.fillRect(2, 2, 476, 241, TFT_BLACK);
  tft.setTextDatum(TL_DATUM); tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("MORE ECUs", 10, 8, 2);
  char line[56]; snprintf(line, sizeof(line), "%s  page %u", profile ? profile->platformLabel : "UNRESOLVED", (unsigned)(operatorModalPage + 1));
  tft.drawString(line, 10, 28, 1);
  for (uint8_t row=0; row<rowsPerPage; ++row) {
    const uint8_t i = (uint8_t)(first + row);
    const int16_t y = (int16_t)(52 + row * 29);
    const bool exists = profile && i < profile->ecuCount;
    const bool readable = exists && dtcReadCapabilityEnabled(profile->ecus[i].read.capability);
    const bool checked = readable && ((dtcOperatorSelectedMask & (1UL << i)) != 0);
    drawOperatorCheckbox(12, y, checked, readable);
    tft.setTextColor(readable ? TFT_WHITE : TFT_DARKGREY, TFT_BLACK);
    tft.drawString(exists ? profile->ecus[i].label : "--", 38, y + 3, 1);
    if (exists && !readable) tft.drawString("LOCKED", 330, y + 3, 1);
  }
  const bool havePrev = operatorModalPage > 0;
  const bool haveNext = profile && (uint8_t)(first + rowsPerPage) < profile->ecuCount;
  drawOperatorButton(10, 207, 100, 30, "BACK", TFT_DARKGREY);
  drawOperatorButton(188, 207, 80, 30, "PREV", TFT_DARKCYAN, havePrev);
  drawOperatorButton(278, 207, 80, 30, "NEXT", TFT_DARKCYAN, haveNext);
  snprintf(line, sizeof(line), "Selected %u / readable %u", popcount32(dtcOperatorSelectedMask & allowed), popcount32(allowed));
  tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK); tft.drawString(line, 365, 215, 1);
}

static void drawDtcResultsModal() {
  constexpr uint8_t rowsPerPage = 4;
  const uint8_t first = (uint8_t)(operatorModalPage * rowsPerPage);
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  tft.fillRect(2, 2, 476, 241, TFT_BLACK);
  tft.setTextDatum(TL_DATUM); tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("DTC / INF RESULTS", 10, 8, 2);
  char line[96];
  snprintf(line, sizeof(line), "Codes %u  ECU replies %u%s", dtcScan.resultCount,
           popcount32(dtcScan.respondingMask), dtcScan.truncated ? "  RESULTS TRUNCATED" : "");
  tft.setTextColor(dtcScan.truncated ? TFT_ORANGE : TFT_LIGHTGREY, TFT_BLACK); tft.drawString(line, 10, 29, 1);
  for (uint8_t row=0; row<rowsPerPage; ++row) {
    const uint8_t ri = (uint8_t)(first + row);
    const int16_t y = (int16_t)(51 + row * 37);
    tft.fillRect(10, y, 455, 34, TFT_BLACK);
    if (ri >= dtcScan.resultCount) continue;
    const DtcResult &r = dtcScan.results[ri];
    const char *ecu = (profile && r.ecuIndex < profile->ecuCount) ? profile->ecus[r.ecuIndex].label : "ECU";
    char code[24]; formatDtcResultText(r, code, sizeof(code));
    snprintf(line, sizeof(line), "%s  %s", ecu, code);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(line, 12, y + 2, 1);
    if (r.flags & DTC_RESULT_HAS_INF) snprintf(line, sizeof(line), "INF %u", (unsigned)r.inf);
    else if (r.flags & DTC_RESULT_PERMANENT) snprintf(line, sizeof(line), "PERMANENT - NOT ERASED BY CLEAR");
    else if (r.flags & DTC_RESULT_PENDING) snprintf(line, sizeof(line), "PENDING - NO INF RETURNED");
    else snprintf(line, sizeof(line), "NO INF RETURNED");
    tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK); tft.drawString(line, 28, y + 18, 1);
  }
  const bool havePrev = operatorModalPage > 0;
  const bool haveNext = (uint16_t)(first + rowsPerPage) < dtcScan.resultCount;
  drawOperatorButton(10, 207, 100, 30, "BACK", TFT_DARKGREY);
  drawOperatorButton(188, 207, 80, 30, "PREV", TFT_DARKCYAN, havePrev);
  drawOperatorButton(278, 207, 80, 30, "NEXT", TFT_DARKCYAN, haveNext);
}

static void drawClearConfirmModal() {
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  tft.fillRect(2, 2, 476, 241, TFT_BLACK);
  tft.setTextDatum(TL_DATUM); tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("CLEAR DTCs", 10, 8, 2);
  char line[80];
  if (!dtcClear.confirmationPending && !dtcClear.active) {
    tft.setTextColor(TFT_ORANGE, TFT_BLACK);
    tft.drawString("CONTROL LOCKED / NO VERIFIED CLEAR TARGET", 10, 52, 1);
    tft.drawString("Only evidence-backed ECU clear commands can be armed.", 10, 73, 1);
    drawOperatorButton(10, 207, 100, 30, "BACK", TFT_DARKGREY);
    return;
  }
  snprintf(line, sizeof(line), "PROFILE: %s  ECUs: %u", profile ? profile->platformLabel : "UNRESOLVED",
           popcount32(dtcClear.eligibleMask));
  tft.setTextColor(TFT_YELLOW, TFT_BLACK); tft.drawString(line, 10, 42, 1);
  tft.drawString("This will clear stored diagnostic information", 10, 64, 1);
  tft.drawString("ONLY from the verified selected ECU(s).", 10, 82, 1);
  uint8_t row=0;
  if (profile) for (uint8_t i=0;i<profile->ecuCount && row<4;i++) {
    if ((dtcClear.eligibleMask & (1UL<<i)) == 0) continue;
    snprintf(line, sizeof(line), "[x] %s", profile->ecus[i].label);
    tft.setTextColor(TFT_WHITE, TFT_BLACK); tft.drawString(line, 18, 108 + row*20, 1); ++row;
  }
  drawOperatorButton(10, 207, 120, 30, "CANCEL", TFT_DARKGREY);
  drawOperatorButton(292, 207, 170, 30, "CONFIRM CLEAR", TFT_RED);
}

static void drawOperatorModal() {
  static uint64_t lastSignature = 0xFFFFFFFFFFFFFFFFULL;
  uint64_t signature = 1469598103934665603ULL;
  auto mixSignature = [&signature](uint32_t value) { signature ^= (uint64_t)value; signature *= 1099511628211ULL; };
  mixSignature((uint32_t)operatorUiModal);
  mixSignature((uint32_t)operatorModalPage);
  mixSignature((uint32_t)vehicleProfile);
  mixSignature(dtcOperatorSelectedMask);
  mixSignature(dtcScan.respondingMask);
  mixSignature((uint32_t)dtcScan.resultCount | ((uint32_t)dtcScan.truncated << 8));
  mixSignature(dtcClear.eligibleMask);
  mixSignature((uint32_t)dtcClear.confirmationPending | ((uint32_t)dtcClear.active << 1) |
               ((uint32_t)diagnosticIdentityVerified << 2) | ((uint32_t)externalTesterOwnsSession << 3));
  if (!tftForceFullRedraw && signature == lastSignature) return;
  lastSignature = signature;
  if (operatorUiModal == OP_MODAL_MORE_ECUS) drawMoreEcusModal();
  else if (operatorUiModal == OP_MODAL_DTC_RESULTS) drawDtcResultsModal();
  else if (operatorUiModal == OP_MODAL_CLEAR_CONFIRM) drawClearConfirmModal();
}

bool handleDtcUiTouch(uint16_t x, uint16_t y) {
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  const uint32_t allowed = diagnosticSelectableReadMask(profile);
  if (operatorUiModal != OP_MODAL_NONE) {
    if (operatorUiModal != OP_MODAL_CLEAR_CONFIRM && y >= 207 && y < 239 && x >= 10 && x < 110) {
      restoreNormalDisplayAfterModal(); return true;
    }
    if (operatorUiModal == OP_MODAL_MORE_ECUS) {
      constexpr uint8_t rowsPerPage = 5;
      const uint8_t first = (uint8_t)(4U + operatorModalPage * rowsPerPage);
      for (uint8_t row=0; row<rowsPerPage; ++row) {
        const uint8_t i = (uint8_t)(first + row); const int16_t ry = (int16_t)(52 + row * 29);
        if (y < ry || y >= ry + 20 || x < 8 || x >= 235) continue;
        if (profile && i < profile->ecuCount && dtcReadCapabilityEnabled(profile->ecus[i].read.capability))
          dtcOperatorSelectedMask ^= (1UL << i);
        return true;
      }
      if (y >= 207 && y < 239 && x >= 188 && x < 268 && operatorModalPage > 0) { --operatorModalPage; return true; }
      if (y >= 207 && y < 239 && x >= 278 && x < 358 && profile && (uint8_t)(first + rowsPerPage) < profile->ecuCount) { ++operatorModalPage; return true; }
      return true;
    }
    if (operatorUiModal == OP_MODAL_DTC_RESULTS) {
      if (y >= 207 && y < 239 && x >= 188 && x < 268 && operatorModalPage > 0) { --operatorModalPage; return true; }
      if (y >= 207 && y < 239 && x >= 278 && x < 358 && (uint16_t)((operatorModalPage + 1U) * 4U) < dtcScan.resultCount) { ++operatorModalPage; return true; }
      return true;
    }
    if (operatorUiModal == OP_MODAL_CLEAR_CONFIRM) {
      if (y >= 207 && y < 239 && x >= 10 && x < 130) { cancelOperatorDtcClear(); restoreNormalDisplayAfterModal(); return true; }
      if (y >= 207 && y < 239 && x >= 292 && x < 462 && dtcClear.confirmationPending) {
        if (confirmOperatorDtcClear()) restoreNormalDisplayAfterModal();
        return true;
      }
      return true;
    }
    return true;
  }
  if (displayPage != 12) return false;
  if (y >= 45 && y < 72 && x < 240) {
    if (allowed) dtcOperatorSelectedMask = ((dtcOperatorSelectedMask & allowed) == allowed) ? 0U : allowed;
    return true;
  }
  const int16_t rowY[4] = {78,106,134,162};
  for (uint8_t i=0;i<4;i++) {
    if (y >= rowY[i] && y < rowY[i] + 20 && x < 235) {
      if (profile && i < profile->ecuCount && dtcReadCapabilityEnabled(profile->ecus[i].read.capability))
        dtcOperatorSelectedMask ^= (1UL << i);
      return true;
    }
  }
  if (x >= 252 && x < 462 && y >= 45 && y < 73 && profile) { openOperatorModal(OP_MODAL_MORE_ECUS); return true; }
  if (x >= 252 && x < 462 && y >= 79 && y < 113) { if (!dtcScan.active) startOperatorDtcRead(dtcOperatorSelectedMask); return true; }
  if (x >= 252 && x < 352 && y >= 184 && y < 216) { if (dtcScan.resultCount || dtcScan.truncated) openOperatorModal(OP_MODAL_DTC_RESULTS); return true; }
  if (x >= 362 && x < 462 && y >= 184 && y < 216) {
    if (dtcOperatorSelectedMask & allowed) {
      beginOperatorDtcClearConfirmation(dtcOperatorSelectedMask);
      openOperatorModal(OP_MODAL_CLEAR_CONFIRM);
    }
    return true;
  }
  return false; // Unmatched touches, especially the shared bottom bar, continue to the wrapper.
}



static const char *fanProfileStatusLabel(const VehicleDiagnosticProfile *profile) {
  if (!profile || profile->fan.overrideRequest.capability != VERIFIED ||
      (profile->fan.releaseRequest.capability != VERIFIED && !fanOverrideMustUseMax(profile))) return "CONTROL LOCKED";
  if (!operatorControlIdentityReady()) return "READ ONLY";
  return "VERIFIED";
}

static uint16_t fanStateColor(FanUiState state) {
  switch (state) {
    case FAN_UI_OVERRIDE: return TFT_GREEN;
    case FAN_UI_ARMED: return TFT_YELLOW;
    case FAN_UI_TEMP_STALE: return TFT_YELLOW;
    case FAN_UI_CONTROL_LOCKED: return TFT_RED;
    case FAN_UI_EXTERNAL_TESTER: return TFT_CYAN;
    case FAN_UI_AUTO:
    default: return TFT_WHITE;
  }
}

static void drawFanOverridePage(uint32_t nowMs) {
  (void)nowMs;
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  const bool commandVerified = profile &&
      profile->fan.overrideRequest.capability == VERIFIED &&
      (profile->fan.releaseRequest.capability == VERIFIED || fanOverrideMustUseMax(profile));
  int16_t hottestF = 0;
  const bool tempFresh = fanTemperatureSnapshot(&hottestF);
  static uint64_t lastSignature = 0xFFFFFFFFFFFFFFFFULL;
  uint64_t signature = 1469598103934665603ULL;
  auto mixSignature = [&signature](uint32_t value) { signature ^= (uint64_t)value; signature *= 1099511628211ULL; };
  mixSignature((uint32_t)vehicleProfile);
  mixSignature((uint32_t)diagnosticIdentityVerified | ((uint32_t)externalTesterOwnsSession << 1) |
               ((uint32_t)commandVerified << 2) | ((uint32_t)tempFresh << 3));
  mixSignature((uint32_t)(int32_t)hottestF);
  mixSignature((uint32_t)fanOverride.enabled | ((uint32_t)fanOverride.overrideActive << 1) |
               ((uint32_t)fanOverride.releasePending << 2) | ((uint32_t)fanOverride.state << 8));
  mixSignature((uint32_t)fanOverride.triggerF | ((uint32_t)fanOverride.speed << 8));
  if (live.batteryFanMonitorValid && (uint32_t)(nowMs - live.batteryFanMonitorMs) <= DIAGNOSTIC_DISPLAY_FRESH_MS) {
    mixSignature((uint32_t)(live.batteryFanMonitorV1 * 10.0f));
    mixSignature((uint32_t)(live.batteryFanMonitorV2 * 10.0f));
  }
  if (!tftForceFullRedraw && signature == lastSignature) return;
  lastSignature = signature;

  if (tftForceFullRedraw) {
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.drawString("FAN OVERRIDE", 10, 8, 2);
  }

  char line[80];
  snprintf(line, sizeof(line), "PROFILE: %s [%s]", profile ? profile->platformLabel : "UNRESOLVED",
           fanProfileStatusLabel(profile));
  tft.fillRect(10, 27, 458, 15, TFT_BLACK);
  tft.setTextColor(commandVerified ? TFT_GREEN : TFT_YELLOW, TFT_BLACK);
  tft.drawString(line, 10, 28, 1);

  drawOperatorCheckbox(12, 47, fanOverride.enabled, commandVerified && !externalTesterOwnsSession);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("ENABLE FAN OVERRIDE", 38, 51, 1);
  snprintf(line, sizeof(line), "HOTTEST: %s", tempFresh ? "" : "---F");
  if (tempFresh) snprintf(line, sizeof(line), "HOTTEST: %dF", (int)hottestF);
  tft.fillRect(285, 47, 180, 18, TFT_BLACK);
  tft.setTextColor(tempFresh ? TFT_CYAN : TFT_DARKGREY, TFT_BLACK);
  tft.drawString(line, 292, 52, 1);

  snprintf(line, sizeof(line), "TRIGGER %uF", (unsigned)fanOverride.triggerF);
  tft.fillRect(10, 73, 160, 18, TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString(line, 10, 76, 2);

  drawOperatorButton(12, 99, 38, 31, "-", TFT_DARKCYAN, true);
  drawOperatorButton(430, 99, 38, 31, "+", TFT_DARKCYAN, true);
  tft.fillRect(FAN_SLIDER_X_MIN - 10, 98, (FAN_SLIDER_X_MAX - FAN_SLIDER_X_MIN) + 20, 42, TFT_BLACK);
  const int16_t sliderY = 112;
  tft.drawLine(FAN_SLIDER_X_MIN, sliderY, FAN_SLIDER_X_MAX, sliderY, TFT_WHITE);
  for (uint8_t tick = 0; tick <= 4; ++tick) {
    const int16_t tx = FAN_SLIDER_X_MIN + (int16_t)((FAN_SLIDER_X_MAX - FAN_SLIDER_X_MIN) * tick / 4);
    tft.drawLine(tx, sliderY - 5, tx, sliderY + 5, TFT_DARKGREY);
  }
  const int16_t knobX = FAN_SLIDER_X_MIN + (int16_t)((uint32_t)(fanOverride.triggerF - FAN_TRIGGER_MIN_F) *
                        (uint32_t)(FAN_SLIDER_X_MAX - FAN_SLIDER_X_MIN) /
                        (uint32_t)(FAN_TRIGGER_MAX_F - FAN_TRIGGER_MIN_F));
  tft.fillCircle(knobX, sliderY, 8, TFT_YELLOW);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("55F", FAN_SLIDER_X_MIN - 2, 126, 1);
  tft.setTextDatum(TR_DATUM); tft.drawString("95F", FAN_SLIDER_X_MAX + 2, 126, 1); tft.setTextDatum(TL_DATUM);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("SPEED", 10, 145, 1);
  drawOperatorCheckbox(70, 141, fanOverride.speed == FAN_SPEED_MAX, commandVerified);
  tft.drawString("MAX", 94, 145, 1);
  drawOperatorCheckbox(160, 141, fanOverride.speed == FAN_SPEED_HIGH && !fanOverrideMustUseMax(profile),
                       commandVerified && !fanOverrideMustUseMax(profile));
  tft.drawString(fanOverrideMustUseMax(profile) ? "N/A" : "HIGH", 184, 145, 1);
  if (profile && commandVerified) {
    if (fanOverrideMustUseMax(profile))
      snprintf(line, sizeof(line), "MAX=%u ONLY", (unsigned)profile->fan.maxLevel);
    else snprintf(line, sizeof(line), "MAX=%u HIGH=%u", (unsigned)profile->fan.maxLevel, (unsigned)profile->fan.highLevel);
    tft.drawString(line, 280, 145, 1);
  } else {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.drawString("TX LOCKED", 280, 145, 1);
  }

  tft.fillRect(10, 165, 458, 14, TFT_BLACK);
  const bool vmfFresh = live.batteryFanMonitorValid && (uint32_t)(nowMs - live.batteryFanMonitorMs) <= DIAGNOSTIC_DISPLAY_FRESH_MS;
  if (vmfFresh) {
    if (live.batteryFanMonitorCount >= 2) snprintf(line, sizeof(line), "VMF: %.1f / %.1f V%s", live.batteryFanMonitorV1, live.batteryFanMonitorV2, live.batteryFanMonitorProbable ? " P" : "");
    else snprintf(line, sizeof(line), "VMF: %.1f V%s   FAN %s: %u", live.batteryFanMonitorV1, live.batteryFanMonitorProbable ? " P" : "",
                  vehicleProfile == PROFILE_CAMRY_HYBRID_GEN1 ? "MODE" : "LEVEL", (unsigned)live.fanLevel);
  } else snprintf(line, sizeof(line), "VMF: ---");
  tft.setTextColor(vmfFresh ? TFT_CYAN : TFT_DARKGREY, TFT_BLACK);
  tft.drawString(line, 10, 166, 1);

  tft.fillRect(10, 181, 458, 18, TFT_BLACK);
  tft.setTextColor(fanStateColor(fanOverride.state), TFT_BLACK);
  snprintf(line, sizeof(line), "STATE: %s", fanUiStateLabel(fanOverride.state));
  tft.drawString(line, 10, 184, 2);

  tft.fillRect(10, 204, 458, 14, TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  snprintf(line, sizeof(line), "ON >= %uF     RELEASE <= %uF", (unsigned)fanOverride.triggerF,
           (unsigned)((fanOverride.triggerF > FAN_HYSTERESIS_F) ? fanOverride.triggerF - FAN_HYSTERESIS_F : 0));
  tft.drawString(line, 10, 206, 1);
  tft.fillRect(10, 221, 458, 12, TFT_BLACK);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.drawString(fanOverrideMustUseMax(profile) ?
                 "OFF: STOP MAX TX; WAIT ECU TIMEOUT (NO AUTO CMD)" :
                 "BOOT: OFF / 69F / MAX   RAM ONLY", 10, 222, 1);
}

bool handleFanUiTouch(uint16_t x, uint16_t y) {
  if (displayPage != 13 || operatorUiModal != OP_MODAL_NONE) return false;
  const VehicleDiagnosticProfile *profile = diagnosticProfileFor(vehicleProfile);
  const bool commandVerified = profile &&
      profile->fan.overrideRequest.capability == VERIFIED &&
      (profile->fan.releaseRequest.capability == VERIFIED || fanOverrideMustUseMax(profile));

  if (y >= 42 && y < 72 && x < 270) {
    setOperatorFanOverrideEnabled(!fanOverride.enabled);
    return true;
  }
  if (y >= 94 && y < 137) {
    if (x >= 8 && x < 55) {
      if (fanOverride.triggerF > FAN_TRIGGER_MIN_F) --fanOverride.triggerF;
      writeEvent("INFO", "OP_FAN_SETTING", String("triggerF=") + String(fanOverride.triggerF));
      return true;
    }
    if (x >= FAN_SLIDER_X_MIN && x <= FAN_SLIDER_X_MAX) {
      fanOverride.triggerF = fanSliderTempFromX((int16_t)x);
      writeEvent("INFO", "OP_FAN_SETTING", String("triggerF=") + String(fanOverride.triggerF));
      return true;
    }
    if (x >= 425 && x < 474) {
      if (fanOverride.triggerF < FAN_TRIGGER_MAX_F) ++fanOverride.triggerF;
      writeEvent("INFO", "OP_FAN_SETTING", String("triggerF=") + String(fanOverride.triggerF));
      return true;
    }
  }
  if (y >= 137 && y < 168 && commandVerified) {
    if (x >= 62 && x < 150) {
      fanOverride.speed = FAN_SPEED_MAX;
      writeEvent("INFO", "OP_FAN_SETTING", "speed=MAX");
      return true;
    }
    if (x >= 152 && x < 250 && !fanOverrideMustUseMax(profile)) {
      fanOverride.speed = FAN_SPEED_HIGH;
      writeEvent("INFO", "OP_FAN_SETTING", "speed=HIGH");
      return true;
    }
  }
  return false;
}

void updateDisplay() {
  if (distanceEntryActive) return;
  if (operatorUiModal != OP_MODAL_NONE) {
    drawOperatorModal();
    drawButtons();
    tftForceFullRedraw = false;
    return;
  }
  const uint32_t nowMs = millis();
  const uint32_t qBefore = currentCanQueueDepth();
  if (qBefore > tftQueueDepthBeforeMax) tftQueueDepthBeforeMax = qBefore;
  if (shouldShedTftRender(nowMs)) {
    ++tftRenderSkippedPressure;
    return;
  }

  const bool graphPage = displayPage == 5 || displayPage == 6;
  const bool dirtyCapablePage = displayPage <= 11;
  const bool pageChanged = displayPage != tftLastRenderedPage;
  const bool periodicFull = dirtyCapablePage && tftDirtyRenderEnabled && !pageChanged &&
                            (uint32_t)(nowMs - tftLastFullRedrawMs) >= TFT_FORCED_FULL_REFRESH_MS;
  if (tftDirtyRenderEnabled && graphPage && !pageChanged && !periodicFull) {
    if (displayPage == 5) {
      const bool fresh=signalFresh(live.blockVoltageValid,live.blockVoltageMs,nowMs);
      if (tftLastBlocksFreshInitialized && live.blockVoltageMs == tftLastBlocksSourceMs && fresh == tftLastBlocksFresh) {
        ++tftGraphRenderSkippedUnchanged;
        return;
      }
    } else if (trendHead == tftLastTrendHead && trendCount == tftLastTrendCount) {
      ++tftGraphRenderSkippedUnchanged;
      return;
    }
  }
  const bool fullRedraw = pageChanged || !tftDirtyRenderEnabled || periodicFull;
  tftForceFullRedraw = fullRedraw;
  if (periodicFull) ++tftForcedFullRedraws;

  const uint64_t renderStartUs = nowMicros64();
  if (tftBatchTransactionEnabled) tft.startWrite();
  if (fullRedraw) {
    tft.fillRect(2, 2, 476, 241, TFT_BLACK);
    ++tftFullRedraws;
    tftLastFullRedrawMs = nowMs;
    invalidateTftDirtyCaches();
  }
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  if (displayPage == 0) drawMainPageDirty(nowMs);
  else if (displayPage == 1) drawSpeedPageDirty(nowMs);
  else if (displayPage == 2) drawWheelsPageDirty(nowMs);
  else if (displayPage == 3) drawTempPageDirty(nowMs);
  else if (displayPage == 4) drawHvPageDirty(nowMs);
  else if (displayPage == 5) drawBlocksPage(nowMs);
  else if (displayPage == 6) drawTrendPage(nowMs);
  else if (displayPage == 7) drawPowerPageDirty(nowMs);
  else if (displayPage == 8) drawHealthPageDirty(nowMs);
  else if (displayPage == 9) drawSystemPageDirty(nowMs);
  else if (displayPage == 10) drawDiagExpPageDirty(nowMs);
  else if (displayPage == 11) drawFuelTripSocPageDirty(nowMs);
  else if (displayPage == 12) drawDtcInfPage(nowMs);
  else if (displayPage == 13) drawFanOverridePage(nowMs);
  else drawFuelTripSocPageDirty(nowMs);
  drawButtons();
  if (tftBatchTransactionEnabled) tft.endWrite();

  if (loggingActive && qBefore > PRESSURE_LOW && qBefore < PRESSURE_HIGH) tftLastSoftPressureRenderMs = nowMs;
  if (displayPage == 5) {
    tftLastBlocksSourceMs = live.blockVoltageMs;
    tftLastBlocksFresh = signalFresh(live.blockVoltageValid,live.blockVoltageMs,nowMs);
    tftLastBlocksFreshInitialized = true;
  } else if (displayPage == 6) {
    tftLastTrendHead = trendHead;
    tftLastTrendCount = trendCount;
  }
  tftLastRenderedPage = displayPage;
  tftForceFullRedraw = false;
  const uint64_t elapsedUs = nowMicros64() - renderStartUs;
  ++tftRenderCalls;
  tftRenderTotalUs += elapsedUs;
  if (elapsedUs > tftRenderMaxUs) tftRenderMaxUs = elapsedUs;
  if (displayPage < 12) {
    ++tftPageRenderCalls[displayPage];
    tftPageRenderTotalUs[displayPage] += elapsedUs;
  }
  const uint32_t qAfter = currentCanQueueDepth();
  if (qAfter > tftQueueDepthAfterMax) tftQueueDepthAfterMax = qAfter;
}

void handleTouch() {
  uint32_t nowMs = millis();
  uint16_t x = 0, y = 0;
  digitalWrite(SD_CS_PIN, HIGH);
  bool pressed = tft.getTouch(&x, &y);

  if (pressed) {
    if (!touchWasDown) {
      touchWasDown = true;
      touchDownX = x;
      touchDownY = y;
      Serial.printf("# TOUCH DOWN,%u,%u\n", x, y);
    }
    return;
  }

  if (!touchWasDown) return;
  touchWasDown = false;
  if (nowMs - lastTouchMs < 250) return;
  lastTouchMs = nowMs;

  if (operatorUiModal != OP_MODAL_NONE || displayPage == 12) {
    if (handleDtcUiTouch(touchDownX, touchDownY)) { updateDisplay(); return; }
  }
  if (displayPage == 13) {
    if (handleFanUiTouch(touchDownX, touchDownY)) { updateDisplay(); return; }
  }

  bool logButton = touchDownX >= CYD_LOG_BTN_X &&
                   touchDownX < CYD_LOG_BTN_X + CYD_LOG_BTN_W &&
                   touchDownY >= CYD_LOG_BTN_Y &&
                   touchDownY < CYD_LOG_BTN_Y + CYD_LOG_BTN_H;
  bool diagButton = touchDownX >= CYD_DIAG_BTN_X &&
                    touchDownX < CYD_DIAG_BTN_X + CYD_DIAG_BTN_W &&
                    touchDownY >= CYD_DIAG_BTN_Y &&
                    touchDownY < CYD_DIAG_BTN_Y + CYD_DIAG_BTN_H;
  bool pageButton = touchDownX >= CYD_PAGE_BTN_X &&
                    touchDownX < CYD_PAGE_BTN_X + CYD_PAGE_BTN_W &&
                    touchDownY >= CYD_PAGE_BTN_Y &&
                    touchDownY < CYD_PAGE_BTN_Y + CYD_PAGE_BTN_H;

  if (pageButton) {
    displayPage = (displayPage + 1) % 14;
    updateDisplay();
  } else if (logButton) {
    if (loggingActive) requestLoggingStop(nullptr, true);
    else startLogging();
  } else if (diagButton) {
    if (diagnosticEnabled || diagnosticCanBeEnabledForProfile(vehicleProfile)) {
      setDiagnosticCapture(!diagnosticEnabled, "Touchscreen user action");
    } else if (nowMs - lastDiagRejectMs >= 2000) {
      writeEvent("WARNING", "DIAGNOSTIC_ENABLE_REJECTED",
                 "Profile conflict/unsupported or no read plan; write controls require VERIFIED identity/capability");
      lastDiagRejectMs = nowMs;
    }
  }
  drawButtons();
}
