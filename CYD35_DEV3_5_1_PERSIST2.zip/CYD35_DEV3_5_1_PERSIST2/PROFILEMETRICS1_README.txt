DEV3.4.3 / DIAG4 R7.4.3 PROFILEMETRICS1

- NHW20 strong passive profile (>=80%) may use already VERIFIED Gen2 DTC clear/fan tuples without waiting on a redundant 21C1 identity response. External tester latch and per-command capability gates remain in force.
- NHW20 fuel remains raw 0..40 with existing red/yellow/green display mapping. No percent claim is added.
- NHW20 0405 vs 0609 is separated by the confirmed 0x529 DLC6/DLC7 variant signal. Manual ODO keypad is allowed only for 0405; direct 0x53F ODO is accepted only for 0609. TRIP entry remains available while logging is stopped.
- NHW20 and AHV40 Catalyst B1S2 temperature: 7E0/7E8 21 3E, BE16/10-40 C, CONFIRMED. NHW20 B1S1 is updated to confirmed 21 3C.
- ZVW35 PHV B1S1/B1S2 catalyst temperatures use standard OBD 01 3C/3E as PROBABLE read-only supplements pending a local transport capture; displayed with P.
- FAN page adds NHW20 confirmed VMF monitor voltage, ZVW35 confirmed dual fan-motor voltages from 2181, and AHV40 probable VMF voltage marked P. Active fan TX remains NHW20-only.
- Queue/storage/TFT performance architecture is unchanged.
