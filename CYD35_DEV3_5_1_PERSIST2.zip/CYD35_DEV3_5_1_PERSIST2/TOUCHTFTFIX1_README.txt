TOUCHTFTFIX1

Root causes corrected from DEV3.4.1 / DIAG4 R7.4.1 field test:
1. DTC page handler returned true for every unmatched touch, swallowing the shared PAGE/WIFI/LOG/DIAG bottom controls.
2. DTC/FAN/modal UI was repainting unchanged controls every 250 ms; modal drawing also retained tftForceFullRedraw.
3. Wrapper Wi-Fi button was repainted every display tick on every normal screen.

Corrections:
- unmatched DTC-page touches return to normal wrapper dispatch;
- disabled MORE ECUs is actually non-interactive until a profile exists;
- change-signature redraw guards for DTC page, FAN page and operator modals;
- clear modal full-redraw latch after the first modal redraw;
- state-signature guard for global Wi-Fi button;
- FAN touch changes no longer force a whole-page clear.

No CAN request/response tuples, storage thresholds, queue sizes, SD clock, RAW batch size or pressure thresholds were changed.
