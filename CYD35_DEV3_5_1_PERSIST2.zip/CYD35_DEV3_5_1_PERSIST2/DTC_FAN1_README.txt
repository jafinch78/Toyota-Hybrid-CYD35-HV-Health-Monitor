DEV3.4.2 / DIAG4 R7.4.1 — DTCFAN1 + FUELBAR1 + COMPILEFIX1 + TOUCHTFTFIX1
2026-10-12

PURPOSE
- Adds DTC/INF operator pages and an HV-battery FAN OVERRIDE page to the field-passed DEV3.3.2/R7.3.2 logger baseline.
- Corrects the Prius raw fuel graphic from a 0..255 presentation scale to the observed raw 0..40 range. The displayed number remains RAW, not percent.
- Preserves RAW-META schema R8 and all acquisition/storage pressure settings.

PAGE CYCLE
- 14 ordinary pages total.
- Page 11: FUEL / TRIP / SOC.
- Page 12: DTC / INF.
- Page 13: FAN OVERRIDE.

FUELBAR1
- Raw fill scale: 0..40.
- 0..7 RED; 8..19 YELLOW; 20..40 GREEN.
- Values above 40 are graphically clamped to a full bar while the raw integer is still shown.
- Example: RAW 38 is 95% full and GREEN.
- These colors are an operator aid; they are not claimed as an exact Toyota Combination Meter bar/hysteresis decoder.

DTC / INF
- Fixed-size state: max 32 displayed DTC result entries; no heap-growing result list.
- Primary ECU controls: ENGINE, HYBRID / PM, HV BATTERY, ABS / SKID.
- SELECT ALL selects only ECUs whose read request is enabled for the active profile.
- MORE ECUs exposes profile-defined A/C, SRS/AIRBAG, EPS, COMB METER, BODY, and GATEWAY entries; unsupported entries remain locked.
- READ CODES is non-destructive.
- CLEAR... requires a separate confirmation screen and sends only profile+ECU clear tuples marked VERIFIED.
- After a clear sequence, the selected readable ECUs are re-read.
- Results remain grouped by ECU and show NO INF RETURNED unless the active response decoder directly associates an INF/detail with that DTC. Static catalog data is never used to invent a currently active INF.

CURRENT DTC CAPABILITY MATRIX
NHW20 / Prius Gen 2:
- Engine: Toyota 13 B0 read ENABLED; service 04 clear VERIFIED.
- Hybrid/PM: Toyota 13 B0 read ENABLED; service 04 clear VERIFIED.
- HV Battery: Toyota 13 80 read ENABLED; service 04 clear VERIFIED.
- ABS/Skid and MORE-ECU requests: CONTROL/READ LOCKED until exact request/response evidence is promoted.

ZVW30 / Prius Gen 3:
- Engine: generic OBD mode 03 read ENABLED.
- Hybrid/PM, HV Battery, ABS/Skid, MORE ECUs: LOCKED pending exact request/response definitions.
- DTC clear: LOCKED.

ZVW35 / Prius PHV Gen 1:
- Engine: generic OBD mode 03 read ENABLED.
- Hybrid/PM, HV Battery, ABS/Skid, MORE ECUs: LOCKED pending exact request/response definitions.
- DTC clear: LOCKED in this revision.

ZVW45 / Prius alpha/v-family:
- Engine: generic OBD mode 03 read ENABLED.
- Hybrid/PM, HV Battery, ABS/Skid, MORE ECUs: LOCKED pending exact request/response definitions.
- DTC clear: LOCKED in this revision.

AHV40 / Camry Hybrid Gen 1:
- Engine: Toyota 13 B0 read ENABLED; service 04 clear VERIFIED.
- Hybrid/PM: Toyota 13 B0 read ENABLED; service 04 clear VERIFIED.
- HV Battery, ABS/Skid and MORE ECUs: LOCKED pending exact request/response definitions.

INF LIMITATION IN THIS REVISION
- The UI/result structure supports a DTC-associated INF field.
- The currently enabled legacy service-13 and OBD-mode-03 decoders do not manufacture an INF from unrelated bytes.
- Existing NHW20 22 05 CA evidence is useful DTC/detail/status evidence but is not treated as a direct DTC-to-INF list without a verified pairing format.
- Therefore NO INF RETURNED is an expected result until an exact active-response INF association is decoded for that ECU/profile.

FAN OVERRIDE
- Boot default: checkbox OFF, trigger 69 F, speed MAX. RAM only; no NVS reads/writes.
- Slider range: 55..95 F, 1 F steps, plus +/- controls.
- Hysteresis: command high fan at hottest valid HV-battery temperature >= trigger; return to AUTO at <= trigger-2 F.
- MAX is selected by default; HIGH is the next-highest configured level where verified.
- NHW20: VERIFIED fan command profile; request 7E3 application payload 30 81 06 n, response prefix 70 81; MAX=6, HIGH=5, release/AUTO=0, refresh 500 ms.
- ZVW30/ZVW35: command descriptors are retained for future promotion but remain LOCKED_UNVERIFIED in this build.
- ZVW45/AHV40: fan TX remains locked in this build.
- External-tester ownership aborts operator DTC/fan work and CYD does not compete with a release frame after ownership transfers.
- Profile/control revocation while CYD still owns the bus schedules release when applicable.
- Deliberate diagnostic disable while an active override exists defers LISTEN_ONLY until the release attempt is completed/abandoned.

TRANSPORT / SAFETY
- DTC and FAN operations share the existing single DiagnosticTransaction/ISO-TP owner. No second CAN transmitter was added.
- High-frequency fan/DTC scheduler telemetry uses fixed stack buffers rather than temporary Arduino String construction.
- External-tester session latch applies to operator diagnostic work even when SD logging is stopped.
- Vehicle/profile capability gates are explicit; unverified writes are never borrowed from a related Toyota generation.
- Logging START/STOP remains independent from the fan checkbox.

FIELD VALIDATION ORDER
1. Arduino IDE Verify both variants before flash.
2. USB bench: navigate all 14 pages; exercise DTC/MORE/results/clear-CANCEL and FAN slider/+/-; verify modal redraws.
3. NHW20: validate Engine/Hybrid/Battery read + confirmed clears and FAN OFF->ARMED->OVERRIDE->AUTO while recording RAW/META.
4. AHV40: validate Engine/Hybrid reads/clears. Fan remains locked.
5. ZVW30/ZVW35/ZVW45: validate available read-only paths first; promote additional ECU reads/clear/fan commands only from exact captured request/response evidence.
6. Compare code/INF results with a known scan tool where possible.

COMPILEFIX1
- Renames ToyotaEcuRole EPS -> ECU_EPS to avoid the ESP32 Xtensa EPS macro collision.
- Uses VehicleDiagnosticProfile::platformLabel consistently (removes invalid displayName references).
- Adds the fanUiStateLabel forward declaration before its first use.
- Braces two fan scheduler telemetry if-blocks so fixed stack buffers stay in scope.
