# DEV3.2.1 Storage-Resilience MEMFIX1 Field Test

This package supersedes the initial DEV3.2/R7.2 1536-queue test package.

## Queue disposition

- This variant uses `CAN_QUEUE_LENGTH=1024`.
- `PRESSURE_HIGH=512` and `PRESSURE_LOW=256` are derived from queue capacity.
- The 1536 target was rejected after real-board boot telemetry showed insufficient internal heap after full setup.
- The new pressure-mode, RAW-first catch-up, routine flush/checkpoint deferral, storage telemetry, and external-tester session latch are retained.

## TWAI boot behavior

The logger intentionally boots TWAI in LISTEN_ONLY before diagnostics are enabled. This is inherited from the proven DEV3.1/R7.1 baseline and is not the S0218/S0219 forced-LISTEN_ONLY experiment. When allowed diagnostics are enabled, the existing code can transition to TWAI NORMAL.

## STALL650 disposition

`STORAGE_STALL650_TEST=false` in this production TEST package. Do not enable the 650 ms injection at the restored queue size: 650 ms at about 1,670 frames/s can exceed the available queue envelope. No STALL650 ZIP is released with MEMFIX1.

## First boot checks

1. Arduino IDE Verify with the established ESP32 Arduino 3.3.10 + TFT_eSPI setup.
2. Confirm `# QUEUE MEMORY,target=1024,...,ok=1`.
3. Capture `# HEAP` / `# DIAG4_MEM` at CAN_QUEUES, SD_STAGE, TWAI_READY, and SETUP_COMPLETE.
4. Confirm SD reports `spi_hz=25000000`.
5. Confirm session META reports the MEMFIX1 firmware/build identity.

## Vehicle test checks

- zero SD drops;
- queue high-water and queue-drop behavior during Card-B stalls;
- pressure entry/exit and deferred flush/checkpoint counters;
- exact STREAM_FILE_CLOSE accounting and clean SESSION_CLOSE;
- external-tester latch keeps post-latch diagnostic TX at zero.
