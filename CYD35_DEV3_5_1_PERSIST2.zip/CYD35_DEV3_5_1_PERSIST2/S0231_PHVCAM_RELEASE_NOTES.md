# Candidate PHV/Camry diagnostics update (2026-10-27)

**PRE-HARDWARE-VERIFY:** Arduino ESP32/TFT_eSPI full-sketch compile and vehicle testing
remain required. Historical README files describe inherited, earlier revisions.

## Confirmed features

- DTC/INF read: PHV ZVW35 engine 13B0/1380 and permanent 0A, Hybrid/PM
  13B0/1380; Camry AHV40 enhanced reads for Engine, Hybrid/PM, ABS, EPS,
  Combination Meter, A/C, Main Body target 0x40, Smart Key target 0xB5.
- Camry pending/secondary DTC stores are queried where observed; no unverified
  INF field is invented. Codes without INF show NO INF RETURNED. Permanent
  OBD 0A DTCs display separately as not erased by 04.
- DTC clears: PHV Engine (7E0/7E8 service04); Camry Engine + Hybrid
  (7E0/7E2 service04); Camry Smart Key 0x750 target B5 service14 and
  response-pending NRC78 handling. Profile identity verification, explicit
  operator confirmation and external tester ownership rules remain.
- PHV Hybrid/PM service04 got a positive ACK in S0231 but effect on a
  real nonzero fault is unknown: UI clear stays LOCKED_UNVERIFIED.
- MAX fan: PHV and Camry 7E2 30 81 06 06, only with exact verified
  profile, battery temperatures fresh and the user-enabled threshold.
  HIGH remains unavailable. On release, transmit no guessed zero/AUTO
  command: cease periodic MAX refresh and allow the ECU to time out.
- Camry fuel: 7C0/7C8 PID2129 Fuel Input = B0 / 2 L
  (S0229 0x2B = 21.5 L); PHV passive 0x612 B5 raw (S0228 26,
  S0231 34 while dash showed two bars). Gen2 0-40 red/yellow/green
  gauge remains unchanged; no false PHV/Camry bars/percent calibration.
- Camry 21CF VMF and fan mode are represented as observed feedback.
- PHV 2195 eight internal resistance bytes at 0.001 ohm/count was
  already implemented in the baseline and remains active.
- Catalyst B1S2: existing confirmed NHW20/AHV40 213E and low-rate
  PROBABLE PHV 013E preserved. PHV A/F 2104 and O2 2133 impedance
  research candidates are not promoted to active production display.

## Deliberately locked

- PHV Techstream Utility 7E2/3B23 (Low-Volt READY Prevention Cancel)
  and 7E2/3B21 (Temporary Vehicle Startup): TX prohibited.
- Camry ABS, Combination Meter, EPS, A/C and Body DTC CLEAR routes;
  TPMS / Occupant Detection DTC access on this logged HS-CAN network.
- Fan intermediate speeds, PHV/Camry factory AUTO fan write and inferred
  PHV fuel dashboard bars.

## Runtime unchanged

- DEV 1024 / DIAG 768 frame queue; RAW batch 128;
  pressure thresholds 384 / 192; SD SPI 25 MHz; STALL650 off.
- TVM1/TCB1 logging schema remains R8, without acquisition-path changes.

## User validation

1. In Arduino IDE, use ESP32-32E + correct ST7796/TFT_eSPI board setup;
   run **Verify** on the .ino whose name matches the sketch folder.
2. Record boot min-free-heap, largest-free-block, SD metric and TFT pages.
3. Test Wi-Fi FILES EXIT/RESTART on DEV; DIAG reuses its field-proven path.
4. Before allowing active DTC clear or MAX fan, verify identity, bus
   ownership, UI confirmation and release-on-stop behavior on the vehicle.
5. Upload RAW/META + Android capture for independent behavioral validation.

Compiler/runtime contract probes are necessary but are not full Arduino
builds or hardware validation.
