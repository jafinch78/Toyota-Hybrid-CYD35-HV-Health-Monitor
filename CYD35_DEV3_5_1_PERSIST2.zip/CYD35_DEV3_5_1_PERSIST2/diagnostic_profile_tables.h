#pragma once
#include "diagnostic_control_types.h"

static constexpr DiagnosticRequestDef DIAG_REQ_NONE =
    {0,0,0,{0,0,0,0,0,0,0},0,{0,0,0},DTC_DECODER_NONE,UNSUPPORTED};

static constexpr DiagnosticRequestDef diagReq(uint32_t reqId, uint32_t respId,
                                              uint8_t a, uint8_t b,
                                              uint8_t prefix,
                                              DiagnosticDecoderKind decoder,
                                              DiagnosticCapability capability) {
  return {reqId,respId,2,{a,b,0,0,0,0,0},1,{prefix,0,0},decoder,capability};
}

static constexpr DiagnosticRequestDef diagReq1(uint32_t reqId, uint32_t respId,
                                               uint8_t a, uint8_t prefix,
                                               DiagnosticDecoderKind decoder,
                                               DiagnosticCapability capability) {
  return {reqId,respId,1,{a,0,0,0,0,0,0},1,{prefix,0,0},decoder,capability};
}

static constexpr DiagnosticRequestDef fanReq(uint32_t reqId, uint32_t respId,
                                             uint8_t level, DiagnosticCapability capability) {
  return {reqId,respId,4,{0x30,0x81,0x06,level,0,0,0},2,{0x70,0x81,0},DTC_DECODER_RAW,capability};
}

static constexpr DiagnosticRequestDef diagReqTarget(uint8_t target,
    uint8_t a, uint8_t b, uint8_t prefix, DiagnosticCapability capability) {
  // Observed AHV40 0x750 -> 0x758 with target byte before ISO-TP PCI.
  // Only short single-frame transactions are supported for this address form.
  return {0x750,0x758,2,{a,b,0,0,0,0,0},1,{prefix,0,0},
          DTC_DECODER_TOYOTA_13,capability,target};
}

static constexpr DiagnosticRequestDef diagClearTarget(uint8_t target) {
  return {0x750,0x758,1,{0x14,0,0,0,0,0,0},1,{0x54,0,0},
          DTC_DECODER_RAW,VERIFIED,target};
}

// Enhanced Toyota reads are enabled only where this project has direct/candidate
// request evidence. Generic OBD mode-03 engine reads are non-destructive and
// are kept separate from Toyota INF decoding.
static constexpr VehicleDiagnosticEcuDef NHW20_ECUS[] = {
  {ENGINE,"ENGINE",true,diagReq(0x7E0,0x7E8,0x13,0xB0,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),diagReq1(0x7E0,0x7E8,0x04,0x44,DTC_DECODER_RAW,VERIFIED)},
  {HYBRID_PM,"HYBRID / PM",true,diagReq(0x7E2,0x7EA,0x13,0xB0,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),diagReq1(0x7E2,0x7EA,0x04,0x44,DTC_DECODER_RAW,VERIFIED)},
  {HV_BATTERY,"HV BATTERY",true,diagReq(0x7E3,0x7EB,0x13,0x80,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),diagReq1(0x7E3,0x7EB,0x04,0x44,DTC_DECODER_RAW,VERIFIED)},
  {ABS_SKID,"ABS / SKID",true,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {AC,"A/C",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {SRS,"SRS / AIRBAG",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {ECU_EPS,"EPS",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {COMBINATION_METER,"COMB METER",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {BODY,"BODY",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {GATEWAY,"GATEWAY",false,DIAG_REQ_NONE,DIAG_REQ_NONE}
};

static constexpr VehicleDiagnosticEcuDef ZVW30_ECUS[] = {
  {ENGINE,"ENGINE",true,diagReq1(0x7E0,0x7E8,0x03,0x43,DTC_DECODER_OBD03,READ_ONLY),DIAG_REQ_NONE},
  {HYBRID_PM,"HYBRID / PM",true,DIAG_REQ_NONE,DIAG_REQ_NONE}, {HV_BATTERY,"HV BATTERY",true,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {ABS_SKID,"ABS / SKID",true,DIAG_REQ_NONE,DIAG_REQ_NONE}, {AC,"A/C",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {SRS,"SRS / AIRBAG",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {ECU_EPS,"EPS",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {COMBINATION_METER,"COMB METER",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {BODY,"BODY",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {GATEWAY,"GATEWAY",false,DIAG_REQ_NONE,DIAG_REQ_NONE}
};

static constexpr VehicleDiagnosticEcuDef ZVW35_ECUS[] = {
  // S0231 P0420 read, clear 04->44, post-clear 13B0=00; permanent 0A
  // is intentionally kept separate from the erasable enhanced DTC store.
  {ENGINE,"ENGINE",true,diagReq(0x7E0,0x7E8,0x13,0xB0,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),
    diagReq1(0x7E0,0x7E8,0x04,0x44,DTC_DECODER_RAW,VERIFIED),
    diagReq(0x7E0,0x7E8,0x13,0x80,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),
    diagReq1(0x7E0,0x7E8,0x0A,0x4A,DTC_DECODER_OBD0A,READ_ONLY)},
  // 7E2/7EA service-04 positive ACK observed; no nonzero hybrid fault
  // followed across a clear, so keep write locked pending effect evidence.
  {HYBRID_PM,"HYBRID / PM",true,diagReq(0x7E2,0x7EA,0x13,0xB0,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),
    diagReq1(0x7E2,0x7EA,0x04,0x44,DTC_DECODER_RAW,LOCKED_UNVERIFIED),
    diagReq(0x7E2,0x7EA,0x13,0x80,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY)},
  {HV_BATTERY,"HV BATTERY",true,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {ABS_SKID,"ABS / SKID",true,DIAG_REQ_NONE,DIAG_REQ_NONE}, {AC,"A/C",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {SRS,"SRS / AIRBAG",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {ECU_EPS,"EPS",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {COMBINATION_METER,"COMB METER",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {BODY,"BODY",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {GATEWAY,"GATEWAY",false,DIAG_REQ_NONE,DIAG_REQ_NONE}
};

static constexpr VehicleDiagnosticEcuDef ZVW45_ECUS[] = {
  {ENGINE,"ENGINE",true,diagReq1(0x7E0,0x7E8,0x03,0x43,DTC_DECODER_OBD03,READ_ONLY),DIAG_REQ_NONE},
  {HYBRID_PM,"HYBRID / PM",true,DIAG_REQ_NONE,DIAG_REQ_NONE}, {HV_BATTERY,"HV BATTERY",true,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {ABS_SKID,"ABS / SKID",true,DIAG_REQ_NONE,DIAG_REQ_NONE}, {AC,"A/C",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {SRS,"SRS / AIRBAG",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {ECU_EPS,"EPS",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {COMBINATION_METER,"COMB METER",false,DIAG_REQ_NONE,DIAG_REQ_NONE}, {BODY,"BODY",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {GATEWAY,"GATEWAY",false,DIAG_REQ_NONE,DIAG_REQ_NONE}
};

static constexpr VehicleDiagnosticEcuDef AHV40_ECUS[] = {
  {ENGINE,"ENGINE",true,diagReq(0x7E0,0x7E8,0x13,0xB0,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),
    diagReq1(0x7E0,0x7E8,0x04,0x44,DTC_DECODER_RAW,VERIFIED),
    diagReq1(0x7E0,0x7E8,0x07,0x47,DTC_DECODER_OBD07,READ_ONLY),
    diagReq(0x7E0,0x7E8,0x13,0x80,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY)},
  {HYBRID_PM,"HYBRID / PM",true,diagReq(0x7E2,0x7EA,0x13,0xB0,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),
    diagReq1(0x7E2,0x7EA,0x04,0x44,DTC_DECODER_RAW,VERIFIED),
    diagReq1(0x7E2,0x7EA,0x07,0x47,DTC_DECODER_OBD07,READ_ONLY),
    diagReq(0x7E2,0x7EA,0x13,0x80,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY)},
  {HV_BATTERY,"HV BATTERY",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {ABS_SKID,"ABS / SKID",true,diagReq(0x7B0,0x7B8,0x13,0x80,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),DIAG_REQ_NONE},
  {AC,"A/C",false,diagReq(0x7C4,0x7CC,0x13,0x81,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),
    DIAG_REQ_NONE,diagReq(0x7C4,0x7CC,0x13,0x82,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY)},
  {SRS,"SRS / AIRBAG",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {ECU_EPS,"EPS",false,diagReq(0x7A1,0x7A9,0x13,0x81,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),
    DIAG_REQ_NONE,diagReq(0x7A1,0x7A9,0x13,0x82,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY)},
  {COMBINATION_METER,"COMB METER",false,diagReq(0x7C0,0x7C8,0x13,0x81,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY),
    DIAG_REQ_NONE,diagReq(0x7C0,0x7C8,0x13,0x82,0x53,DTC_DECODER_TOYOTA_13,READ_ONLY)},
  {BODY,"MAIN BODY",false,diagReqTarget(0x40,0x13,0x81,0x53,READ_ONLY),
    DIAG_REQ_NONE,diagReqTarget(0x40,0x13,0x82,0x53,READ_ONLY)},
  {GATEWAY,"GATEWAY",false,DIAG_REQ_NONE,DIAG_REQ_NONE},
  {SMART_KEY,"SMART KEY",false,diagReqTarget(0xB5,0x13,0x81,0x53,READ_ONLY),
    diagClearTarget(0xB5),diagReqTarget(0xB5,0x13,0x82,0x53,READ_ONLY)}
};

static constexpr FanCommandProfileDef FAN_NONE = {DIAG_REQ_NONE,DIAG_REQ_NONE,0,0,0};
static constexpr FanCommandProfileDef NHW20_FAN = {fanReq(0x7E3,0x7EB,6,VERIFIED),fanReq(0x7E3,0x7EB,0,VERIFIED),6,5,500};
static constexpr FanCommandProfileDef ZVW30_FAN = {fanReq(0x7E2,0x7EA,6,LOCKED_UNVERIFIED),fanReq(0x7E2,0x7EA,0,LOCKED_UNVERIFIED),6,5,500};
// S0225/S0231 PHV and S0229/S0230 AHV40: only LEVEL6/MAX is proven.
// Release is by ceasing refresh; a LEVEL0 explicit AUTO command is NOT verified.
static constexpr FanCommandProfileDef ZVW35_FAN = {fanReq(0x7E2,0x7EA,6,VERIFIED),DIAG_REQ_NONE,6,0,1000};
static constexpr FanCommandProfileDef AHV40_FAN = {fanReq(0x7E2,0x7EA,6,VERIFIED),DIAG_REQ_NONE,6,0,1000};

static constexpr VehicleDiagnosticProfile VEHICLE_DIAGNOSTIC_PROFILES[] = {
  {PROFILE_PRIUS_GEN2,PLATFORM_NHW20,"NHW20","NHW20",NHW20_ECUS,(uint8_t)(sizeof(NHW20_ECUS)/sizeof(NHW20_ECUS[0])),NHW20_FAN},
  {PROFILE_PRIUS_GEN3,PLATFORM_ZVW30,"ZVW30","ZVW30",ZVW30_ECUS,(uint8_t)(sizeof(ZVW30_ECUS)/sizeof(ZVW30_ECUS[0])),ZVW30_FAN},
  {PROFILE_PRIUS_PHV_GEN1,PLATFORM_ZVW35,"ZVW35","ZVW35",ZVW35_ECUS,(uint8_t)(sizeof(ZVW35_ECUS)/sizeof(ZVW35_ECUS[0])),ZVW35_FAN},
  {PROFILE_PRIUS_ALPHA_ZVW45,PLATFORM_ZVW45,"ZVW45","ZVW45",ZVW45_ECUS,(uint8_t)(sizeof(ZVW45_ECUS)/sizeof(ZVW45_ECUS[0])),FAN_NONE},
  {PROFILE_CAMRY_HYBRID_GEN1,PLATFORM_AHV40,"AHV40","AHV40L",AHV40_ECUS,(uint8_t)(sizeof(AHV40_ECUS)/sizeof(AHV40_ECUS[0])),AHV40_FAN}
};

static inline const VehicleDiagnosticProfile *diagnosticProfileFor(VehicleProfile profile) {
  for (size_t i=0;i<sizeof(VEHICLE_DIAGNOSTIC_PROFILES)/sizeof(VEHICLE_DIAGNOSTIC_PROFILES[0]);++i)
    if (VEHICLE_DIAGNOSTIC_PROFILES[i].vehicleProfile == profile) return &VEHICLE_DIAGNOSTIC_PROFILES[i];
  return nullptr;
}

static inline bool controlIdentityVerifiedFor(VehicleProfile profile) {
  // This is capability/evidence availability, not the current runtime latch.
  return profile == PROFILE_PRIUS_GEN2 || profile == PROFILE_PRIUS_PHV_GEN1 || profile == PROFILE_CAMRY_HYBRID_GEN1;
}

static inline uint32_t diagnosticSelectableReadMask(const VehicleDiagnosticProfile *profile) {
  if (!profile) return 0;
  uint32_t mask=0;
  for (uint8_t i=0;i<profile->ecuCount && i<32;i++) {
    const DiagnosticCapability c=profile->ecus[i].read.capability;
    if (c == VERIFIED || c == READ_ONLY) mask |= (1UL<<i);
  }
  return mask;
}
