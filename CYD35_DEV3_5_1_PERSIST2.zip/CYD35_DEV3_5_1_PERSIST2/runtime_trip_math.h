#pragma once
#include <stdint.h>

inline uint16_t runtimeCounterDelta16(uint16_t now, uint16_t prior) {
  return (uint16_t)(now - prior);
}
inline uint32_t runtimeOdometer24(uint8_t b1, uint8_t b2, uint8_t b3) {
  return ((uint32_t)b1 << 16) | ((uint32_t)b2 << 8) | b3;
}
inline uint32_t runtimeOdometer20(uint8_t b5, uint8_t b6, uint8_t b7) {
  return ((uint32_t)(b5 & 0x0F) << 16) | ((uint32_t)b6 << 8) | b7;
}
inline double runtimeMetersToMiles(double meters) { return meters / 1609.344; }
struct RuntimeDistanceIntegrator {
  double miles;
  uint32_t lastMs;
  float lastMph;
  bool valid;
};
inline void runtimeDistanceReset(RuntimeDistanceIntegrator &s, uint32_t nowMs) {
  s.miles = 0.0; s.lastMs = nowMs; s.lastMph = 0.0f; s.valid = false;
}
inline void runtimeDistanceUpdateSpeed(RuntimeDistanceIntegrator &s, float mph, uint32_t nowMs) {
  if (mph < 0.0f) mph = -mph;
  if (!s.valid) { s.lastMs = nowMs; s.lastMph = mph; s.valid = true; return; }
  uint32_t dt = nowMs - s.lastMs;
  if (dt <= 5000U) s.miles += ((double)s.lastMph + (double)mph) * 0.5 * ((double)dt / 3600000.0);
  s.lastMs = nowMs; s.lastMph = mph;
}
