Toyota_Hybrid_CYD35_HV_Health_DEV2_8_RAW_META

Field-data-driven next revision after S0192-S0194.

Changes:
- Retains RAW-first and draining STOP.
- Retains event codes 20-26 and MPH/WHEELS decode.
- Fixes STREAM_FILE_CLOSE accounting using explicit bytes/records actually written.
- TFT pressure shedding at 75% CAN queue occupancy while logging.
- Dirty rendering on SPEED and WHEELS pages; other pages retain legacy full redraw behavior for this first measured iteration.
- One startWrite/endWrite transaction per actual TFT refresh when batching is enabled.
- Periodic 30 s forced full repaint on dirty pages.
- Session-local TFT performance metrics IDs 2014-2025 in TVM1 HEALTH schema 3.
- Runtime Serial A/B commands: TFT DIRTY ON/OFF, TFT SHED ON/OFF, TFT BATCH ON/OFF, TFT FULL, TFT STATS.

Queue sizes remain unchanged for A/B comparison.
