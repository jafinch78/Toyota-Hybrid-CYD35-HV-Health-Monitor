/*
  Toyota Hybrid CYD35 HV Health DEV3.5.1 / 1024 queue RAW + META SD25M STORAGERES2 TFTPERF3 DTCFAN2 FUELPROFILE1 WIFIEXIT1 TEST

  Architecture rule:
    - The acquisition/logger implementation below is the v2.4.3 logger core branched from the exact v2.4.2 baseline
      included as logger_v2_4_3_core.inc.
    - Only setup(), loop(), handleTouch(), drawButtons(), and updateDisplay()
      are wrapped so Wi-Fi maintenance can be entered while STOPPED.
    - Wi-Fi is never initialized during the normal logger boot/run path.
    - Entering Wi-Fi permanently tears down BLE/TWAI/CAN runtime services.
      EXIT performs ESP.restart(); logger services are never reconstructed in RAM.
    - Persistent SD + NVS high-water session allocation is used. The card is scanned
      once at mount/recovery; normal START reserves the next Sxxxx in O(1) time and
      never reuses an already-reserved session number.
    - Toyota Hybrid CAN Database v0.9.51 runtime-equivalency metadata is compiled for Gen 2,
      PHV Gen 1, and Camry Hybrid display decoding. Decoder definitions never
      authorize TX; a separate explicit read-only active-poll whitelist does.
    - When an external tester owns the diagnostic bus, CYD immediately software-inhibits
      all diagnostic TX without reinitializing TWAI, preserving the active CAN logging
      session and RX task. Matching validated normalDisplay responses may refresh
      MAIN/TEMP/HV; CANDIDATE/observe-only definitions remain DIAG EXP/evidence-only.
*/

#include <WiFi.h>
#include <WebServer.h>
#include <esp_wifi.h>
#include <esp_heap_caps.h>
#include "database_v0_5_5_decoded_ids.h"
#include "database_v0_9_51_runtime_equivalency.h"
#include "wifi_session_zip.h"
#include "wifi_session_zip_async.h"
#include "wifi_zip_download_async.h"

bool distanceEntryActive = false;

#define setup logger243_setup
#define loop logger243_loop
#define handleTouch logger243_handleTouch
#define drawButtons logger243_drawButtons
#define updateDisplay logger243_updateDisplay
#include "logger_v2_4_3_core.inc"
#undef setup
#undef loop
#undef handleTouch
#undef drawButtons
#undef updateDisplay

constexpr int CYD_WIFI_BTN_X = 125;
constexpr int CYD_WIFI_BTN_Y = 258;
constexpr int CYD_WIFI_BTN_W = 105;
constexpr int CYD_WIFI_BTN_H = 50;
constexpr uint8_t CYD_WIFI_CHANNEL = 6;
constexpr uint8_t CYD_WIFI_MAX_CLIENTS = 4;
constexpr int WIFI_TOUCH_EXIT_X = 300;
constexpr int WIFI_TOUCH_EXIT_Y = 284;
constexpr int WIFI_TOUCH_EXIT_W = 165;
constexpr int WIFI_TOUCH_EXIT_H = 30;

WebServer wifiServer(80);
bool wifiMaintenanceMode = false;
bool wifiConfirmPending = false;
bool wifiZipCompletionLogged = false;
String wifiPendingClear;
char wifiApSsid[32] = {0};
char wifiApPassword[20] = {0};
uint32_t lastWifiUiMs = 0;

// -------------------- DEV2.5 additive PLOT data recorder --------------------
// This subsystem is intentionally isolated from logger_v2_4_3_core.inc.
// It observes the existing loggingActive/sessionDir/live state and writes only
// companion files. No CAN acquisition, decoder, diagnostic, BLE sync, or
// existing session-file logic is modified.
constexpr uint32_t PLOT_SAMPLE_INTERVAL_MS = 200;   // 5 Hz, conservative SD load
constexpr uint32_t PLOT_FLUSH_INTERVAL_MS = 1000;
File plotFile;
bool plotRecorderActive = false;
uint32_t plotLastSampleMs = 0;
uint32_t plotLastFlushMs = 0;
uint32_t plotSampleCount = 0;
uint32_t plotStartMs = 0;
uint32_t plotStartBleSyncSamples = 0;

static uint32_t plotSignalAgeMs(bool valid, uint32_t stampMs, uint32_t nowMs) {
  return valid ? (uint32_t)(nowMs - stampMs) : 0xFFFFFFFFUL;
}

static void plotCsvFloat(bool valid, float value, uint8_t decimals) {
  if (valid && !isnan(value)) plotFile.print(value, decimals);
}

static void plotCsvInt(bool valid, int32_t value) {
  if (valid) plotFile.print(value);
}

static void plotWriteHeader() {
  if (!plotFile) return;
  plotFile.print("Time_ms,Elapsed_s,Session,Profile,ProfileConfidence,BLE_Connected,BLE_Sync_Count,");
  plotFile.print("SOC_pct,Pack_V,Pack_A,Pack_kW,Block_Delta_V,");
  for (uint8_t i=1;i<=14;++i) { plotFile.printf("B%02u_V,", i); }
  for (uint8_t i=1;i<=14;++i) { plotFile.printf("B%02u_R_ohm,", i); }
  plotFile.print("HV_T1_F,HV_T2_F,HV_T3_F,HV_T4_F,MG1_Motor_F,MG2_Motor_F,");
  plotFile.print("ICE_RPM,MG1_RPM,MG2_RPM,Vehicle_mph,FL_mph,FR_mph,RL_mph,RR_mph,");
  plotFile.println("SOC_Age_ms,Electrical_Age_ms,BlockV_Age_ms,Resistance_Age_ms,BatteryTemp_Age_ms,MotorTemp_Age_ms,Wheel_Age_ms,DataQuality");
}

static bool plotRecorderStart() {
  if (plotRecorderActive || !loggingActive || !sdReady || sessionDir[0] == 0) return false;
  char path[64];
  snprintf(path, sizeof(path), "%s/PLOT.CSV", sessionDir);
  plotFile = SD.open(path, FILE_WRITE);
  if (!plotFile) {
    Serial.printf("# PLOT OPEN FAILED,%s\n", path);
    return false;
  }
  plotWriteHeader();
  plotFile.flush();
  plotStartMs = millis();
  plotLastSampleMs = 0;
  plotLastFlushMs = plotStartMs;
  plotSampleCount = 0;
  plotStartBleSyncSamples = bleSyncSamples;
  plotRecorderActive = true;
  Serial.printf("# PLOT STARTED,%s,rate_hz=5,sync=SYNC.CSV\n", path);
  return true;
}

static void plotWriteSummary() {
  if (!sdReady || sessionDir[0] == 0) return;
  char path[72];
  snprintf(path, sizeof(path), "%s/PLOT_SUMMARY.JSON", sessionDir);
  File f = SD.open(path, FILE_WRITE);
  if (!f) return;
  const uint32_t stopMs = millis();
  f.println("{");
  f.printf("  \"session\": \"%s\",\n", sessionName());
  f.printf("  \"profile\": \"%s\",\n", profileLabel(vehicleProfile));
  f.printf("  \"profile_confidence\": %u,\n", (unsigned)profileConfidence);
  f.println("  \"sample_rate_hz\": 5,");
  f.printf("  \"sample_count\": %lu,\n", (unsigned long)plotSampleCount);
  f.printf("  \"duration_ms\": %lu,\n", (unsigned long)(stopMs - plotStartMs));
  f.printf("  \"ble_sync_records_during_plot\": %lu,\n", (unsigned long)(bleSyncSamples - plotStartBleSyncSamples));
  f.println("  \"ble_sync_file\": \"SYNC.CSV\",");
  f.println("  \"event_file\": \"EVENTS.CSV\",");
  f.println("  \"notes\": \"PLOT.CSV uses the same Sxxxx session and ESP32 time base as SYNC.CSV and EVENTS.CSV. Blank values are unavailable or stale.\"");
  f.println("}");
  f.close();
}

static void plotRecorderStop() {
  if (!plotRecorderActive) return;
  if (plotFile) { plotFile.flush(); plotFile.close(); }
  plotRecorderActive = false;
  plotWriteSummary();
  Serial.printf("# PLOT CLOSED,%s,samples=%lu\n", sessionName(), (unsigned long)plotSampleCount);
}

static void plotWriteSample(uint32_t nowMs) {
  if (!plotRecorderActive || !plotFile) return;
  const bool soc = signalFresh(live.socValid, live.socMs, nowMs);
  const bool elec = signalFresh(live.electricalValid, live.electricalMs, nowMs);
  const bool blockV = signalFresh(live.blockVoltageValid, live.blockVoltageMs, nowMs);
  const bool resistance = signalFresh(live.resistanceValid, live.resistanceMs, nowMs);
  const bool battTemp = signalFresh(live.batteryTempValid, live.batteryTempMs, nowMs);
  const bool motorTemp = signalFresh(live.motorTempValid, live.motorTempMs, nowMs);
  const bool ice = signalFresh(live.engineRPMValid, live.engineRPMMs, nowMs);
  const bool mg = signalFresh(live.mgPowertrainValid, live.mgPowertrainMs, nowMs);
  const bool veh = live.vehicleSpeedValid && nowMs-live.vehicleSpeedMs <= 2000;
  const bool wheels = live.wheelSpeedValid && nowMs-live.wheelSpeedMs <= 2000;

  plotFile.print(nowMs); plotFile.print(',');
  plotFile.print((nowMs - plotStartMs) / 1000.0f, 3); plotFile.print(',');
  plotFile.print(sessionName()); plotFile.print(',');
  plotFile.print(profileLabel(vehicleProfile)); plotFile.print(',');
  plotFile.print(profileConfidence); plotFile.print(',');
  plotFile.print(bleConnected ? 1 : 0); plotFile.print(',');
  plotFile.print(bleSyncSamples); plotFile.print(',');
  plotCsvFloat(soc, live.socPct, 2); plotFile.print(',');
  plotCsvFloat(elec, live.packVolts, 2); plotFile.print(',');
  plotCsvFloat(elec, live.packAmps, 2); plotFile.print(',');
  plotCsvFloat(elec, live.packKW, 2); plotFile.print(',');
  plotCsvFloat(blockV, live.blockDeltaV, 3); plotFile.print(',');
  for (uint8_t i=0;i<14;++i) { plotCsvFloat(blockV && i<live.blockCount, live.blockVolts[i], 3); plotFile.print(','); }
  for (uint8_t i=0;i<14;++i) { plotCsvFloat(resistance && i<live.blockCount, live.internalResistance[i], 4); plotFile.print(','); }
  plotCsvFloat(battTemp && live.batteryTempCount>0, live.batteryTempsF[0], 1); plotFile.print(',');
  plotCsvFloat(battTemp && live.batteryTempCount>1, live.batteryTempsF[1], 1); plotFile.print(',');
  plotCsvFloat(battTemp && live.batteryTempCount>2, live.batteryTempsF[2], 1); plotFile.print(',');
  plotCsvFloat(battTemp && live.batteryTempCount>3, live.batteryTempsF[3], 1); plotFile.print(',');
  plotCsvFloat(motorTemp, live.mg1StatorF, 1); plotFile.print(',');
  plotCsvFloat(motorTemp, live.mg2StatorF, 1); plotFile.print(',');
  plotCsvInt(ice, live.engineRPM); plotFile.print(',');
  plotCsvInt(mg, live.mg1RPM); plotFile.print(',');
  plotCsvInt(mg, live.mg2RPM); plotFile.print(',');
  plotCsvFloat(veh, live.vehicleSpeedMph, 2); plotFile.print(',');
  for (uint8_t i=0;i<4;++i) { plotCsvFloat(wheels, live.wheelSpeedMph[i], 2); plotFile.print(','); }
  plotFile.print(plotSignalAgeMs(live.socValid, live.socMs, nowMs)); plotFile.print(',');
  plotFile.print(plotSignalAgeMs(live.electricalValid, live.electricalMs, nowMs)); plotFile.print(',');
  plotFile.print(plotSignalAgeMs(live.blockVoltageValid, live.blockVoltageMs, nowMs)); plotFile.print(',');
  plotFile.print(plotSignalAgeMs(live.resistanceValid, live.resistanceMs, nowMs)); plotFile.print(',');
  plotFile.print(plotSignalAgeMs(live.batteryTempValid, live.batteryTempMs, nowMs)); plotFile.print(',');
  plotFile.print(plotSignalAgeMs(live.motorTempValid, live.motorTempMs, nowMs)); plotFile.print(',');
  plotFile.print(plotSignalAgeMs(live.wheelSpeedValid, live.wheelSpeedMs, nowMs)); plotFile.print(',');
  plotFile.println(dataQualityLabel());
  ++plotSampleCount;
}

static void servicePlotRecorder() {
  // DEV2.9 RAW+META: PLOT products are reconstructed offline by the preprocessor.
  return;
}

static String htmlEscape(const String &s) {
  String out;
  out.reserve(s.length() + 16);
  for (size_t i = 0; i < s.length(); ++i) {
    char c = s[i];
    if (c == '&') out += F("&amp;");
    else if (c == '<') out += F("&lt;");
    else if (c == '>') out += F("&gt;");
    else if (c == '\"') out += F("&quot;");
    else out += c;
  }
  return out;
}

static bool validSessionName(const String &name) {
  if (name.length() != 5 || name[0] != 'S') return false;
  for (uint8_t i = 1; i < 5; ++i) if (!isDigit(name[i])) return false;
  return true;
}

static bool validFileName(const String &name) {
  if (name.length() == 0 || name.length() > 48) return false;
  if (name.indexOf('/') >= 0 || name.indexOf('\\') >= 0 || name.indexOf("..") >= 0) return false;
  return true;
}

static String sessionPath(const String &session) { return String("/CANLOG/") + session; }
static String zipPath(const String &session) { return String("/CANLOG/_ZIP/") + session + ".zip"; }

static bool ensureZipDirectory() {
  if (SD.exists("/CANLOG/_ZIP")) return true;
  return SD.mkdir("/CANLOG/_ZIP");
}

static uint64_t directoryBytes(const String &path) {
  File dir = SD.open(path.c_str());
  if (!dir || !dir.isDirectory()) { if (dir) dir.close(); return 0; }
  uint64_t total = 0;
  File f = dir.openNextFile();
  while (f) {
    if (!f.isDirectory()) total += f.size();
    f.close();
    f = dir.openNextFile();
  }
  dir.close();
  return total;
}

static uint64_t fileBytes(const String &path) {
  File f = SD.open(path.c_str(), FILE_READ);
  if (!f || f.isDirectory()) { if (f) f.close(); return 0; }
  uint64_t size = f.size();
  f.close();
  return size;
}

static String humanBytes(uint64_t bytes) {
  if (bytes >= 1024ULL * 1024ULL) return String((double)bytes / (1024.0 * 1024.0), 1) + " MB";
  if (bytes >= 1024ULL) return String((double)bytes / 1024.0, 1) + " KB";
  return String((unsigned long long)bytes) + " B";
}

static bool clearDirectoryContents(const String &path) {
  File dir = SD.open(path.c_str());
  if (!dir || !dir.isDirectory()) { if (dir) dir.close(); return false; }
  bool ok = true;
  File f = dir.openNextFile();
  while (f) {
    String childName = String(f.name());
    bool childDir = f.isDirectory();
    f.close();
    String childPath = childName.startsWith("/") ? childName : path + "/" + childName;
    if (childDir) {
      if (!clearDirectoryContents(childPath)) ok = false;
      if (!SD.rmdir(childPath.c_str())) ok = false;
    } else if (!SD.remove(childPath.c_str())) {
      ok = false;
    }
    if (!ok) break;
    f = dir.openNextFile();
  }
  dir.close();
  return ok;
}

static void sendPage(const String &body, int code = 200) {
  String html = F("<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                  "<title>Toyota CYD Wi-Fi Files</title><style>"
                  "*{box-sizing:border-box}body{font-family:Arial,sans-serif;max-width:900px;margin:0 auto;padding:18px;background:#f5f6f7;color:#171717}"
                  "h1{font-size:1.7rem;margin:.2em 0}.sub{color:#555;margin:.4em 0 1.2em}.session{background:white;border:1px solid #ddd;border-radius:12px;padding:14px;margin:10px 0;box-shadow:0 1px 2px #0001}"
                  ".sessionHead{display:flex;justify-content:space-between;gap:12px;align-items:baseline}.sessionName{font-size:1.2rem;font-weight:700}.size{color:#555;white-space:nowrap}.state{font-size:.85rem;color:#666;margin-top:3px}"
                  ".actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}.btn,button{appearance:none;border:1px solid #aaa;border-radius:8px;background:#fff;color:#111;padding:9px 12px;text-decoration:none;font-size:.95rem;line-height:1.15}"
                  ".primary{background:#1769aa;color:white;border-color:#1769aa}.danger{background:#a51d25;color:white;border-color:#a51d25}.secondary{background:#eee}.actions form{margin:0}"
                  ".notice{background:#fff8df;border:1px solid #ead28b;border-radius:10px;padding:10px 12px}.tableWrap{overflow-x:auto;background:white;border-radius:10px}table{border-collapse:collapse;width:100%;min-width:440px}td,th{border-bottom:1px solid #ddd;padding:10px;text-align:left}"
                  "@media(max-width:520px){body{padding:12px}h1{font-size:1.45rem}.sessionHead{align-items:flex-start}.actions{display:grid;grid-template-columns:1fr 1fr}.btn,button{width:100%;text-align:center}.actions form{width:100%}}"
                  "</style></head><body>");
  html += body;
  html += F("</body></html>");
  wifiServer.send(code, "text/html", html);
}

static void streamRootBegin() {
  wifiServer.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  wifiServer.sendHeader("Pragma", "no-cache");
  wifiServer.sendHeader("Connection", "close");
  wifiServer.setContentLength(CONTENT_LENGTH_UNKNOWN);
  wifiServer.send(200, "text/html", "");
  wifiServer.sendContent(F("<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                           "<title>Toyota CYD Wi-Fi Files</title><style>"
                           "*{box-sizing:border-box}body{font-family:Arial,sans-serif;max-width:900px;margin:0 auto;padding:18px;background:#f5f6f7;color:#171717}"
                           "h1{font-size:1.7rem;margin:.2em 0}.sub{color:#555;margin:.4em 0 1.2em}.session{display:flex;gap:12px;align-items:center;background:white;border:1px solid #ddd;border-radius:10px;padding:11px 12px;margin:8px 0}"
                           ".pick{transform:scale(1.25);margin:0 4px}.sessionMain{flex:1;min-width:0}.sessionHead{display:flex;justify-content:space-between;gap:12px;align-items:baseline}.sessionName{font-size:1.08rem;font-weight:700}.size{color:#555;white-space:nowrap}.state{font-size:.85rem;color:#666;margin-top:3px}"
                           ".actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;position:sticky;bottom:0;background:#f5f6f7;padding:10px 0 6px}.btn,button{appearance:none;border:1px solid #aaa;border-radius:8px;background:#fff;color:#111;padding:9px 12px;text-decoration:none;font-size:.95rem;line-height:1.15}"
                           ".primary{background:#1769aa;color:white;border-color:#1769aa}.danger{background:#a51d25;color:white;border-color:#a51d25}.secondary{background:#eee}.notice{background:#fff8df;border:1px solid #ead28b;border-radius:10px;padding:10px 12px;margin:8px 0}"
                           "@media(max-width:520px){body{padding:12px}h1{font-size:1.45rem}.actions{display:grid;grid-template-columns:1fr 1fr}.btn,button{width:100%;text-align:center}}"
                           "</style></head><body>"));
}

static void streamRootEnd() {
  wifiServer.sendContent(F("</body></html>"));
  wifiServer.sendContent("");
}

static void streamRootChunk(const String &chunk) {
  wifiServer.sendContent(chunk);
  delay(0);
}

static void handleWifiRoot() {
  uint32_t heapBefore = ESP.getFreeHeap();
  uint32_t largestBefore = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
  Serial.printf("# WIFI ROOT START,heap=%u,largest=%u,clients=%u\n",
                heapBefore, largestBefore, (unsigned)WiFi.softAPgetStationNum());

  streamRootBegin();
  streamRootChunk(F("<h1>Toyota CYD v2.4.4 RC1.4 R2.5 - Wi-Fi Files</h1><p class='sub'>Logger runtime is offline. SD maintenance only.</p>"));
  streamRootChunk("<p class='sub'>Runtime DB: " + String(TOYOTA_CAN_DB_RUNTIME_REVISION) +
                  " &middot; Legacy catalog: v" + String(TOYOTA_CAN_DB_VERSION) +
                  " / " + String(DB_DECODED_ID_COUNT) +
                  " read-only definitions &middot; AP channel " + String(CYD_WIFI_CHANNEL) +
                  " &middot; Wi-Fi sleep OFF</p>");

  if (wifiZipDownloadBusy()) {
    streamRootChunk("<div class='notice'><b>Downloading " + htmlEscape(wifiZipDownloadSession()) +
                    ".zip:</b> " + String(wifiZipDownloadProgress()) + "% &middot; " +
                    humanBytes(wifiZipDownloadSentBytes()) + " / " + humanBytes(wifiZipDownloadTotalBytes()) +
                    ". One ZIP download is allowed at a time; other clients may continue viewing this status page.</div>");
    streamRootChunk(F("<div class='actions'><form method='POST' action='/download-cancel'><button class='danger' type='submit'>Cancel Download</button></form><a class='btn secondary' href='/exit'>EXIT / RESTART LOGGER</a></div>"
                      "<script>setTimeout(function(){location.replace('/');},1500);</script>"));
    streamRootEnd();
    return;
  }

  if (storedSessionZipAsyncBusy()) {
    String s = storedSessionZipAsyncSession();
    streamRootChunk("<div class='notice'><b>Preparing " + htmlEscape(s) + ".zip:</b> " +
                    String(storedSessionZipAsyncProgress()) +
                    "% complete. ZIP preparation remains cooperative so Wi-Fi/HTTP can continue to run.</div>");
    streamRootChunk(F("<div class='actions'><form method='POST' action='/zip-cancel'><button class='danger' type='submit'>Cancel ZIP</button></form><a class='btn secondary' href='/exit'>EXIT / RESTART LOGGER</a></div>"
                      "<script>setTimeout(function(){location.replace('/');},1500);</script>"));
    streamRootEnd();
    return;
  }

  if (wifiZipDownloadAborted()) streamRootChunk("<div class='notice'><b>Last download stopped:</b> " + htmlEscape(wifiZipDownloadError()) + "</div>");
  else if (wifiZipDownloadFailed()) streamRootChunk("<div class='notice'><b>Last download error:</b> " + htmlEscape(wifiZipDownloadError()) + "</div>");
  if (storedSessionZipAsyncFailed()) streamRootChunk("<div class='notice'><b>Last ZIP error:</b> " + htmlEscape(storedSessionZipAsyncError()) + "</div>");

  streamRootChunk(F("<div class='notice'><b>Selected-session actions:</b> Select one session below, then use the shared action buttons. Temporary ZIPs remain on the microSD until Delete ZIP or Clear Contents removes them.</div>"));
  streamRootChunk(F("<form id='sessionActions'>"));

  File root = SD.open("/CANLOG");
  if (root && root.isDirectory()) {
    File entry = root.openNextFile();
    while (entry) {
      if (entry.isDirectory()) {
        String full = String(entry.name());
        int slash = full.lastIndexOf('/');
        String name = slash >= 0 ? full.substring(slash + 1) : full;
        if (validSessionName(name)) {
          uint64_t bytes = directoryBytes(sessionPath(name));
          uint64_t zbytes = fileBytes(zipPath(name));
          String row;
          row.reserve(320);
          row += "<label class='session'><input class='pick' type='radio' name='s' value='" + name + "'><div class='sessionMain'><div class='sessionHead'><div class='sessionName'>" + htmlEscape(name) + "</div><div class='size'>" + humanBytes(bytes) + "</div></div><div class='state'>";
          if (bytes == 0) row += "EMPTY / CLEARED";
          else row += "Session data ready";
          if (zbytes > 0) row += " &middot; ZIP ready (" + humanBytes(zbytes) + ")";
          row += "</div></div></label>";
          streamRootChunk(row);
        }
      }
      entry.close();
      entry = root.openNextFile();
    }
  }
  if (root) root.close();

  streamRootChunk(F("<div class='actions'>"
                    "<button class='secondary' type='submit' formmethod='GET' formaction='/session'>View Files</button>"
                    "<button class='primary' type='submit' formmethod='POST' formaction='/zip-create'>Prepare ZIP</button>"
                    "<button class='primary' type='button' onclick='downloadSelected()'>Download ZIP</button>"
                    "<button class='secondary' type='submit' formmethod='POST' formaction='/zip-delete'>Delete ZIP</button>"
                    "<button class='danger' type='submit' formmethod='GET' formaction='/clear'>Clear Contents</button>"
                    "<a class='btn secondary' href='/exit'>EXIT / RESTART LOGGER</a>"
                    "</div></form>"));

  streamRootChunk(F(R"rawliteral(
<script>
function selectedSession() {
  var e = document.querySelector("input[name='s']:checked");
  if (!e) { alert("Select one session first."); return null; }
  return e.value;
}
function canlogExportName() {
  var d = new Date();
  function p2(v) { return (v < 10 ? "0" : "") + v; }
  var h24 = d.getHours();
  var ap = h24 >= 12 ? "P" : "A";
  var h12 = h24 % 12;
  if (h12 === 0) h12 = 12;
  var yy = String(d.getFullYear()).slice(-2);
  return "CANLOG_" + p2(d.getMonth() + 1) + p2(d.getDate()) + yy +
         "_" + p2(h12) + p2(d.getMinutes()) + ap + "M.zip";
}
function downloadSelected() {
  var session = selectedSession();
  if (!session) return false;
  var url = "http://" + location.hostname + ":81/" + canlogExportName() +
            "?s=" + encodeURIComponent(session);
  window.open(url, "_blank");
  return false;
}
</script>
)rawliteral"));

  streamRootEnd();
  uint32_t heapAfter = ESP.getFreeHeap();
  uint32_t largestAfter = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
  Serial.printf("# WIFI ROOT END,heap=%u,largest=%u\n", heapAfter, largestAfter);
}

static void handleWifiSession() {
  if (storedSessionZipAsyncBusy() || wifiZipDownloadBusy()) { wifiServer.send(409, "text/plain", "SD transfer in progress; retry shortly."); return; }
  String s = wifiServer.arg("s");
  if (!validSessionName(s)) { sendPage(F("<h2>Invalid session</h2>"), 400); return; }
  String path = sessionPath(s);
  File dir = SD.open(path.c_str());
  if (!dir || !dir.isDirectory()) { if (dir) dir.close(); sendPage(F("<h2>Session not found</h2>"), 404); return; }
  String body = "<h1>" + htmlEscape(s) + "</h1><div class='tableWrap'><table><tr><th>File</th><th>Size</th><th>Action</th></tr>";
  File f = dir.openNextFile();
  while (f) {
    if (!f.isDirectory()) {
      String full = String(f.name());
      int slash = full.lastIndexOf('/');
      String name = slash >= 0 ? full.substring(slash + 1) : full;
      if (validFileName(name)) body += "<tr><td>" + htmlEscape(name) + "</td><td>" + humanBytes(f.size()) + "</td><td><a href='/download?s=" + s + "&f=" + name + "'>Download</a></td></tr>";
    }
    f.close();
    f = dir.openNextFile();
  }
  dir.close();
  body += F("</table></div><p><a class='btn secondary' href='/'>Back</a></p>");
  sendPage(body);
}

static void handleWifiDownload() {
  if (storedSessionZipAsyncBusy() || wifiZipDownloadBusy()) { wifiServer.send(409, "text/plain", "SD transfer in progress; retry shortly."); return; }
  String s = wifiServer.arg("s"), f = wifiServer.arg("f");
  if (!validSessionName(s) || !validFileName(f)) { wifiServer.send(400, "text/plain", "Invalid path"); return; }
  String path = sessionPath(s) + "/" + f;
  File file = SD.open(path.c_str(), FILE_READ);
  if (!file || file.isDirectory()) { if (file) file.close(); wifiServer.send(404, "text/plain", "Not found"); return; }
  wifiServer.sendHeader("Content-Disposition", "attachment; filename=\"" + f + "\"");
  wifiServer.streamFile(file, "application/octet-stream");
  file.close();
}

static void handleWifiZipCreate() {
  String s = wifiServer.arg("s");
  if (!validSessionName(s)) { sendPage(F("<h2>Invalid session</h2>"), 400); return; }
  if (wifiZipDownloadBusy()) { sendPage(F("<h2>A ZIP download is active. Wait or cancel it first.</h2>"), 409); return; }
  if (storedSessionZipAsyncBusy()) { sendPage(F("<h2>A ZIP is already being prepared.</h2>"), 409); return; }
  String source = sessionPath(s);
  uint64_t sourceBytes = directoryBytes(source);
  if (sourceBytes == 0) { sendPage(F("<h2>Session is empty</h2><p>No ZIP was created.</p>"), 400); return; }
  if (!ensureZipDirectory()) { sendPage(F("<h2>ZIP folder error</h2><p>Could not create /CANLOG/_ZIP.</p>"), 500); return; }

  String error;
  String zp = zipPath(s);
  Serial.printf("# WIFI ZIP ASYNC START,%s,%llu bytes\n", s.c_str(), (unsigned long long)sourceBytes);
  if (!startStoredSessionZipAsync(s, source, zp, sourceBytes, error)) {
    Serial.printf("# WIFI ZIP ASYNC FAILED_TO_START,%s,%s\n", s.c_str(), error.c_str());
    sendPage("<h1>ZIP creation failed</h1><p>" + htmlEscape(error) + "</p><p><a class='btn secondary' href='/'>Back</a></p>", 500);
    return;
  }
  wifiZipCompletionLogged = false;
  wifiServer.sendHeader("Location", "/");
  wifiServer.send(303, "text/plain", "ZIP preparation started");
}

static void handleWifiZipDownload() {
  // Compatibility route: redirect legacy port-80 ZIP links to the dedicated
  // cooperative port-81 download service.
  if (storedSessionZipAsyncBusy()) { wifiServer.send(409, "text/plain", "ZIP preparation still in progress."); return; }
  String s = wifiServer.arg("s");
  if (!validSessionName(s)) { wifiServer.send(400, "text/plain", "Invalid session"); return; }
  if (fileBytes(zipPath(s)) == 0) { wifiServer.send(404, "text/plain", "ZIP not prepared"); return; }
  String dl = String("http://") + WiFi.softAPIP().toString() + ":" + WIFI_ZIP_DOWNLOAD_PORT +
              "/CANLOG_010100_1200AM.zip?s=" + s;
  wifiServer.sendHeader("Location", dl);
  wifiServer.send(303, "text/plain", "Use the main Wi-Fi page Download ZIP button for workstation-local timestamp naming.");
}

static void handleWifiZipDelete() {
  if (storedSessionZipAsyncBusy() || wifiZipDownloadBusy()) { sendPage(F("<h2>An SD transfer is active. Wait or cancel it before deleting.</h2>"), 409); return; }
  String s = wifiServer.arg("s");
  if (!validSessionName(s)) { sendPage(F("<h2>Invalid session</h2>"), 400); return; }
  String zp = zipPath(s);
  uint64_t before = fileBytes(zp);
  if (before == 0) { sendPage("<h1>No temporary ZIP</h1><p>" + htmlEscape(s) + ".zip is not present.</p><p><a class='btn secondary' href='/'>Back</a></p>"); return; }
  if (!SD.remove(zp.c_str())) { sendPage(F("<h1>ZIP delete failed</h1><p>The temporary ZIP remains on the microSD.</p>"), 500); return; }
  Serial.printf("# WIFI ZIP DELETED,%s,%llu bytes\n", s.c_str(), (unsigned long long)before);
  wifiServer.sendHeader("Location", "/");
  wifiServer.send(303, "text/plain", "Temporary ZIP deleted");
}

static void handleWifiZipCancel() {
  if (storedSessionZipAsyncBusy()) {
    String s = storedSessionZipAsyncSession();
    cancelStoredSessionZipAsync();
    Serial.printf("# WIFI ZIP CANCELLED,%s\n", s.c_str());
  }
  wifiServer.sendHeader("Location", "/");
  wifiServer.send(303, "text/plain", "ZIP preparation cancelled");
}

static void handleWifiDownloadCancel() {
  if (wifiZipDownloadBusy()) cancelWifiZipDownload();
  wifiServer.sendHeader("Location", "/");
  wifiServer.send(303, "text/plain", "Download cancelled");
}

static void handleWifiClearRequest() {
  if (storedSessionZipAsyncBusy() || wifiZipDownloadBusy()) { sendPage(F("<h2>An SD transfer is active. Wait or cancel it before clearing.</h2>"), 409); return; }
  String s = wifiServer.arg("s");
  if (!validSessionName(s)) { sendPage(F("<h2>Invalid session</h2>"), 400); return; }
  wifiPendingClear = s;
  wifiConfirmPending = true;
  String body = "<h1>Confirm clear</h1><p>Clear contents of <b>" + htmlEscape(s) + "</b> while keeping the empty <b>" + htmlEscape(s) + "</b> folder for session-number continuity?</p>";
  if (fileBytes(zipPath(s)) > 0) body += F("<div class='notice'>A temporary ZIP for this session also exists. It will be deleted first so cleared data is not left behind in /CANLOG/_ZIP.</div>");
  body += "<div class='actions'><form method='POST' action='/clear-confirm'><input type='hidden' name='s' value='" + s + "'><button class='danger' type='submit'>CLEAR CONTENTS OF " + s + "</button></form><a class='btn secondary' href='/'>Cancel</a></div>";
  sendPage(body);
}

static void handleWifiClearConfirm() {
  if (storedSessionZipAsyncBusy() || wifiZipDownloadBusy()) { sendPage(F("<h2>An SD transfer is active. Clear refused.</h2>"), 409); return; }
  String s = wifiServer.arg("s");
  if (!wifiConfirmPending || s != wifiPendingClear || !validSessionName(s)) { sendPage(F("<h2>Confirmation expired or invalid.</h2>"), 400); return; }
  wifiConfirmPending = false;
  wifiPendingClear = "";
  String path = sessionPath(s);
  uint64_t sourceBefore = directoryBytes(path);
  String zp = zipPath(s);
  uint64_t zipBefore = fileBytes(zp);
  if (zipBefore > 0 && !SD.remove(zp.c_str())) {
    sendPage(F("<h1>Clear stopped</h1><p>Temporary ZIP could not be removed, so session contents were not cleared.</p>"), 500);
    return;
  }
  bool ok = clearDirectoryContents(path);
  if (ok && SD.exists(path.c_str())) {
    uint64_t freed = sourceBefore + zipBefore;
    sendPage("<h1>Cleared " + htmlEscape(s) + "</h1><p>Freed approximately <b>" + humanBytes(freed) + "</b>. The empty session folder was retained for v2.4.2 numbering continuity.</p><p><a class='btn secondary' href='/'>Back</a></p>");
  } else {
    sendPage("<h1>Clear incomplete</h1><p>Stopped on SD error. The session folder was not intentionally removed.</p><p><a class='btn secondary' href='/'>Back</a></p>", 500);
  }
}

static void handleWifiExit() {
  if (storedSessionZipAsyncBusy()) cancelStoredSessionZipAsync();
  if (wifiZipDownloadBusy()) cancelWifiZipDownload();
  wifiServer.send(200, "text/plain", "Restarting logger...");
  delay(250);
  ESP.restart();
}

static void wifiEventHandler(WiFiEvent_t event, WiFiEventInfo_t info) {
  if (event == ARDUINO_EVENT_WIFI_AP_STACONNECTED) {
    const wifi_event_ap_staconnected_t &e = info.wifi_ap_staconnected;
    Serial.printf("# WIFI STA CONNECTED,%02X:%02X:%02X:%02X:%02X:%02X,AID=%u\n",
                  e.mac[0], e.mac[1], e.mac[2], e.mac[3], e.mac[4], e.mac[5], (unsigned)e.aid);
  } else if (event == ARDUINO_EVENT_WIFI_AP_STADISCONNECTED) {
    const wifi_event_ap_stadisconnected_t &e = info.wifi_ap_stadisconnected;
    Serial.printf("# WIFI STA DISCONNECTED,%02X:%02X:%02X:%02X:%02X:%02X,AID=%u,REASON=%u\n",
                  e.mac[0], e.mac[1], e.mac[2], e.mac[3], e.mac[4], e.mac[5],
                  (unsigned)e.aid, (unsigned)e.reason);
  }
}

static void serviceWifiMaintenanceUi() {
  uint32_t nowMs = millis();
  if (nowMs - lastWifiUiMs < 500) return;
  lastWifiUiMs = nowMs;
  uint8_t clients = (uint8_t)WiFi.softAPgetStationNum();

  tft.fillRect(15, 225, 455, 55, TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString(String("Clients: ") + clients + "   CH: " + CYD_WIFI_CHANNEL + "   Sleep: OFF", 20, 228, 2);
  if (wifiZipDownloadBusy()) {
    tft.drawString(String("DL ") + wifiZipDownloadSession() + ": " + wifiZipDownloadProgress() + "%", 20, 252, 2);
  } else if (storedSessionZipAsyncBusy()) {
    tft.drawString(String("ZIP ") + storedSessionZipAsyncSession() + ": " + storedSessionZipAsyncProgress() + "%", 20, 252, 2);
  } else if (storedSessionZipAsyncDone()) {
    tft.drawString(String("ZIP ready: ") + storedSessionZipAsyncSession(), 20, 252, 2);
  } else if (storedSessionZipAsyncFailed()) {
    tft.drawString("ZIP last result: stopped/error", 20, 252, 2);
  }

  // Reference behavior from field-tested DIAG4 R7.4.2 and R7.4.3.
  tft.fillRoundRect(WIFI_TOUCH_EXIT_X, WIFI_TOUCH_EXIT_Y, WIFI_TOUCH_EXIT_W, WIFI_TOUCH_EXIT_H, 6, TFT_BLUE);
  tft.drawRoundRect(WIFI_TOUCH_EXIT_X, WIFI_TOUCH_EXIT_Y, WIFI_TOUCH_EXIT_W, WIFI_TOUCH_EXIT_H, 6, TFT_WHITE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE);
  tft.drawString("EXIT / RESTART", WIFI_TOUCH_EXIT_X + WIFI_TOUCH_EXIT_W / 2,
                 WIFI_TOUCH_EXIT_Y + WIFI_TOUCH_EXIT_H / 2, 2);
  tft.setTextDatum(TL_DATUM);
}

static void serviceWifiMaintenanceTouch() {
  uint32_t nowMs = millis();
  uint16_t x = 0, y = 0;
  digitalWrite(SD_CS_PIN, HIGH);
  bool pressed = tft.getTouch(&x, &y);
  if (pressed) {
    if (!touchWasDown) {
      touchWasDown = true;
      touchDownX = x;
      touchDownY = y;
      Serial.printf("# TOUCH DOWN,%u,%u\n", x, y);
    }
    return;
  }
  if (!touchWasDown) return;
  touchWasDown = false;
  if (nowMs - lastTouchMs < 250) return;
  lastTouchMs = nowMs;

  const bool exitPressed = touchDownX >= WIFI_TOUCH_EXIT_X &&
                           touchDownX < WIFI_TOUCH_EXIT_X + WIFI_TOUCH_EXIT_W &&
                           touchDownY >= WIFI_TOUCH_EXIT_Y &&
                           touchDownY < WIFI_TOUCH_EXIT_Y + WIFI_TOUCH_EXIT_H;
  if (!exitPressed) return;
  Serial.println("# WIFI TOUCH EXIT,RESTARTING LOGGER");
  if (storedSessionZipAsyncBusy()) cancelStoredSessionZipAsync();
  if (wifiZipDownloadBusy()) cancelWifiZipDownload();
  delay(250);
  ESP.restart();
}

static void shutdownLoggerServicesForWifi() {
  diagnosticEnabled = false;
  fastDiagActive = false;
  if (canReceiveTaskHandle != nullptr) {
    vTaskDelete(canReceiveTaskHandle);
    canReceiveTaskHandle = nullptr;
  }
  twai_stop();
  twai_driver_uninstall();
  twaiNormalMode = false;
  if (bleStackInitialized) {
    BLEDevice::deinit(true);
    bleStackInitialized = false;
    bleServiceReady = false;
    bleConnected = false;
  }
  if (bleSyncQueue != nullptr) { vQueueDelete(bleSyncQueue); bleSyncQueue = nullptr; }
  if (bleCommandQueue != nullptr) { vQueueDelete(bleCommandQueue); bleCommandQueue = nullptr; }
}

static void enterWifiMaintenanceMode() {
  if (wifiMaintenanceMode || loggingActive || !sdReady) return;
  shutdownLoggerServicesForWifi();
  wifiMaintenanceMode = true;
  uint32_t suffix = (uint32_t)(ESP.getEfuseMac() & 0xFFFF);
  snprintf(wifiApSsid, sizeof(wifiApSsid), "ToyotaCYD-Files-%04X", suffix);
  snprintf(wifiApPassword, sizeof(wifiApPassword), "Toyota%04Xfiles", suffix);

  WiFi.onEvent(wifiEventHandler);
  WiFi.mode(WIFI_AP);
  esp_err_t psResult = esp_wifi_set_ps(WIFI_PS_NONE);
  Serial.printf("# WIFI AP CONFIG,channel=%u,max_clients=%u,power_save=OFF,ps_result=%d\n",
                (unsigned)CYD_WIFI_CHANNEL, (unsigned)CYD_WIFI_MAX_CLIENTS, (int)psResult);

  if (!WiFi.softAP(wifiApSsid, wifiApPassword, CYD_WIFI_CHANNEL, false, CYD_WIFI_MAX_CLIENTS)) {
    tft.fillScreen(TFT_RED);
    tft.setTextColor(TFT_WHITE, TFT_RED);
    tft.drawString("WIFI AP FAILED", 40, 110, 4);
    tft.drawString("RESTART REQUIRED", 40, 160, 3);
    return;
  }

  wifiServer.on("/", HTTP_GET, handleWifiRoot);
  wifiServer.on("/session", HTTP_GET, handleWifiSession);
  wifiServer.on("/download", HTTP_GET, handleWifiDownload);
  wifiServer.on("/zip-create", HTTP_POST, handleWifiZipCreate);
  wifiServer.on("/zip-download", HTTP_GET, handleWifiZipDownload);
  wifiServer.on("/zip-delete", HTTP_POST, handleWifiZipDelete);
  wifiServer.on("/zip-cancel", HTTP_POST, handleWifiZipCancel);
  wifiServer.on("/download-cancel", HTTP_POST, handleWifiDownloadCancel);
  wifiServer.on("/clear", HTTP_GET, handleWifiClearRequest);
  wifiServer.on("/clear-confirm", HTTP_POST, handleWifiClearConfirm);
  wifiServer.on("/exit", HTTP_GET, handleWifiExit);
  wifiServer.onNotFound([](){ wifiServer.send(404, "text/plain", "Not found"); });
  wifiServer.begin();
  beginWifiZipDownloadServer();

  Serial.printf("# WIFI AP READY,%s,http://%s,channel=%u,zip_download_port=%u\n",
                wifiApSsid, WiFi.softAPIP().toString().c_str(), (unsigned)CYD_WIFI_CHANNEL,
                (unsigned)WIFI_ZIP_DOWNLOAD_PORT);
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("WIFI FILE MAINTENANCE", 20, 20, 4);
  tft.drawString(String("SSID: ") + wifiApSsid, 20, 80, 2);
  tft.drawString(String("PASS: ") + wifiApPassword, 20, 110, 2);
  tft.drawString(String("OPEN: http://") + WiFi.softAPIP().toString(), 20, 140, 2);
  tft.drawString(String("Runtime DB: ") + TOYOTA_CAN_DB_RUNTIME_REVISION, 20, 170, 2);
  tft.drawString(String("Legacy catalog: v") + TOYOTA_CAN_DB_VERSION, 20, 190, 2);
  tft.drawString("EXIT from browser restarts logger", 20, 215, 2);
  lastWifiUiMs = 0;
  serviceWifiMaintenanceUi();
}


void updateDisplay();

enum DistanceEntryTarget : uint8_t {
  DISTANCE_ENTRY_NONE = 0,
  DISTANCE_ENTRY_ODO,
  DISTANCE_ENTRY_TRIP
};

uint8_t distanceEntryTarget = DISTANCE_ENTRY_NONE;
char distanceEntryBuffer[16] = {0};
uint8_t distanceEntryLength = 0;
char distanceEntryStatus[40] = {0};

static void drawDistanceEntryKey(int16_t x, int16_t y, int16_t w, int16_t h,
                                 const char *label, uint16_t color) {
  tft.fillRoundRect(x, y, w, h, 5, color);
  tft.drawRoundRect(x, y, w, h, 5, TFT_WHITE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE);
  tft.drawString(label, x + w / 2, y + h / 2, 2);
  tft.setTextDatum(TL_DATUM);
}

static void drawDistanceEntryScreen() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(TL_DATUM);
  tft.drawString(distanceEntryTarget == DISTANCE_ENTRY_ODO ? "ENTER ODO (mi)" : "ENTER TRIP (mi)", 12, 8, 2);
  tft.drawRoundRect(12, 32, 456, 40, 5, TFT_CYAN);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.drawString(distanceEntryLength ? distanceEntryBuffer : "---", 240, 52, 4);
  tft.setTextDatum(TL_DATUM);
  if (distanceEntryStatus[0]) {
    tft.setTextColor(TFT_ORANGE, TFT_BLACK);
    tft.drawString(distanceEntryStatus, 12, 74, 1);
  }

  static const char *keys[3][4] = {{"1","2","3","BACK"},{"4","5","6","CLEAR"},{"7","8","9","."}};
  const int16_t xs[4] = {12,126,240,354};
  const int16_t ys[3] = {88,136,184};
  for (uint8_t row=0; row<3; ++row) {
    for (uint8_t col=0; col<4; ++col) drawDistanceEntryKey(xs[col], ys[row], 106, 40, keys[row][col], TFT_DARKGREY);
  }
  drawDistanceEntryKey(12,232,106,40,"CANCEL",TFT_RED);
  drawDistanceEntryKey(126,232,220,40,"0",TFT_DARKGREY);
  drawDistanceEntryKey(354,232,106,40,"SAVE",TFT_DARKGREEN);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  tft.drawString("Stopped-only entry; SAVE resets SESSION distance to 0", 240, 292, 1);
  tft.setTextDatum(TL_DATUM);
}

static double distanceEntrySessionMiles() {
  double miles = (vehicleProfile==PROFILE_PRIUS_GEN2 && live.runDistanceValid) ? live.runDistanceMiles : sessionDistanceIntegrator.miles;
  return isfinite(miles) && miles >= 0.0 ? miles : 0.0;
}

static void beginDistanceEntry(uint8_t target) {
  if (target == DISTANCE_ENTRY_ODO && !odoManualEntryAllowed()) {
    Serial.println("# ODO ENTRY REJECTED,NHW20_0405 ONLY");
    return;
  }
  if (loggingActive || capturePressureMode) {
    Serial.println("# DISTANCE ENTRY REJECTED,STOP LOG FIRST");
    return;
  }
  distanceEntryTarget = target;
  distanceEntryLength = 0;
  distanceEntryBuffer[0] = '\0';
  distanceEntryStatus[0] = '\0';
  distanceEntryActive = true;
  drawDistanceEntryScreen();
}

static void endDistanceEntry(bool saved) {
  distanceEntryActive = false;
  distanceEntryTarget = DISTANCE_ENTRY_NONE;
  distanceEntryLength = 0;
  distanceEntryBuffer[0] = '\0';
  distanceEntryStatus[0] = '\0';
  invalidateTftDirtyCaches();
  tftLastRenderedPage = 0xFF;
  tftForceFullRedraw = true;
  Serial.printf("# DISTANCE ENTRY,%s\n", saved ? "SAVED" : "CANCELLED");
  // Keypad is a full-screen transient UI. Normal dirty redraw clears only y=2..242,
  // so erase the whole TFT once before restoring the logger page/buttons.
  tft.fillScreen(TFT_BLACK);
  updateDisplay();
}

static bool saveDistanceEntry() {
  double entered = 0.0;
  if (!fuelTripParseMiles(distanceEntryBuffer, &entered)) {
    snprintf(distanceEntryStatus, sizeof(distanceEntryStatus), "INVALID 0..999999.999");
    drawDistanceEntryScreen();
    return false;
  }
  if (loggingActive || capturePressureMode) {
    snprintf(distanceEntryStatus, sizeof(distanceEntryStatus), "STOP LOG FIRST");
    drawDistanceEntryScreen();
    return false;
  }

  // Preserve the other manually based counter at its currently displayed value,
  // then rebase SESSION to zero. This makes the newly entered value authoritative
  // immediately and keeps subsequent drive distance additive from this point.
  const double sessionMiles = distanceEntrySessionMiles();
  if (distanceEntryTarget == DISTANCE_ENTRY_ODO) {
    if (tripBaseValid) tripBaseMiles += sessionMiles;
    else { tripBaseMiles = sessionMiles; tripBaseValid = true; }
    odoBaseMiles=entered; odoBaseValid=true;
    gen2Persist.odoMiles=entered; gen2Persist.odoValid=true;
    if (gen2Persist.fuelValid) gen2Persist.lastFuelOdoMiles=entered;
    saveDistanceBase(TRIP_BASE_NVS_KEY,tripBaseMiles);
    saveDistanceBase(ODO_BASE_NVS_KEY,odoBaseMiles);
    gen2PersistCheckpoint(true);
    Serial.printf("# ODO TOUCH SET,%.3f\n",odoBaseMiles);
  } else if (distanceEntryTarget == DISTANCE_ENTRY_TRIP) {
    // Do not add SESSION miles again: gen2PersistDistance already accumulated them.
    if (nhw20EarlyProfileConfirmed()) gen2PersistCheckpoint(true);
    tripBaseMiles = entered; tripBaseValid = true;
    saveDistanceBase(TRIP_BASE_NVS_KEY, tripBaseMiles);
    Serial.printf("# TRIP TOUCH SET,%.3f\n", tripBaseMiles);
  } else return false;

  runtimeDistanceReset(sessionDistanceIntegrator, millis());
  live.runDistanceMiles = 0.0;
  live.runDistanceValid = false;
  nhw20RunCounterPriorValid = false;
  endDistanceEntry(true);
  return true;
}

static void handleDistanceEntryTouch(uint16_t x, uint16_t y) {
  if (!distanceEntryActive) return;
  distanceEntryStatus[0] = '\0';
  const int16_t xs[4] = {12,126,240,354};
  const int16_t ys[3] = {88,136,184};
  static const char keyChars[3][4] = {{'1','2','3','B'},{'4','5','6','C'},{'7','8','9','.'}};
  for (uint8_t row=0; row<3; ++row) {
    if (y < ys[row] || y >= ys[row] + 40) continue;
    for (uint8_t col=0; col<4; ++col) {
      if (x < xs[col] || x >= xs[col] + 106) continue;
      const char key = keyChars[row][col];
      if (key == 'B') fuelTripEntryBackspace(distanceEntryBuffer, &distanceEntryLength);
      else if (key == 'C') { distanceEntryLength = 0; distanceEntryBuffer[0] = '\0'; }
      else fuelTripEntryAppend(distanceEntryBuffer, &distanceEntryLength, sizeof(distanceEntryBuffer), key);
      drawDistanceEntryScreen();
      return;
    }
  }
  if (y >= 232 && y < 272) {
    if (x >= 12 && x < 118) { endDistanceEntry(false); return; }
    if (x >= 126 && x < 346) {
      fuelTripEntryAppend(distanceEntryBuffer, &distanceEntryLength, sizeof(distanceEntryBuffer), '0');
      drawDistanceEntryScreen(); return;
    }
    if (x >= 354 && x < 460) { saveDistanceEntry(); return; }
  }
}

void drawButtons() {
  if (distanceEntryActive) return;
  logger243_drawButtons();
  if (wifiMaintenanceMode) return;
  static uint32_t lastWifiButtonSignature = 0xFFFFFFFFUL;
  const uint32_t wifiButtonSignature = ((!loggingActive && sdReady) ? 1UL : 0UL);
  if (wifiButtonSignature == lastWifiButtonSignature) return;
  lastWifiButtonSignature = wifiButtonSignature;
  uint16_t wifiColor = (!loggingActive && sdReady) ? TFT_PURPLE : TFT_DARKGREY;
  tft.fillRoundRect(CYD_WIFI_BTN_X, CYD_WIFI_BTN_Y, CYD_WIFI_BTN_W, CYD_WIFI_BTN_H, 6, wifiColor);
  tft.drawRoundRect(CYD_WIFI_BTN_X, CYD_WIFI_BTN_Y, CYD_WIFI_BTN_W, CYD_WIFI_BTN_H, 6, TFT_WHITE);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE);
  tft.drawString("WIFI FILES", CYD_WIFI_BTN_X + CYD_WIFI_BTN_W / 2, 283, 2);
  tft.setTextDatum(TL_DATUM);
}

void updateDisplay() {
  if (wifiMaintenanceMode) return;
  if (distanceEntryActive) { drawDistanceEntryScreen(); return; }
  logger243_updateDisplay();
  drawButtons();
}

void handleTouch() {
  if (wifiMaintenanceMode) return;
  uint32_t nowMs = millis();
  uint16_t x = 0, y = 0;
  digitalWrite(SD_CS_PIN, HIGH);
  bool pressed = tft.getTouch(&x, &y);
  if (pressed) {
    if (!touchWasDown) {
      touchWasDown = true;
      touchDownX = x;
      touchDownY = y;
      Serial.printf("# TOUCH DOWN,%u,%u\n", x, y);
    }
    return;
  }
  if (!touchWasDown) return;
  touchWasDown = false;
  if (nowMs - lastTouchMs < 250) return;
  lastTouchMs = nowMs;

  if (distanceEntryActive) {
    handleDistanceEntryTouch(touchDownX, touchDownY);
    return;
  }

  if (operatorUiModal != OP_MODAL_NONE || displayPage == 12) {
    if (handleDtcUiTouch(touchDownX, touchDownY)) { updateDisplay(); return; }
  }

  if (displayPage == 13) {
    if (handleFanUiTouch(touchDownX, touchDownY)) { updateDisplay(); return; }
  }

  if (displayPage == 11 && !loggingActive) {
    const bool odoHit = touchDownX >= 245 && touchDownX < 470 && touchDownY >= 48 && touchDownY < 90;
    const bool tripHit = touchDownX >= 245 && touchDownX < 470 && touchDownY >= 98 && touchDownY < 140;
    if (odoHit && odoManualEntryAllowed()) { beginDistanceEntry(DISTANCE_ENTRY_ODO); return; }
    if (tripHit) { beginDistanceEntry(DISTANCE_ENTRY_TRIP); return; }
  }

  bool wifiButton = touchDownX >= CYD_WIFI_BTN_X && touchDownX < CYD_WIFI_BTN_X + CYD_WIFI_BTN_W &&
                    touchDownY >= CYD_WIFI_BTN_Y && touchDownY < CYD_WIFI_BTN_Y + CYD_WIFI_BTN_H;
  if (wifiButton) {
    if (!loggingActive && sdReady) enterWifiMaintenanceMode();
    return;
  }

  bool logButton = touchDownX >= CYD_LOG_BTN_X && touchDownX < CYD_LOG_BTN_X + CYD_LOG_BTN_W && touchDownY >= CYD_LOG_BTN_Y && touchDownY < CYD_LOG_BTN_Y + CYD_LOG_BTN_H;
  bool diagButton = touchDownX >= CYD_DIAG_BTN_X && touchDownX < CYD_DIAG_BTN_X + CYD_DIAG_BTN_W && touchDownY >= CYD_DIAG_BTN_Y && touchDownY < CYD_DIAG_BTN_Y + CYD_DIAG_BTN_H;
  bool pageButton = touchDownX >= CYD_PAGE_BTN_X && touchDownX < CYD_PAGE_BTN_X + CYD_PAGE_BTN_W && touchDownY >= CYD_PAGE_BTN_Y && touchDownY < CYD_PAGE_BTN_Y + CYD_PAGE_BTN_H;
  if (pageButton) { displayPage = (displayPage + 1) % 14; updateDisplay(); }
  else if (logButton) { if (loggingActive) requestLoggingStop(nullptr, true); else startLogging(); }
  else if (diagButton) {
    if (diagnosticEnabled) {
      // Manual pause: stop CYD-originated diagnostic requests. Passive CAN and
      // external-tester decoding continue.
      diagnosticAutoStartPending = false;
      setDiagnosticCapture(false, "Touchscreen user pause");
    } else if (diagnosticCanBeEnabledForProfile(vehicleProfile)) {
      // Manual resume. If another tester is currently active, keep the resume
      // pending until the external-tester hold window expires.
      diagnosticAutoStartPending = true;
      if (setDiagnosticCapture(true, "Touchscreen user resume"))
        diagnosticAutoStartPending = false;
    } else if (nowMs - lastDiagRejectMs >= 2000) {
      writeEvent("WARNING", "DIAGNOSTIC_ENABLE_REJECTED",
                 "Profile conflict/unsupported or no read plan; write controls require VERIFIED identity/capability");
      lastDiagRejectMs = nowMs;
    }
  }
  drawButtons();
}

void setup() {
  logger243_setup();
  Serial.printf("# HV Health DEV3.5.1 RAW + META / TFT PERF3 + platform equivalency ready; STARTPERF2 SD25M STORAGERES2 FUELPROFILE1 DTCFAN2 WIFIEXIT1 ODOFUELPERSIST1 FUELBARPHVCAM1; core v2.4.3; runtime=%s; Wi-Fi OFF; legacy catalog v%s; decoded IDs=%u\n",
                TOYOTA_CAN_DB_RUNTIME_REVISION, TOYOTA_CAN_DB_VERSION, (unsigned)DB_DECODED_ID_COUNT);
  updateDisplay();
}

static void serviceWifiMaintenanceMode() {
  wifiServer.handleClient();
  serviceWifiZipDownload();
  if (!wifiZipDownloadBusy()) serviceStoredSessionZipAsync();
  serviceWifiMaintenanceUi();
  serviceWifiMaintenanceTouch();

  if (!wifiZipCompletionLogged && storedSessionZipAsyncDone()) {
    Serial.printf("# WIFI ZIP ASYNC READY,%s,%llu bytes\n",
                  storedSessionZipAsyncSession().c_str(),
                  (unsigned long long)storedSessionZipAsyncBytes());
    wifiZipCompletionLogged = true;
  } else if (!wifiZipCompletionLogged && storedSessionZipAsyncFailed()) {
    Serial.printf("# WIFI ZIP ASYNC STOPPED,%s,%s\n",
                  storedSessionZipAsyncSession().c_str(),
                  storedSessionZipAsyncError().c_str());
    wifiZipCompletionLogged = true;
  }
}

void loop() {
  if (wifiMaintenanceMode) {
    serviceWifiMaintenanceMode();
    delay(1);
    return;
  }

  handleTouch();
  if (wifiMaintenanceMode) {
    serviceWifiMaintenanceMode();
    delay(1);
    return;
  }

  uint32_t displayStampBefore = lastDisplayMs;
  logger243_loop();
  servicePlotRecorder();
  serviceHvHealthAccumulator();
  if (lastDisplayMs != displayStampBefore && !wifiMaintenanceMode && !distanceEntryActive) drawButtons();
}
